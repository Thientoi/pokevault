# POKÉVAULT cho Google AI Studio

Bản mã nguồn Next.js 16, React 19 và Node.js để tiếp tục chỉnh sửa cửa hàng POKÉVAULT trong Google AI Studio. Gồm giao diện tiếng Việt, 9 sản phẩm mẫu, giỏ hàng, đặt đơn thử và trang quản trị. Ảnh và font được lưu trong dự án.

## Chạy thử

Cần Node.js **22.13 trở lên**.

```powershell
npm ci
npm run dev
```

Mở `http://127.0.0.1:3000/`. Trang quản trị ở `/quan-tri` hoặc `/admin`. Máy chủ lắng nghe trên `0.0.0.0`; có thể đặt `PORT` theo môi trường xem trước. Kiểm tra bản dựng bằng `npm run build` và chạy bằng `npm start`.

Cơ sở dữ liệu SQLite được tạo và áp dụng migration khi sử dụng lần đầu. Danh mục 9 sản phẩm được thêm khi mở cửa hàng. Không cần Cloudflare, Wrangler, Sites hay khóa Gemini để chạy các chức năng cửa hàng hiện tại.

Nếu preview đi qua proxy HTTPS, đặt `APP_URL` bằng đúng địa chỉ preview để kiểm tra nguồn yêu cầu và metadata dùng tên miền thực tế.

## Đưa vào Google AI Studio

1. Đưa mã nguồn này vào một repository GitHub của bạn, gồm cả thư mục `public` và `drizzle`.
2. Trong Google AI Studio, mở **Build → dấu + → Import from GitHub** và chọn repository.
3. Dùng nội dung trong [AI_STUDIO_IMPORT.md](AI_STUDIO_IMPORT.md) nếu AI Studio cần hướng dẫn chạy dự án.
4. Sau khi Google tạo dự án, dùng chính URL của dự án đó để tiếp tục chỉnh sửa.

Tài liệu nhập dự án: [Google AI Studio Build](https://ai.google.dev/gemini-api/docs/aistudio-build-mode). Đây là gói mã nguồn đã chuẩn bị; bản thân thư mục này không tạo ra URL Google AI Studio.

## Tài khoản quản trị

Không có tài khoản hay mật khẩu mặc định. Tài khoản `admin` của bản Cursor trước đó và dữ liệu trong cơ sở dữ liệu cũ không được sao chép vào bản này.

- Khi chạy trên máy, sao chép `.env.example` thành `.env.local`. Trong AI Studio, đặt các giá trị tương ứng ở phần biến môi trường/Secrets của máy chủ.
- Đặt `ADMIN_SETUP_KEY` thành chuỗi ngẫu nhiên riêng ít nhất 32 ký tự, giữ `COMMERCE_LIVE=false` và `LOCAL_ADMIN_LOGIN=false`, rồi khởi động lại máy chủ.
- Mở `/quan-tri`, chọn **Thiết lập quản trị**, nhập khóa thiết lập, tên, email và mật khẩu riêng ít nhất 10 ký tự.
- Đăng nhập bằng email vừa tạo. Sau đó xóa `ADMIN_SETUP_KEY` khỏi môi trường và khởi động lại máy chủ. Khi đã có admin, chức năng tạo admin đầu tiên sẽ khóa.

Không đưa tệp môi trường, khóa thiết lập, mật khẩu hoặc cơ sở dữ liệu lên GitHub. Chỉ `.env.example` chứa các giá trị mẫu được chia sẻ cùng mã nguồn.

## Dữ liệu và chế độ thử

Mặc định `COMMERCE_LIVE=false`: đơn thử được ghi vào cơ sở dữ liệu, không có thanh toán, gửi email hay giao hàng thật. Ảnh, sản phẩm, giá, tồn kho và chính sách là dữ liệu minh họa.

`DATABASE_PATH` mặc định là `.data/pokevault.sqlite`. Tệp SQLite giữ dữ liệu qua lần khởi động lại nếu thư mục đó còn tồn tại. **Không coi tệp này là kho dữ liệu bền vững khi xuất bản lên Cloud Run:** hệ thống có thể thay hoặc khởi động lại container và không chia sẻ tệp giữa các bản chạy. Trước khi bán thật hoặc xuất bản dùng lâu dài, cần kết nối cơ sở dữ liệu lưu trữ bền vững và kiểm tra lại giao dịch tồn kho, đăng nhập, sao lưu.

## Kiểm tra

```powershell
npm run check
npm test
# Máy chủ local cần đang chạy, dùng cùng DATABASE_PATH với bài kiểm tra.
npm run test:api
```

`test:api` chạy 54 kiểm tra API và tài nguyên: đăng nhập, phân quyền, CSRF, sản phẩm, mã giảm giá, giá tính ở máy chủ, tồn kho, đặt đồng thời, hủy đơn, giỏ hàng/đơn thử và các đường dẫn giao diện. Nó chỉ tạo và dọn các bản ghi thử có mã riêng của lần chạy; không thay dữ liệu mẫu. Chỉ chạy trên cơ sở dữ liệu local dành cho thử nghiệm. Nếu dùng cổng khác, đặt `TEST_URL`; nếu dùng tệp dữ liệu khác, đặt cùng `DATABASE_PATH` cho cả máy chủ và lệnh kiểm tra. Bộ kiểm tra này không thay thế kiểm tra hình ảnh và thao tác trình duyệt.
