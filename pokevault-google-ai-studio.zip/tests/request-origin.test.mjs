import test from "node:test";
import assert from "node:assert/strict";
import { sameOriginRequest } from "../lib/request-origin.ts";

test("Next listener host accepts browser same-origin requests and rejects foreign origins", () => {
  const request = (origin, host = "127.0.0.1:3000") => new Request("http://0.0.0.0:3000/api/auth/login", {
    headers: { host, ...(origin ? { origin } : {}) },
  });
  assert.equal(sameOriginRequest(request("http://127.0.0.1:3000")), true);
  for (const origin of ["https://evil.example", "null", "http://127.0.0.1:3000.evil.example", "http://127.0.0.1:3000/", ""])
    assert.equal(sameOriginRequest(request(origin)), false);
  assert.equal(sameOriginRequest(request("https://preview.example"), "https://preview.example"), true);
  assert.equal(sameOriginRequest(request("https://other.example"), "https://preview.example"), false);
});
