import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  mkdirSync,
  writeFileSync,
  rmSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { basename, join, resolve, sep } from "node:path";
import { createDatabase } from "../lib/database.ts";

function temporary(t) {
  const directory = mkdtempSync(join(tmpdir(), "pokevault-db-test-"));
  t.after(() => {
    const target = resolve(directory);
    if (!target.startsWith(resolve(tmpdir()) + sep) || !basename(target).startsWith("pokevault-db-test-"))
      throw new Error("Refusing cleanup outside the temporary database test directory.");
    rmSync(target, { recursive: true, force: true });
  });
  return directory;
}

test("SQLite migration and RETURNING preserve D1 query contracts and persisted data", async (t) => {
  const filename = join(temporary(t), "shop.sqlite");
  let db = createDatabase(filename);
  try {
    const insert = await db
      .prepare(
        "INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) RETURNING count",
      )
      .bind("sample", 123)
      .all();
    assert.equal(insert.meta.changes, 1);
    assert.equal(insert.results[0].count, 1);
    const row = await db
      .prepare(
        "UPDATE rate_limits SET count=count+1 WHERE key=? RETURNING count",
      )
      .bind("sample")
      .first();
    assert.equal(row.count, 2);
    const missing = await db
      .prepare("UPDATE rate_limits SET count=0 WHERE key=?")
      .bind("missing")
      .run();
    assert.equal(missing.meta.changes, 0);
    const selected = await db
      .prepare("SELECT count FROM rate_limits WHERE key=?")
      .bind("sample")
      .all();
    assert.equal(selected.meta.changes, 0);
    db.close();
    db = createDatabase(filename);
    assert.equal(
      await db
        .prepare("SELECT count FROM rate_limits WHERE key=?")
        .bind("sample")
        .first("count"),
      2,
    );
    assert.equal(
      await db
        .prepare("SELECT count FROM rate_limits WHERE key=?")
        .bind("absent")
        .first(),
      null,
    );
  } finally {
    db.close();
  }
});

test("Inventory batch rolls back every write when a later statement fails", async (t) => {
  const db = createDatabase(join(temporary(t), "shop.sqlite"));
  try {
    await db
      .prepare(
        "INSERT INTO products(id,name,category,price,stock,description,image,color,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
      )
      .bind(
        "box",
        "Sample",
        "Mystery Box",
        1000,
        1,
        "Sample item",
        "/products/box.svg",
        "red",
        123,
      )
      .run();
    await assert.rejects(
      db.batch([
        db.prepare(
          "INSERT INTO meta(key,value) VALUES('order-marker','pending')",
        ),
        db.prepare("UPDATE products SET stock=stock-2 WHERE id='box'"),
      ]),
      /CHECK constraint failed/,
    );
    assert.equal(
      await db
        .prepare("SELECT stock FROM products WHERE id='box'")
        .first("stock"),
      1,
    );
    assert.equal(
      await db
        .prepare("SELECT value FROM meta WHERE key='order-marker'")
        .first(),
      null,
    );
    const committed = await db.batch([
      db.prepare(
        "INSERT INTO meta(key,value) VALUES('order-marker','confirmed')",
      ),
      db.prepare("UPDATE products SET stock=stock-1 WHERE id='box'"),
    ]);
    assert.equal(committed[1].meta.changes, 1);
    assert.equal(
      await db
        .prepare("SELECT stock FROM products WHERE id='box'")
        .first("stock"),
      0,
    );
  } finally {
    db.close();
  }
});

test("Applied migrations cannot silently change and pending migrations apply once", async (t) => {
  const directory = temporary(t);
  const migrationsDirectory = join(directory, "migrations");
  mkdirSync(migrationsDirectory);
  const firstPath = join(migrationsDirectory, "0000.sql");
  const original =
    "CREATE TABLE sample (id TEXT PRIMARY KEY, value INTEGER NOT NULL);\n";
  writeFileSync(firstPath, original);
  const filename = join(directory, "shop.sqlite");
  let db = createDatabase(filename, { migrationsDirectory });
  await db.prepare("INSERT INTO sample VALUES('saved',7)").run();
  db.close();
  writeFileSync(
    join(migrationsDirectory, "0001.sql"),
    "ALTER TABLE sample ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1;\n",
  );
  db = createDatabase(filename, { migrationsDirectory });
  assert.equal(
    await db
      .prepare("SELECT enabled FROM sample WHERE id='saved'")
      .first("enabled"),
    1,
  );
  db.close();
  writeFileSync(firstPath, original + "-- changed applied migration\n");
  assert.throws(
    () => createDatabase(filename, { migrationsDirectory }),
    /Applied migration has changed/,
  );
  writeFileSync(firstPath, original.replace(/\n/g, "\r\n"));
  db = createDatabase(filename, { migrationsDirectory });
  assert.equal(
    await db
      .prepare("SELECT COUNT(*) AS n FROM __pokevault_migrations")
      .first("n"),
    2,
  );
  assert.equal(
    await db
      .prepare("SELECT value FROM sample WHERE id='saved'")
      .first("value"),
    7,
  );
  db.close();
});
