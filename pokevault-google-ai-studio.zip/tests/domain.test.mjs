import test from "node:test";
import assert from "node:assert/strict";
import { normalize, seedProducts } from "../lib/catalog.ts";
import {
  totals,
  checkoutSchema,
  productSchema,
  loginSchema,
  passwordSchema,
} from "../lib/validation.ts";
import { localAdminEnabled } from "../lib/local-admin.ts";
import { addToCart, restoreCart } from "../lib/cart.ts";
test("Local admin alias requires opt-in, loopback and demo mode", () => {
  const enabled = { LOCAL_ADMIN_LOGIN: "true", COMMERCE_LIVE: "false" };
  assert.equal(
    localAdminEnabled(new URL("http://127.0.0.1:5173"), enabled),
    true,
  );
  assert.equal(
    localAdminEnabled(new URL("http://localhost:5173"), enabled),
    true,
  );
  for (const host of [
    "https://shop.example",
    "http://192.168.1.2",
    "https://localhost.example",
  ])
    assert.equal(localAdminEnabled(new URL(host), enabled), false);
  for (const config of [
    {},
    { LOCAL_ADMIN_LOGIN: "true" },
    { ...enabled, LOCAL_ADMIN_LOGIN: "false" },
    { ...enabled, COMMERCE_LIVE: "true" },
  ])
    assert.equal(
      localAdminEnabled(new URL("http://127.0.0.1:5173"), config),
      false,
    );
});

test("Short local admin password does not relax customer or setup validation", () => {
  assert.equal(
    loginSchema(true).safeParse({ email: "admin", password: "1" }).success,
    true,
  );
  assert.equal(
    loginSchema(false).safeParse({ email: "admin", password: "1" }).success,
    false,
  );
  assert.equal(
    loginSchema(true).safeParse({ email: "admin", password: "" }).success,
    false,
  );
  assert.equal(
    loginSchema(true).safeParse({ email: "user@example.com", password: "1" })
      .success,
    false,
  );
  assert.equal(
    loginSchema(true).safeParse({
      email: "admin@pokevault.local",
      password: "1",
    }).success,
    false,
  );
  assert.equal(passwordSchema.safeParse("1").success, false);
  assert.equal(
    loginSchema(false).safeParse({
      email: "user@example.com",
      password: "A-valid-password",
    }).success,
    true,
  );
});
test("Vietnamese search matches accents, uppercase Đ and product terms", () => {
  assert.equal(normalize("ĐẶC BIỆT"), "dac biet");
  const matches = seedProducts.filter((p) =>
    normalize(p.name + " " + p.description + " " + p.category).includes(
      normalize("tui bao ve"),
    ),
  );
  assert.ok(matches.some((p) => p.id === "card-sleeves"));
  assert.equal(
    seedProducts.filter((p) => normalize(p.name).includes("not-a-product"))
      .length,
    0,
  );
});
test("Free shipping threshold and express override are independent of coupon", () => {
  assert.deepEqual(totals(699000, "standard", 10, 50000), {
    subtotal: 699000,
    discount: 50000,
    shipping: 0,
    total: 649000,
  });
  assert.equal(totals(698999, "standard").shipping, 30000);
  assert.equal(totals(699000, "express").shipping, 50000);
});
test("Checkout rejects invalid quantity, empty cart and unsupported payment", () => {
  const valid = {
    id: crypto.randomUUID(),
    name: "Test User",
    phone: "0901234567",
    address: "Test address only",
    shippingMethod: "standard",
    payment: "cod",
    items: [{ id: "mystery-starter", quantity: 1 }],
  };
  assert.ok(checkoutSchema.safeParse(valid).success);
  for (const change of [
    { items: [] },
    { items: [{ id: "mystery-starter", quantity: -1 }] },
    { items: [{ id: "mystery-starter", quantity: 21 }] },
    { payment: "bank" },
    { phone: "abc" },
  ])
    assert.equal(
      checkoutSchema.safeParse({ ...valid, ...change }).success,
      false,
    );
});
test("Product edits reject external images, negative stock and invalid category", () => {
  const p = seedProducts[0];
  assert.ok(productSchema.safeParse(p).success);
  for (const change of [
    { stock: -1 },
    { price: 0 },
    { image: "https://tracker.example/image.svg" },
    { category: "invalid" },
  ])
    assert.equal(productSchema.safeParse({ ...p, ...change }).success, false);
});

test("Cart additions use remaining capacity and preserve current cart on rejection", () => {
  const product = { id: "limited-box", active: 1, stock: 5 };
  const initial = [
    { id: "another-box", quantity: 2 },
    { id: product.id, quantity: 3 },
  ];
  const first = addToCart(initial, product, 1);
  assert.equal(first.ok, true);
  const second = addToCart(first.cart, product, 1);
  assert.equal(second.ok, true);
  assert.deepEqual(second.cart, [
    { id: "another-box", quantity: 2 },
    { id: product.id, quantity: 5 },
  ]);
  assert.deepEqual(addToCart(second.cart, product, 1), {
    ok: false,
    reason: "capacity",
  });
  assert.equal(second.cart[1].quantity, 5);
  assert.equal(initial[1].quantity, 3);
  assert.deepEqual(addToCart([], { ...product, stock: 100 }, 21), {
    ok: false,
    reason: "capacity",
  });
});

test("Cart rejects unavailable products and invalid amounts without exceeding checkout line limit", () => {
  const product = { id: "box", active: 1, stock: 10 };
  for (const amount of [0, -1, 1.5, NaN, Infinity])
    assert.deepEqual(addToCart([], product, amount), {
      ok: false,
      reason: "quantity",
    });
  for (const unavailable of [
    undefined,
    { ...product, active: 0 },
    { ...product, stock: 0 },
  ])
    assert.deepEqual(addToCart([], unavailable, 1), {
      ok: false,
      reason: "unavailable",
    });
  const fullCart = Array.from({ length: 20 }, (_, i) => ({
    id: "box-" + i,
    quantity: 1,
  }));
  assert.deepEqual(addToCart(fullCart, product, 1), {
    ok: false,
    reason: "lines",
  });
  const existing = addToCart(fullCart, { ...product, id: "box-0" }, 1);
  assert.equal(existing.ok, true);
  assert.equal(existing.cart.length, 20);
  assert.equal(existing.cart[0].quantity, 2);
});

test("Persisted cart restores only valid, distinct checkout lines", () => {
  assert.deepEqual(
    restoreCart([
      null,
      { id: "box", quantity: 2 },
      { id: "box", quantity: 3 },
      { id: "invalid", quantity: 21 },
      { id: "", quantity: 1 },
      { id: "valid", quantity: 20 },
    ]),
    [
      { id: "box", quantity: 2 },
      { id: "valid", quantity: 20 },
    ],
  );
  assert.equal(
    restoreCart(
      Array.from({ length: 25 }, (_, i) => ({ id: "box-" + i, quantity: 1 })),
    ).length,
    20,
  );
});
