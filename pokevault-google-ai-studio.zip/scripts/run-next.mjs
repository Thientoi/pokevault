import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const mode = process.argv[2];
if (!["dev", "start"].includes(mode)) throw new Error("Use dev or start.");
const project = fileURLToPath(new URL("../", import.meta.url));
const port = process.env.PORT || "3000";
if (!/^\d+$/.test(port) || +port < 1 || +port > 65535)
  throw new Error("Invalid PORT.");
const child = spawn(
  process.execPath,
  [
    fileURLToPath(
      new URL("../node_modules/next/dist/bin/next", import.meta.url),
    ),
    mode,
    "--hostname",
    "0.0.0.0",
    "--port",
    port,
    ...(mode === "dev" ? ["--webpack"] : []),
  ],
  {
    cwd: project,
    stdio: "inherit",
    env: { ...process.env, NEXT_TELEMETRY_DISABLED: "1" },
  },
);
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => child.kill(signal));
child.on("error", (error) => {
  console.error(error.message);
  process.exitCode = 1;
});
child.on("exit", (code) => {
  process.exitCode = code ?? 1;
});
