import assert from "node:assert/strict";
import { randomUUID, randomBytes, pbkdf2Sync } from "node:crypto";
import { execFileSync } from "node:child_process";
const base = process.env.TEST_URL || "http://127.0.0.1:3000";
if (!["127.0.0.1", "localhost"].includes(new URL(base).hostname))
  throw new Error(
    "Integration tests are restricted to a local, disposable development database.",
  );
const origin = new URL(base).origin,
  run = randomUUID(),
  adminId = randomUUID(),
  userEmail = `qa-${run}@example.invalid`,
  adminEmail = `qa-admin-${run}@example.invalid`,
  password = randomBytes(24).toString("hex"),
  productId = `qa-${run}`,
  couponCode = `QA${run.replaceAll('-','').slice(0,16).toUpperCase()}`,
  orderIds = [];
let passed = 0,
  adminCookie = "",
  userCookie = "";
function sql(query) {
  try {
    execFileSync(
      process.execPath,
      ["--experimental-strip-types", "./scripts/database-query.mjs"],
      { input: query, encoding: "utf8", stdio: ["pipe", "pipe", "pipe"] },
    );
  } catch {
    throw new Error("Could not prepare or remove local SQLite test fixtures.");
  }
}
async function req(
  path,
  method = "GET",
  body,
  cookie = "",
  customOrigin = origin,
) {
  const r = await fetch(base + "/api/" + path, {
    method,
    headers: {
      ...(body
        ? { "Content-Type": "application/json", Origin: customOrigin }
        : {}),
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const raw = await r.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    data = { error: raw };
  }
  return { status: r.status, data, cookie: r.headers.get("set-cookie") || "" };
}
function check(name, fn) {
  fn();
  passed++;
  console.log(`PASS ${String(passed).padStart(2, "0")} ${name}`);
}
function order(overrides = {}) {
  const id = randomUUID();
  orderIds.push(id);
  return {
    id,
    name: "Khách thử nghiệm",
    phone: "0901234567",
    address: "Địa chỉ thử nghiệm, không giao hàng",
    note: "Automated QA fixture",
    shippingMethod: "standard",
    payment: "cod",
    coupon: "",
    items: [{ id: productId, quantity: 1 }],
    ...overrides,
  };
}
let original;
try {
  const listing = await req("products");
  check("Catalog contains 9+ products and UTF-8 descriptions", () => {
    assert.equal(listing.status, 200);
    assert.ok(listing.data.products.length >= 9);
    assert.ok(listing.data.products.some((p) => p.category === "Thẻ bài"));
    assert.equal(listing.data.demo, true);
  });
  const unauthorized = await req("admin/overview");
  check("Anonymous admin request is denied without customer or dashboard data", () => {
    assert.equal(unauthorized.status, 401);
    assert.equal(unauthorized.data.customers, undefined);
    assert.equal(unauthorized.data.summary, undefined);
  });
  const originDenied = await req(
    "auth/register",
    "POST",
    { email: userEmail, name: "QA Customer", password },
    "",
    "https://evil.example",
  );
  check("Cross-origin mutation is rejected", () =>
    assert.equal(originDenied.status, 403),
  );
  const register = await req("auth/register", "POST", {
    email: userEmail,
    name: "QA Customer",
    password,
  });
  userCookie = register.cookie.split(";")[0];
  check("Registration creates secure HttpOnly session", () => {
    assert.equal(register.status, 201);
    assert.match(register.cookie, /HttpOnly/);
    assert.match(register.cookie, /SameSite=Lax/);
  });
  const me = await req("me", "GET", null, userCookie);
  check("Profile does not disclose password", () => {
    assert.equal(me.data.user.email, userEmail);
    assert.equal(me.data.user.password, undefined);
  });
  const forbidden = await req("admin/overview", "GET", null, userCookie);
  check("Customer cannot read admin data or other customer profiles", () => {
    assert.equal(forbidden.status, 403);
    assert.equal(forbidden.data.customers, undefined);
    assert.equal(forbidden.data.orders, undefined);
  });
  const badLogin = await req("auth/login", "POST", {
    email: userEmail,
    password: password + "wrong",
  });
  check("Wrong password is rejected", () => assert.equal(badLogin.status, 401));
  const profile = await req(
    "profile",
    "PUT",
    {
      name: "QA Updated",
      phone: "0901234567",
      address: "Địa chỉ nhận hàng thử nghiệm",
    },
    userCookie,
  );
  check("Customer profile can be updated", () =>
    assert.equal(profile.status, 200),
  );
  const invalid = await req(
    "orders",
    "POST",
    order({ phone: "123" }),
    userCookie,
  );
  check("Server validates checkout phone", () =>
    assert.equal(invalid.status, 400),
  );
  const salt = randomBytes(16).toString("hex"),
    hash =
      salt +
      ":" +
      pbkdf2Sync(password, salt, 100000, 32, "sha256").toString("hex");
  sql(
    `INSERT INTO users(id,email,name,password,role) VALUES('${adminId}','${adminEmail}','QA Admin','${hash}','admin');`,
  );
  const login = await req("auth/login", "POST", {
    email: adminEmail,
    password,
  });
  adminCookie = login.cookie.split(";")[0];
  check("Admin can authenticate with hashed password", () =>
    assert.equal(login.status, 200),
  );
  const overviewBefore = await req("admin/overview", "GET", null, adminCookie);
  check("Admin dashboard returns truthful full counts and bounded lists", () => {
    assert.equal(overviewBefore.status, 200);
    for (const field of ["totalOrders", "pendingOrders", "activeProducts", "lowStockProducts", "customerCount", "deliveredValue", "demoOrders"])
      assert.ok(Number.isInteger(overviewBefore.data.summary[field]) && overviewBefore.data.summary[field] >= 0, field);
    assert.ok(overviewBefore.data.orders.length <= 200);
    assert.ok(overviewBefore.data.customers.length <= 500);
    assert.deepEqual(overviewBefore.data.scope, {ordersLimit:200, customersLimit:500, timezone:"Asia/Bangkok"});
  });
  const today = new Date(Date.now() + 7 * 3600000).toISOString().slice(0, 10);
  check("Dashboard chart has 14 continuous Bangkok days, including zero days", () => {
    const days = overviewBefore.data.dailyOrders;
    assert.equal(days.length, 14);
    assert.equal(days.at(-1).day, today);
    for (let index = 0; index < days.length; index++) {
      assert.match(days[index].day, /^\d{4}-\d{2}-\d{2}$/);
      assert.ok(Number.isInteger(days[index].liveOrders));
      assert.ok(Number.isInteger(days[index].demoOrders));
      if (index) assert.equal(Date.parse(days[index].day)-Date.parse(days[index-1].day),86400000);
    }
  });
  check("Admin customer records exclude credentials and report only known integrations", () => {
    const customer=overviewBefore.data.customers.find(c=>c.email===userEmail);
    assert.ok(customer);
    assert.deepEqual(Object.keys(customer).sort(), ["id","name","email","phone","address","orderCount","totalSpent","lastOrderAt"].sort());
    assert.equal(customer.orderCount,0);
    assert.equal(customer.totalSpent,0);
    assert.equal(overviewBefore.data.settings.demoMode,true);
    assert.equal(overviewBefore.data.settings.emailConnected,false);
    assert.equal(overviewBefore.data.settings.shippingConnected,false);
    assert.equal(overviewBefore.data.settings.paymentsConnected,false);
    assert.equal(overviewBefore.data.settings.adminSetupEnabled,false);
    assert.equal(typeof overviewBefore.data.settings.adminSetupKeyConfigured,"boolean");
    assert.equal(overviewBefore.data.settings.ADMIN_SETUP_KEY,undefined);
  });
  original = {
    id: productId,
    name: "QA Product",
    category: "Mystery Box",
    price: 299000,
    oldPrice: 349000,
    stock: 5,
    description: "Temporary integration test fixture",
    image: "/products/box-yellow.svg",
    color: "yellow",
    badge: "QA",
    active: 1,
  };
  const create = await req("admin/product", "POST", original, adminCookie);
  check("Admin creates a product", () => assert.equal(create.status, 201));
  const collision = await req("admin/product", "POST", { ...original, name:"Must not overwrite", stock:999 }, adminCookie);
  const afterCollision = await req("products");
  check("Creating an existing product slug returns conflict without overwriting", () => {
    assert.equal(collision.status,409);
    const existing=afterCollision.data.products.find(p=>p.id===productId);
    assert.equal(existing.name,original.name);
    assert.equal(existing.stock,original.stock);
  });
  const missingEdit = await req("admin/product", "PUT", { ...original, id:productId+'-missing' }, adminCookie);
  check("Editing a missing product does not accidentally create it",()=>assert.equal(missingEdit.status,404));
  const createDenied = await req("admin/product", "POST", original, userCookie);
  check("Customer cannot edit products", () =>
    assert.equal(createDenied.status, 403),
  );
  const testCoupon={code:couponCode,percent:10,maximum:50000,active:1};
  const couponCreated=await req("admin/coupon","POST",testCoupon,adminCookie);
  const couponCollision=await req("admin/coupon","POST",{...testCoupon,percent:40,maximum:100000},adminCookie);
  const couponAfterCollision=await req("coupon","POST",{code:couponCode});
  check("Creating a duplicate coupon returns conflict and preserves the original discount",()=>{
    assert.equal(couponCreated.status,201);
    assert.equal(couponCollision.status,409);
    assert.equal(couponAfterCollision.data.percent,10);
    assert.equal(couponAfterCollision.data.maximum,50000);
  });
  const couponMissingEdit=await req("admin/coupon","PUT",{...testCoupon,code:couponCode+'M'},adminCookie);
  check("Editing a missing coupon does not create it",()=>assert.equal(couponMissingEdit.status,404));
  const payload = order({
    coupon: "HELLOVAULT",
    items: [{ id: productId, quantity: 2, price: 1 }],
    total: 1,
  });
  const placed = await req("orders", "POST", payload, userCookie);
  check(
    "Checkout recalculates price, shipping and capped discount server-side",
    () => {
      assert.equal(placed.status, 201);
      assert.equal(placed.data.subtotal, 598000);
      assert.equal(placed.data.discount, 50000);
      assert.equal(placed.data.shipping, 30000);
      assert.equal(placed.data.total, 578000);
      assert.equal(placed.data.demo, true);
    },
  );
  const repeated = await req("orders", "POST", payload, userCookie);
  const afterRepeat = await req("products");
  check("Retrying an order does not double-decrement stock", () => {
    assert.equal(repeated.status, 200);
    assert.equal(
      afterRepeat.data.products.find((p) => p.id === productId).stock,
      3,
    );
  });
  const overviewAfter = await req("admin/overview", "GET", null, adminCookie);
  check("Dashboard counts newly placed demo order without inflating sales", () => {
    const before=overviewBefore.data.summary,after=overviewAfter.data.summary;
    assert.equal(after.totalOrders,before.totalOrders+1);
    assert.equal(after.pendingOrders,before.pendingOrders+1);
    assert.equal(after.demoOrders,before.demoOrders+1);
    assert.equal(after.activeProducts,before.activeProducts+1);
    assert.equal(after.lowStockProducts,before.lowStockProducts+1);
    assert.equal(after.deliveredValue,before.deliveredValue);
    const customer=overviewAfter.data.customers.find(c=>c.email===userEmail);
    assert.equal(customer.orderCount,1);
    assert.equal(customer.totalSpent,0);
    assert.equal(typeof customer.lastOrderAt,"number");
    const beforeDay=overviewBefore.data.dailyOrders.find(d=>d.day===today),afterDay=overviewAfter.data.dailyOrders.find(d=>d.day===today);
    assert.equal(afterDay.demoOrders,beforeDay.demoOrders+1);
    assert.equal(afterDay.liveOrders,beforeDay.liveOrders);
  });
  const hideForVisibility = await req("admin/products", "PATCH", {id:productId,active:0}, adminCookie);
  const restoreVisibility = await req("admin/products", "PATCH", {id:productId,active:1}, adminCookie);
  const afterVisibility = await req("products");
  check("Visibility-only hide and restore preserve inventory changed by checkout",()=>{
    assert.equal(hideForVisibility.status,200);
    assert.equal(restoreVisibility.status,200);
    assert.equal(afterVisibility.data.products.find(p=>p.id===productId).stock,3);
  });
  const staleVisibility = await req("admin/products", "PATCH", {...original,active:1}, adminCookie);
  check("Visibility patch rejects full stale product snapshots",()=>assert.equal(staleVisibility.status,400));
  const visibilityDenied = await req("admin/products", "PATCH", {id:productId,active:0}, userCookie);
  check("Customer cannot change product visibility",()=>assert.equal(visibilityDenied.status,403));
  const oversell = await req(
    "orders",
    "POST",
    order({ items: [{ id: productId, quantity: 4 }] }),
    userCookie,
  );
  check("Insufficient stock blocks order", () =>
    assert.equal(oversell.status, 409),
  );
  const invalidCoupon = await req(
    "orders",
    "POST",
    order({ coupon: "INVALIDCODE" }),
    userCookie,
  );
  check("Unknown coupon blocks order", () =>
    assert.equal(invalidCoupon.status, 400),
  );
  const history = await req("orders", "GET", null, userCookie);
  check("Customer sees only their own order history", () =>
    assert.deepEqual(
      history.data.orders.map((o) => o.id),
      [payload.id],
    ),
  );
  const guest = await req("orders", "POST", order());
  check("Guest checkout works without an account", () =>
    assert.equal(guest.status, 201),
  );
  const historyAgain = await req("orders", "GET", null, userCookie);
  check("Guest order is not exposed in customer history", () =>
    assert.equal(historyAgain.data.orders.length, 1),
  );
  const cancel = await req(
    "admin/order",
    "PUT",
    { id: payload.id, status: "cancelled" },
    adminCookie,
  );
  const cancelAgain = await req(
    "admin/order",
    "PUT",
    { id: payload.id, status: "cancelled" },
    adminCookie,
  );
  check("Cancellation restores stock only once", () => {
    assert.equal(cancel.status, 200);
    assert.equal(cancelAgain.status, 400);
  });
  const retryCancelled=await req("orders","POST",payload,userCookie);
  check("Idempotent retry preserves the order's updated status and pricing",()=>{
    assert.equal(retryCancelled.status,200);
    assert.equal(retryCancelled.data.status,"cancelled");
    assert.equal(retryCancelled.data.subtotal,598000);
    assert.equal(retryCancelled.data.discount,50000);
    assert.equal(retryCancelled.data.shipping,30000);
  });
  const afterCancel = await req("products");
  check("Cancellation inventory is correct", () =>
    assert.equal(
      afterCancel.data.products.find((p) => p.id === productId).stock,
      4,
    ),
  );
  await req("admin/product", "PUT", { ...original, stock: 1 }, adminCookie);
  const concurrent = await Promise.all([
    req("orders", "POST", order()),
    req("orders", "POST", order()),
  ]);
  check("Concurrent orders cannot oversell the last unit", () =>
    assert.deepEqual(concurrent.map((r) => r.status).sort(), [201, 409]),
  );
  const afterConcurrent = await req("products");
  check("Atomic inventory never goes below zero", () =>
    assert.equal(
      afterConcurrent.data.products.find((p) => p.id === productId).stock,
      0,
    ),
  );
  const hide = await req(
    "admin/product",
    "DELETE",
    { id: productId },
    adminCookie,
  );
  const afterHide = await req("products");
  check("Hidden product is removed from storefront", () => {
    assert.equal(hide.status, 200);
    assert.ok(!afterHide.data.products.some((p) => p.id === productId));
  });
  const consent = await req("newsletter", "POST", {
    email: userEmail,
    consent: false,
  });
  const subscribed = await req("newsletter", "POST", {
    email: userEmail,
    consent: true,
  });
  check("Newsletter requires consent and persists registration", () => {
    assert.equal(consent.status, 400);
    assert.equal(subscribed.status, 200);
  });
  await req("auth/logout", "POST", {}, userCookie);
  const loggedOut = await req("me", "GET", null, userCookie);
  check("Logout invalidates server session", () =>
    assert.equal(loggedOut.data.user, null),
  );
  const setup = await req("setup", "POST", {
    key: "invalid",
    email: "admin@example.invalid",
    name: "QA",
    password,
  });
  check("Admin setup is closed without a valid secret", () =>
    assert.equal(setup.status, 403),
  );
  for (const path of [
    "/",
    "/san-pham",
    "/san-pham/mystery-starter",
    "/gio-hang",
    "/thanh-toan",
    "/tai-khoan",
    "/quan-tri",
    "/admin",
    "/thong-tin/bao-mat",
    "/robots.txt",
    "/sitemap.xml",
    "/hero.svg",
    "/studio/hero-v2.png",
    "/studio/starter.png",
    "/fonts/manrope-400.ttf",
  ]) {
    const r = await fetch(base + path);
    check(`Route ${path} returns 200`, () => assert.equal(r.status, 200));
  }
  console.log(
    `\n${passed} checks passed. Browser rendering is not covered by this suite.`,
  );
} finally {
  const ids = orderIds.map((id) => `'${id}'`).join(",") || "''";
  sql(
    `DELETE FROM order_items WHERE order_id IN (${ids}); DELETE FROM orders WHERE id IN (${ids}); DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE email IN ('${userEmail}','${adminEmail}')); DELETE FROM users WHERE email IN ('${userEmail}','${adminEmail}'); DELETE FROM products WHERE id IN ('${productId}','${productId}-missing'); DELETE FROM coupons WHERE code IN ('${couponCode}','${couponCode}M'); DELETE FROM subscribers WHERE email='${userEmail}';`,
  );
  console.log("Removed only fixtures created by this test run.");
}
