import { createDatabase } from "../lib/database.ts";

let sql = "";
for await (const chunk of process.stdin) {
  sql += chunk;
  if (sql.length > 5_000_000) throw new Error("SQL script is too large.");
}
let database;
try {
  if (!sql.trim()) throw new Error("No SQL supplied.");
  database = createDatabase();
  database.exec(sql);
  console.log(JSON.stringify({ success: true }));
} catch {
  // Do not leak SQL text, fixture credentials, or database rows to logs.
  console.error("Database command failed. No SQL or credentials were logged.");
  process.exitCode = 1;
} finally {
  database?.close();
}
