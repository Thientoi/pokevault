import { createInterface } from "node:readline/promises";
import { readFileSync } from "node:fs";
for (const file of [".env.local", ".env"]) {
  try {
    process.loadEnvFile(file);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
}
const base = process.env.SITE_URL || "http://127.0.0.1:3000";
const url = new URL(base);
if (
  url.protocol !== "https:" &&
  !["127.0.0.1", "localhost"].includes(url.hostname)
)
  throw new Error("Use HTTPS except for loopback development.");
let key = process.env.ADMIN_SETUP_KEY;
if (!key && ["127.0.0.1", "localhost"].includes(url.hostname))
  try {
    key = readFileSync(".env.local", "utf8")
      .match(/^ADMIN_SETUP_KEY=(.+)$/m)?.[1]
      ?.trim()
      .replace(/^['"]|['"]$/g, "");
  } catch {}
if (!key || key.length < 32)
  throw new Error(
    "Set ADMIN_SETUP_KEY (at least 32 random characters) in the server environment or .env.local.",
  );
const rl = createInterface({ input: process.stdin, output: process.stdout });
const name = await rl.question("Admin name: "),
  email = await rl.question("Admin email: ");
rl.close();
// Password is supplied by a hidden OS prompt or environment, never command arguments or logs.
let password = process.env.ADMIN_PASSWORD;
if (!password) {
  process.stdout.write(
    "Admin password (minimum 10 characters, input hidden): ",
  );
  if (!process.stdin.isTTY)
    throw new Error(
      "Use a terminal, or supply ADMIN_PASSWORD via a protected environment.",
    );
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding("utf8");
  password = await new Promise((resolve, reject) => {
    let value = "";
    function onData(chunk) {
      for (const c of chunk) {
        if (c === "\u0003") {
          process.stdin.off("data", onData);
          reject(new Error("Cancelled"));
          return;
        }
        if (c === "\r" || c === "\n") {
          process.stdin.off("data", onData);
          resolve(value);
          return;
        }
        if (c === "\u007f" || c === "\b") value = value.slice(0, -1);
        else if (c >= " ") value += c;
      }
    }
    process.stdin.on("data", onData);
  }).finally(() => {
    process.stdin.setRawMode(false);
    process.stdin.pause();
    process.stdout.write("\n");
  });
}
const response = await fetch(new URL("/api/setup", url), {
  method: "POST",
  headers: { "Content-Type": "application/json", Origin: url.origin },
  body: JSON.stringify({ name, email, password, key }),
});
const data = await response.json();
if (!response.ok) throw new Error(data.error);
console.log(
  "Admin created. Sign in at " +
    url.origin +
    "/tai-khoan. Remove ADMIN_SETUP_KEY from the runtime after setup.",
);
