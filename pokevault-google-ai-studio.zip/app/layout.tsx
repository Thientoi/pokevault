import type { Metadata } from "next";
import "./globals.css";
import "./storefront-v2.css";
import "./collector-edit.css";

export const metadata: Metadata = {
  title: "POKÉVAULT — Mở hộp, mở niềm vui",
  description:
    "Khám phá Mystery Box, thẻ bài và phụ kiện sưu tầm tại POKÉVAULT. Cửa hàng minh họa tiếng Việt.",
  metadataBase: new URL(process.env.APP_URL || "http://localhost:3000"),
  openGraph: {
    title: "POKÉVAULT — Mở hộp, mở niềm vui",
    description: "Một chiếc hộp. Một hành trình khám phá.",
    images: ["/studio/hero-v2.png"],
    locale: "vi_VN",
    type: "website",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className="antialiased">{children}</body>
    </html>
  );
}
