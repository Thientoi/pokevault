"use client";
import { useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  Sparkles,
  ShieldCheck,
  Truck,
  Package,
  Gift,
  Check,
  Zap,
  Heart,
  Minus,
  Plus,
} from "lucide-react";
import { useShop } from "./context";
import { ProductCard, FAQ, Dialog, Loading, ErrorMessage } from "./ui";
import { categories, money } from "../lib/catalog";
import { productImage } from "../lib/product-art";
import { BoxGuide } from "./box-guide";
import { boxBudgets, findBudgetBox } from "../lib/discovery";

const categoryImages = [
  "/products/box-yellow.svg",
  "/products/pack.svg",
  "/products/cards.svg",
  "/products/album.svg",
  "/products/gift.svg",
];
const categoryCopy = [
  "Một chút tò mò",
  "Khui pack, thêm vui",
  "Viết tiếp bộ sưu tập",
  "Nâng niu từng tấm thẻ",
  "Gửi người bạn thương",
];
const tiers = boxBudgets;

export function HomeStudio() {
  const { products, loading, error, refresh } = useShop();
  const [tab, setTab] = useState("featured"),
    [finder, setFinder] = useState(false),
    [tier, setTier] = useState(0);
  const shown =
    tab === "new"
      ? [...products].sort((a, b) => b.createdAt - a.createdAt).slice(0, 4)
      : tab === "best"
        ? [...products]
            .filter((p) => (p.soldCount || 0) > 0)
            .sort((a, b) => (b.soldCount || 0) - (a.soldCount || 0))
            .slice(0, 4)
        : [
            ...products.filter((p) => p.category === "Mystery Box"),
            ...products.filter((p) => p.category !== "Mystery Box"),
          ].slice(0, 4);
  const suggested = findBudgetBox(products, tiers[tier]);
  const heroProduct =
    products.find((p) => p.id === "mystery-starter") ||
    products.find((p) => p.category === "Mystery Box");
  const collectionTabs = [
    ["featured", "Lựa chọn nổi bật"],
    ["new", "Vừa lên kệ"],
    ...(products.some((p) => (p.soldCount || 0) > 0)
      ? [["best", "Bán chạy"]]
      : []),
  ];
  return (
    <div className="collector-home">
      <section className="studio-hero">
        <div className="container studio-hero-grid">
          <div className="studio-hero-copy">
            <div className="studio-kicker">
              <span className="pulse-dot" /> GÓC NHỎ CHO NGƯỜI MÊ SƯU TẦM
            </div>
            <h1>
              Mỗi chiếc hộp.
              <br />
              <span>Một niềm vui mới.</span>
              <Sparkles className="studio-title-spark" size={40} />
            </h1>
            <p>
              Mystery Box, thẻ bài và những món đồ nhỏ làm nên một bộ sưu tập
              mang dấu ấn của bạn.
            </p>
            <div className="studio-hero-actions">
              <Link
                className="button primary studio-primary"
                href="/san-pham?category=Mystery%20Box"
              >
                Khám phá Mystery Box <ArrowUpRight size={20} />
              </Link>
              <button
                className="studio-quiet-button"
                onClick={() => setFinder(true)}
              >
                Tìm chiếc hộp hợp gu <ArrowRight size={17} />
              </button>
            </div>
            <div className="studio-hero-trust">
              <div className="studio-trust-icon">
                <ShieldCheck size={21} />
              </div>
              <div>
                <strong>Bất ngờ bên trong. Rõ ràng bên ngoài.</strong>
                <span>
                  Đọc đầy đủ thông tin trước khi chọn chiếc hộp của bạn.
                </span>
              </div>
            </div>
            <span className="studio-vertical-note">
              BUILT FOR THE JOY OF COLLECTING
            </span>
          </div>
          <div className="studio-hero-art">
            <span className="studio-art-label">
              <Zap size={12} /> THE MYSTERY COLLECTION
            </span>
            <img
              src="/studio/hero-v2.png"
              width="1536"
              height="1024"
              alt="Hình minh họa studio: hộp POKÉVAULT vàng mở ra những tấm thẻ huyền ảo, bên cạnh hộp màu đỏ"
              fetchPriority="high"
            />
            <div className="studio-art-stamp">
              <Sparkles size={18} />
              <span>
                OPEN THE
                <br />
                <b>UNEXPECTED</b>
              </span>
            </div>
            <Link
              href={
                heroProduct
                  ? "/san-pham/" + heroProduct.id
                  : "/san-pham?category=Mystery%20Box"
              }
              className="studio-floating-product"
            >
              <div>
                <span>KHỞI ĐẦU CHO MỘT NIỀM VUI</span>
                <strong>{heroProduct?.name || "Khám phá Mystery Box"}</strong>
                <small>
                  {heroProduct ? money(heroProduct.price) : "Xem bộ sưu tập"}{" "}
                  {heroProduct && <em>· Giá mẫu</em>}
                </small>
              </div>
              <span className="studio-circle-arrow">
                <ArrowUpRight size={24} />
              </span>
            </Link>
            <p className="studio-image-note">
              HÌNH MINH HỌA · KHÔNG CAM KẾT NỘI DUNG TRONG HỘP
            </p>
          </div>
        </div>
      </section>
      <div className="studio-ribbon" aria-hidden="true">
        <span>COLLECT MOMENTS</span>
        <Sparkles />
        <span>OPEN THE UNEXPECTED</span>
        <Sparkles />
        <span>COLLECT JOY</span>
        <Sparkles />
        <span>MAKE IT YOURS</span>
        <Sparkles />
      </div>
      <section className="container studio-section studio-categories-section">
        <div className="studio-section-heading">
          <div>
            <p className="studio-eyebrow">KHÁM PHÁ BỘ SƯU TẬP</p>
            <h2>Bắt đầu từ điều bạn thích.</h2>
          </div>
          <Link href="/san-pham" className="studio-text-link">
            Tất cả sản phẩm <ArrowUpRight size={18} />
          </Link>
        </div>
        <div className="studio-categories">
          {categories.map((category, i) => (
            <Link
              className={"studio-category studio-category-" + i}
              key={category}
              href={"/san-pham?category=" + encodeURIComponent(category)}
            >
              <div className="studio-category-top">
                <span>0{i + 1}</span>
                <ArrowUpRight size={18} />
              </div>
              <div className="studio-category-image">
                <img
                  src={productImage(categoryImages[i])}
                  width="240"
                  height="240"
                  alt=""
                  loading="lazy"
                />
              </div>
              <h3>{category}</h3>
              <p>{categoryCopy[i]}</p>
            </Link>
          ))}
        </div>
      </section>
      <section
        className="container studio-section studio-collection"
        id="bo-suu-tap"
      >
        <div className="studio-section-heading">
          <div>
            <p className="studio-eyebrow">
              THE VAULT EDIT / LỰA CHỌN CỦA CHÚNG MÌNH
            </p>
            <h2>Thêm một điều mới vào bộ sưu tập.</h2>
          </div>
          <Link className="studio-text-link" href="/san-pham">
            Xem bộ sưu tập <ArrowUpRight size={18} />
          </Link>
        </div>
        <div className="studio-collection-tools">
          <div
            className="studio-tabs"
            role="tablist"
            aria-label="Bộ sưu tập sản phẩm"
          >
            {collectionTabs.map(([key, label], index) => (
              <button
                role="tab"
                id={"collection-tab-" + key}
                aria-controls="collection-panel"
                aria-selected={tab === key}
                tabIndex={tab === key ? 0 : -1}
                onKeyDown={(event) => {
                  const next =
                    event.key === "ArrowRight"
                      ? (index + 1) % collectionTabs.length
                      : event.key === "ArrowLeft"
                        ? (index - 1 + collectionTabs.length) %
                          collectionTabs.length
                        : event.key === "Home"
                          ? 0
                          : event.key === "End"
                            ? collectionTabs.length - 1
                            : -1;
                  if (next < 0) return;
                  event.preventDefault();
                  const nextKey = collectionTabs[next][0];
                  setTab(nextKey);
                  document.getElementById("collection-tab-" + nextKey)?.focus();
                }}
                key={key}
                onClick={() => setTab(key)}
                className={tab === key ? "active" : ""}
              >
                {label}
                {key === "new" && <span className="tab-dot" />}
              </button>
            ))}
          </div>
          <span className="studio-sample">
            <span /> Bộ sưu tập minh họa
          </span>
        </div>
        <div
          id="collection-panel"
          role="tabpanel"
          aria-labelledby={"collection-tab-" + tab}
        >
          {loading ? (
            <Loading />
          ) : error ? (
            <>
              <ErrorMessage error={error} />
              <button className="button secondary" onClick={refresh}>
                Thử tải lại
              </button>
            </>
          ) : shown.length ? (
            <div className="product-grid">
              {shown.map((p) => (
                <ProductCard key={p.id} p={p} />
              ))}
            </div>
          ) : (
            <div className="studio-no-sales">
              <Package size={32} />
              <h3>Câu chuyện bán chạy chưa bắt đầu.</h3>
              <p>
                Danh sách sẽ xuất hiện khi có đơn thật đã giao. Chúng mình không
                dùng đơn thử để tạo số liệu bán chạy.
              </p>
              <button
                className="studio-text-link"
                onClick={() => setTab("featured")}
              >
                Khám phá lựa chọn nổi bật <ArrowRight size={17} />
              </button>
            </div>
          )}
        </div>
      </section>
      <BoxGuide />
      <section className="container studio-bento">
        <div className="studio-finder-card">
          <div className="studio-bento-copy">
            <p className="studio-eyebrow">A BOX WITH YOUR NAME ON IT</p>
            <h2>
              Chiếc hộp nào
              <br />
              sinh ra dành cho bạn?
            </h2>
            <p>
              Mới bắt đầu hay đã mê sưu tầm?
              <br />
              Chọn ngân sách, tìm một chút bất ngờ hợp gu.
            </p>
            <button
              className="button studio-lime-button"
              onClick={() => setFinder(true)}
            >
              Tìm hộp của tôi <ArrowUpRight size={18} />
            </button>
          </div>
          <span className="studio-giant-question">?</span>
          <div className="studio-finder-decoration">
            <span>STARTER</span>
            <span>ADVENTURE</span>
            <span>LEGEND</span>
          </div>
        </div>
        <Link
          href="/san-pham?category=Qu%C3%A0%20t%E1%BA%B7ng"
          className="studio-gift-card"
        >
          <div>
            <p className="studio-eyebrow">JUST BECAUSE YOU CARE</p>
            <h2>
              Một chiếc hộp.
              <br />
              Một lời thương.
            </h2>
            <p>Đâu cần dịp đặc biệt để tặng niềm vui.</p>
            <span className="studio-text-link">
              Khám phá quà tặng <ArrowUpRight size={17} />
            </span>
          </div>
          <img
            src="/products/gift.svg"
            width="320"
            height="320"
            alt="Hộp quà POKÉVAULT hồng minh họa"
            loading="lazy"
          />
          <Heart className="gift-heart" size={31} strokeWidth={1.5} />
        </Link>
      </section>
      <section className="studio-story">
        <div className="container studio-story-inner">
          <div className="studio-story-illustration">
            <div className="studio-story-card card-one">
              <img
                src="/products/cards.svg"
                alt="Minh họa bộ thẻ sưu tầm"
                width="360"
                height="360"
                loading="lazy"
              />
            </div>
            <span className="studio-story-badge">
              FOR THE LOVE
              <br />
              <b>OF COLLECTING.</b>
              <Heart size={19} />
            </span>
            <span className="studio-story-note">
              Every collection
              <br />
              tells a story.
            </span>
          </div>
          <div className="studio-story-copy">
            <p className="studio-eyebrow">NOT JUST CARDS. YOUR STORY.</p>
            <h2>
              Có những niềm vui
              <br />
              vừa bằng <span>một tấm thẻ.</span>
            </h2>
            <p>
              Tấm thẻ đầu tiên. Chiếc album đầy dần. Những buổi mở hộp cùng bạn
              bè. Với chúng mình, sưu tầm là lưu giữ những khoảnh khắc như thế.
            </p>
            <p>
              POKÉVAULT là ý tưởng về một góc nhỏ để bạn tìm thấy điều khiến
              mình mỉm cười — và viết tiếp câu chuyện của riêng mình.
            </p>
            <Link className="studio-text-link" href="/thong-tin/gioi-thieu">
              Một chút về POKÉVAULT <ArrowUpRight size={18} />
            </Link>
          </div>
        </div>
      </section>
      <section className="container studio-section studio-faq">
        <div>
          <p className="studio-eyebrow">A FEW THINGS TO KNOW</p>
          <h2>
            Tò mò là tốt.
            <br />
            Hiểu rõ còn tốt hơn.
          </h2>
          <p>
            Một vài câu trả lời trước khi bạn
            <br />
            mở cánh cửa sưu tầm.
          </p>
          <Link className="studio-text-link" href="/thong-tin/faq">
            Xem tất cả câu hỏi <ArrowUpRight size={18} />
          </Link>
        </div>
        <FAQ />
      </section>
      <Dialog
        open={finder}
        onClose={() => setFinder(false)}
        title="Tìm chiếc hộp hợp gu bạn"
      >
        <div className="studio-finder-dialog">
          <p className="muted">Bạn muốn dành bao nhiêu cho một chút bất ngờ?</p>
          <div
            className="studio-budget-options"
            role="group"
            aria-label="Chọn ngân sách"
          >
            {tiers.map((t, i) => (
              <button
                type="button"
                aria-pressed={tier === i}
                className={tier === i ? "selected" : ""}
                key={t.id}
                onClick={() => setTier(i)}
              >
                <span>{t.budget}</span>
                <b>{t.label}</b>
                {tier === i && <Check size={17} />}
              </button>
            ))}
          </div>
          <div aria-live="polite" aria-atomic="true">
            {loading ? (
              <Loading />
            ) : error ? (
              <ErrorMessage error={error} />
            ) : suggested ? (
              <div className="studio-finder-result">
                <img
                  src={productImage(suggested.image)}
                  alt={suggested.name}
                  width="240"
                  height="240"
                />
                <p className="studio-eyebrow">MỘT GỢI Ý DÀNH CHO BẠN</p>
                <h3>{suggested.name}</h3>
                <p>{tiers[tier].description}</p>
                <strong>
                  {money(suggested.price)} <small>· Giá mẫu</small>
                </strong>
                <Link
                  className="button primary full"
                  href={"/san-pham/" + suggested.id}
                  onClick={() => setFinder(false)}
                >
                  Khám phá chiếc hộp này <ArrowUpRight size={18} />
                </Link>
              </div>
            ) : (
              <p className="notice">
                Chưa có Mystery Box còn hàng trong ngân sách này. Hãy chọn một
                mức khác.
              </p>
            )}
          </div>
          <p className="small muted">
            Đây là gợi ý theo ngân sách, không cam kết độ hiếm hoặc giá trị vật
            phẩm bên trong.
          </p>
        </div>
      </Dialog>
    </div>
  );
}
