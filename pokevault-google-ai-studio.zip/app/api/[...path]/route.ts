import { z } from "zod";
import {
  db,
  seed,
  json,
  fail,
  currentUser,
  passwordHash,
  verifyPassword,
  session,
  digest,
  limit,
  config,
} from "../../../lib/server";
import {
  emailSchema,
  passwordSchema,
  loginSchema,
  profileSchema,
  checkoutSchema,
  productSchema,
  totals,
} from "../../../lib/validation";
import { LOCAL_ADMIN_EMAIL, localAdminEnabled } from "../../../lib/local-admin";
import { sameOriginRequest } from "../../../lib/request-origin";
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
const productColumns =
  "id,name,category,price,old_price AS oldPrice,stock,description,image,color,badge,active,created_at AS createdAt";

async function adminOverview() {
  // Bangkok uses UTC+07:00 year-round. Match SQLite's daily grouping to the
  // client's timezone rather than grouping late-night orders in UTC.
  const dayMs = 86400000;
  const bangkokOffset = 7 * 3600000;
  const today = new Date(Date.now() + bangkokOffset).toISOString().slice(0, 10);
  const todayStart = Date.parse(`${today}T00:00:00+07:00`);
  const firstDayStart = todayStart - 13 * dayMs;
  const database = db();
  // Read the dashboard in one consistent database batch; headline statistics
  // cover all rows even though the management lists are intentionally bounded.
  const results = await database.batch([
    database.prepare(`SELECT ${productColumns} FROM products ORDER BY created_at DESC`),
    database.prepare("SELECT id,name,phone,address,note,subtotal,shipping,discount,total,shipping_method AS shippingMethod,status,demo,created_at AS createdAt FROM orders ORDER BY created_at DESC LIMIT 200"),
    database.prepare("SELECT order_id AS orderId,name,price,quantity FROM order_items WHERE order_id IN (SELECT id FROM orders ORDER BY created_at DESC LIMIT 200)"),
    database.prepare("SELECT * FROM coupons ORDER BY code"),
    database.prepare(`SELECT u.id,u.name,u.email,u.phone,u.address,
      COUNT(o.id) AS orderCount,
      COALESCE(SUM(CASE WHEN o.demo=0 AND o.status='delivered' THEN o.total ELSE 0 END),0) AS totalSpent,
      MAX(o.created_at) AS lastOrderAt
      FROM users u LEFT JOIN orders o ON o.user_id=u.id
      WHERE u.role='customer' GROUP BY u.id
      ORDER BY COALESCE(MAX(o.created_at),0) DESC,u.name COLLATE NOCASE LIMIT 500`),
    database.prepare(`SELECT COUNT(*) AS totalOrders,
      COALESCE(SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END),0) AS pendingOrders,
      COALESCE(SUM(CASE WHEN demo=1 THEN 1 ELSE 0 END),0) AS demoOrders,
      COALESCE(SUM(CASE WHEN demo=0 AND status='delivered' THEN total ELSE 0 END),0) AS deliveredValue,
      (SELECT COUNT(*) FROM products WHERE active=1) AS activeProducts,
      (SELECT COUNT(*) FROM products WHERE active=1 AND stock<=5) AS lowStockProducts,
      (SELECT COUNT(*) FROM users WHERE role='customer') AS customerCount
      FROM orders`),
    database.prepare(`SELECT date(created_at/1000,'unixepoch','+7 hours') AS day,
      SUM(CASE WHEN demo=0 THEN 1 ELSE 0 END) AS liveOrders,
      SUM(CASE WHEN demo=1 THEN 1 ELSE 0 END) AS demoOrders
      FROM orders WHERE created_at>=? AND created_at<? GROUP BY day ORDER BY day`)
      .bind(firstDayStart, todayStart + dayMs),
  ]);
  const recordedDays = new Map(results[6].results.map((row: any) => [row.day, row]));
  const dailyOrders = Array.from({ length: 14 }, (_, index) => {
    const day = new Date(firstDayStart + index * dayMs + bangkokOffset).toISOString().slice(0, 10);
    const recorded: any = recordedDays.get(day);
    return { day, liveOrders: recorded?.liveOrders || 0, demoOrders: recorded?.demoOrders || 0 };
  });
  const setupKey = config().ADMIN_SETUP_KEY;
  return {
    products: results[0].results,
    orders: results[1].results,
    orderItems: results[2].results,
    coupons: results[3].results,
    customers: results[4].results,
    summary: results[5].results[0],
    dailyOrders,
    settings: {
      demoMode: config().COMMERCE_LIVE !== "true",
      emailConnected: false,
      shippingConnected: false,
      paymentsConnected: false,
      // An authenticated admin already exists, so initial setup is closed.
      adminSetupEnabled: false,
      adminSetupKeyConfigured: !!setupKey && setupKey.length >= 32 && !setupKey.startsWith("replace-with-"),
    },
    scope: { ordersLimit: 200, customersLimit: 500, timezone: "Asia/Bangkok" },
  };
}

async function coupon(code: string) {
  if (!code) return null;
  const c = await db()
    .prepare("SELECT * FROM coupons WHERE code=? AND active=1")
    .bind(code.toUpperCase())
    .first<{ percent: number; maximum: number }>();
  if (!c) fail("Mã ưu đãi không tồn tại hoặc đã ngừng áp dụng.");
  return c;
}
async function handle(req: Request) {
  try {
    const url = new URL(req.url),
      path = url.pathname.replace(/^\/api\//, ""),
      method = req.method;
    if (method !== "GET") {
      if (!sameOriginRequest(req, process.env.APP_URL))
        fail("Yêu cầu không hợp lệ. Vui lòng tải lại trang.", 403);
      if (!req.headers.get("content-type")?.startsWith("application/json"))
        fail("Định dạng yêu cầu không hợp lệ.", 415);
    }
    const raw = method === "GET" ? "" : await req.text();
    if (raw.length > 30000) fail("Nội dung quá dài.", 413);
    let body: any = {};
    if (raw) {
      try {
        body = JSON.parse(raw);
      } catch {
        fail("Dữ liệu JSON không hợp lệ.");
      }
    }
    if (path === "products" && method === "GET") {
      await seed();
      const products = (
        await db()
          .prepare(
            `SELECT ${productColumns}, (SELECT COALESCE(SUM(oi.quantity),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=products.id AND o.status='delivered' AND o.demo=0) AS soldCount FROM products WHERE active=1 ORDER BY created_at`,
          )
          .all()
      ).results;
      return json({ products, demo: config().COMMERCE_LIVE !== "true" });
    }
    if (path === "me" && method === "GET")
      return json({ user: await currentUser(req) });
    if (path === "auth/register" && method === "POST") {
      await limit(req, "auth");
      const p = z
        .object({
          name: z.string().trim().min(2).max(100),
          email: emailSchema,
          password: passwordSchema,
        })
        .parse(body);
      const id = crypto.randomUUID();
      try {
        await db()
          .prepare("INSERT INTO users(id,email,name,password) VALUES(?,?,?,?)")
          .bind(id, p.email, p.name, await passwordHash(p.password))
          .run();
      } catch (e) {
        if (String(e).includes("UNIQUE"))
          fail("Email đã được sử dụng. Vui lòng đăng nhập.");
        throw e;
      }
      return json({ ok: true }, 201, { "Set-Cookie": await session(id, req) });
    }
    if (path === "auth/login" && method === "POST") {
      await limit(req, "auth");
      const localEnabled = localAdminEnabled(url, config());
      const p = loginSchema(localEnabled).parse(body);
      const isLocalAlias = p.email === "admin";
      const email = isLocalAlias ? LOCAL_ADMIN_EMAIL : p.email;
      const u = await db()
        .prepare("SELECT id,password,role FROM users WHERE email=?")
        .bind(email)
        .first<{ id: string; password: string; role: string }>();
      const valid = await verifyPassword(
        p.password,
        u?.password || "00000000000000000000000000000000:" + "0".repeat(64),
      );
      if (!u || !valid || (isLocalAlias && u.role !== "admin") ||
        (email === LOCAL_ADMIN_EMAIL && !localEnabled))
        fail("Tài khoản hoặc mật khẩu chưa đúng.", 401);
      return json({ ok: true }, 200, {
        "Set-Cookie": await session(u.id, req),
      });
    }
    if (path === "auth/logout" && method === "POST") {
      const token = req.headers
        .get("cookie")
        ?.match(/(?:^|;\s*)pv_session=([^;]+)/)?.[1];
      if (token)
        await db()
          .prepare("DELETE FROM sessions WHERE token=?")
          .bind(await digest(token))
          .run();
      return json({ ok: true }, 200, {
        "Set-Cookie": `pv_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${url.protocol === "https:" ? "; Secure" : ""}`,
      });
    }
    if (path === "setup" && method === "POST") {
      await limit(req, "setup", 5);
      const key = config().ADMIN_SETUP_KEY;
      if (
        !key ||
        key.length < 32 ||
        key.startsWith("replace-with-") ||
        typeof body.key !== "string" ||
        (await digest(body.key)) !== (await digest(key))
      )
        fail("Khóa thiết lập quản trị không hợp lệ hoặc chưa cấu hình.", 403);
      const p = z
        .object({
          name: z.string().min(2).max(100),
          email: emailSchema,
          password: passwordSchema,
        })
        .parse(body);
      const id = crypto.randomUUID();
      const r = await db()
        .prepare(
          "INSERT INTO users(id,email,name,password,role) SELECT ?,?,?,?,'admin' WHERE NOT EXISTS (SELECT 1 FROM users WHERE role='admin')",
        )
        .bind(id, p.email, p.name, await passwordHash(p.password))
        .run();
      if (!r.meta.changes) fail("Quản trị viên đã được thiết lập.", 409);
      await seed();
      return json({ ok: true }, 201);
    }
    if (path === "newsletter" && method === "POST") {
      await limit(req, "newsletter", 5);
      const email = emailSchema.parse(body.email);
      if (body.consent !== true) fail("Vui lòng đồng ý nhận email.");
      await db()
        .prepare(
          "INSERT OR IGNORE INTO subscribers(email,created_at) VALUES(?,?)",
        )
        .bind(email, Date.now())
        .run();
      return json({
        message:
          "Đã lưu đăng ký. Email bản tin sẽ được gửi sau khi cửa hàng kết nối dịch vụ email.",
      });
    }
    if (path === "coupon" && method === "POST") {
      await limit(req, "coupon", 30);
      const code = z
        .string()
        .trim()
        .min(1)
        .max(30)
        .parse(body.code)
        .toUpperCase();
      return json({ code, ...(await coupon(code)) });
    }
    if (path === "orders" && method === "POST") {
      await limit(req, "order", 15);
      const p = checkoutSchema.parse(body);
      if (new Set(p.items.map((i) => i.id)).size !== p.items.length)
        fail("Sản phẩm trong giỏ bị trùng.");
      const user = await currentUser(req),
        fingerprint = await digest(
          JSON.stringify({ ...p, userId: user?.id || null }),
        );
      const existing = await db()
        .prepare("SELECT id,subtotal,shipping,discount,total,demo,status,fingerprint FROM orders WHERE id=?")
        .bind(p.id)
        .first<any>();
      if (existing) {
        if (existing.fingerprint !== fingerprint)
          fail("Mã yêu cầu đã được sử dụng.", 409);
        return json({
          id: existing.id,
          subtotal: existing.subtotal,
          shipping: existing.shipping,
          discount: existing.discount,
          total: existing.total,
          demo: !!existing.demo,
          status: existing.status,
        });
      }
      await seed();
      const lines = [];
      for (const item of p.items) {
        const product = await db()
          .prepare("SELECT * FROM products WHERE id=? AND active=1")
          .bind(item.id)
          .first<any>();
        if (!product || product.stock < item.quantity)
          fail(
            "Một sản phẩm đã hết hàng hoặc không đủ số lượng. Vui lòng cập nhật giỏ hàng.",
            409,
          );
        lines.push({ ...item, product });
      }
      const c = await coupon(p.coupon),
        t = totals(
          lines.reduce((s, l) => s + l.product.price * l.quantity, 0),
          p.shippingMethod,
          c?.percent,
          c?.maximum,
        ),
        demo = config().COMMERCE_LIVE !== "true";
      const batch = [
        db()
          .prepare(
            "INSERT INTO orders(id,user_id,name,phone,address,note,shipping_method,subtotal,shipping,discount,total,status,payment,demo,created_at,fingerprint) VALUES(?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?,?)",
          )
          .bind(
            p.id,
            user?.id || null,
            p.name,
            p.phone,
            p.address,
            p.note,
            p.shippingMethod,
            t.subtotal,
            t.shipping,
            t.discount,
            t.total,
            p.payment,
            demo ? 1 : 0,
            Date.now(),
            fingerprint,
          ),
      ];
      for (const l of lines) {
        // A concurrent price/visibility change forces the CHECK constraint to fail and rolls back the whole batch.
        batch.push(
          db()
            .prepare(
              "UPDATE products SET stock=CASE WHEN active=1 AND price=? THEN stock-? ELSE -1 END WHERE id=?",
            )
            .bind(l.product.price, l.quantity, l.id),
        );
        batch.push(
          db()
            .prepare(
              "INSERT INTO order_items(id,order_id,product_id,name,price,quantity,image) VALUES(?,?,?,?,?,?,?)",
            )
            .bind(
              crypto.randomUUID(),
              p.id,
              l.id,
              l.product.name,
              l.product.price,
              l.quantity,
              l.product.image,
            ),
        );
      }
      try {
        await db().batch(batch);
      } catch (e) {
        if (/constraint|UNIQUE/i.test(String(e)))
          fail(
            "Tồn kho hoặc giá vừa thay đổi. Vui lòng kiểm tra lại giỏ hàng.",
            409,
          );
        throw e;
      }
      return json({ id: p.id, ...t, demo, status: "pending" }, 201);
    }
    const user = await currentUser(req);
    if (!user) fail("Vui lòng đăng nhập để tiếp tục.", 401);
    if (path === "profile" && method === "PUT") {
      const p = profileSchema.parse(body);
      await db()
        .prepare("UPDATE users SET name=?,phone=?,address=? WHERE id=?")
        .bind(p.name, p.phone, p.address, user.id)
        .run();
      return json({ ok: true });
    }
    if (path === "orders" && method === "GET") {
      const list = (
        await db()
          .prepare(
            "SELECT id,status,total,demo,created_at AS createdAt FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT 100",
          )
          .bind(user.id)
          .all()
      ).results;
      return json({ orders: list });
    }
    if (path.startsWith("admin/")) {
      if (user.role !== "admin") fail("Bạn không có quyền quản trị.", 403);
      if (path === "admin/overview" && method === "GET")
        return json(await adminOverview());
      if (path === "admin/product" && (method === "POST" || method === "PUT")) {
        const p = productSchema.parse(body);
        if (method === "POST") {
          const created = await db()
            .prepare(
              "INSERT INTO products(id,name,category,price,old_price,stock,description,image,color,badge,active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING",
            )
            .bind(p.id,p.name,p.category,p.price,p.oldPrice,p.stock,p.description,p.image,p.color,p.badge,p.active,Date.now())
            .run();
          if (!created.meta.changes)
            fail("Mã sản phẩm đã tồn tại. Hãy chọn mã khác hoặc chỉnh sửa sản phẩm hiện có.", 409);
          return json({ ok: true }, 201);
        }
        const updated = await db()
          .prepare("UPDATE products SET name=?,category=?,price=?,old_price=?,stock=?,description=?,image=?,color=?,badge=?,active=? WHERE id=?")
          .bind(p.name,p.category,p.price,p.oldPrice,p.stock,p.description,p.image,p.color,p.badge,p.active,p.id)
          .run();
        if (!updated.meta.changes) fail("Không tìm thấy sản phẩm cần chỉnh sửa.", 404);
        return json({ ok: true });
      }
      if (path === "admin/products" && method === "PATCH") {
        const p = z.object({
          id: z.string().regex(/^[a-z0-9-]{1,80}$/),
          active: z.union([z.literal(0), z.literal(1)]),
        }).strict().parse(body);
        // Visibility never writes a stale product snapshot back over live stock.
        const updated = await db().prepare("UPDATE products SET active=? WHERE id=?")
          .bind(p.active, p.id).run();
        if (!updated.meta.changes) fail("Không tìm thấy sản phẩm.", 404);
        return json({ ok: true });
      }
      if (path === "admin/product" && method === "DELETE") {
        const id = z.string().min(1).max(100).parse(body.id);
        await db()
          .prepare("UPDATE products SET active=0 WHERE id=?")
          .bind(id)
          .run();
        return json({ ok: true });
      }
      if (path === "admin/order" && method === "PUT") {
        const p = z
          .object({
            id: z.string().uuid(),
            status: z.enum([
              "pending",
              "confirmed",
              "shipping",
              "delivered",
              "cancelled",
            ]),
          })
          .parse(body);
        const old = await db()
          .prepare("SELECT status FROM orders WHERE id=?")
          .bind(p.id)
          .first<{ status: string }>();
        if (!old) fail("Không tìm thấy đơn hàng.", 404);
        const allowed: Record<string, string[]> = {
          pending: ["confirmed", "cancelled"],
          confirmed: ["shipping", "cancelled"],
          shipping: ["delivered"],
          delivered: [],
          cancelled: [],
        };
        if (!allowed[old.status]?.includes(p.status))
          fail("Chuyển trạng thái không hợp lệ.");
        const items = (
          await db()
            .prepare(
              "SELECT product_id,quantity FROM order_items WHERE order_id=?",
            )
            .bind(p.id)
            .all<any>()
        ).results;
        const batch = [];
        if (p.status === "cancelled")
          for (const i of items)
            batch.push(
              db()
                .prepare(
                  "UPDATE products SET stock=stock+? WHERE id=? AND EXISTS(SELECT 1 FROM orders WHERE id=? AND status=?)",
                )
                .bind(i.quantity, i.product_id, p.id, old.status),
            );
        batch.push(
          db()
            .prepare("UPDATE orders SET status=? WHERE id=? AND status=?")
            .bind(p.status, p.id, old.status),
        );
        const updated = await db().batch(batch);
        if (!updated[updated.length - 1].meta.changes)
          fail("Trạng thái đơn vừa được thay đổi bởi phiên khác. Vui lòng tải lại.", 409);
        return json({ ok: true });
      }
      if (path === "admin/coupon" && (method === "POST" || method === "PUT")) {
        const c = z
          .object({
            code: z.string().regex(/^[A-Z0-9]{3,20}$/),
            percent: z.number().int().min(1).max(50),
            maximum: z.number().int().min(1000).max(1000000),
            active: z.number().int().min(0).max(1),
          })
          .parse(body);
        if (method === "POST") {
          const created = await db()
            .prepare("INSERT INTO coupons(code,percent,maximum,active) VALUES(?,?,?,?) ON CONFLICT(code) DO NOTHING")
            .bind(c.code, c.percent, c.maximum, c.active).run();
          if (!created.meta.changes) fail("Mã ưu đãi đã tồn tại. Hãy chọn mã khác hoặc chỉnh sửa mã hiện có.", 409);
          return json({ ok: true }, 201);
        }
        const updated = await db()
          .prepare("UPDATE coupons SET percent=?,maximum=?,active=? WHERE code=?")
          .bind(c.percent,c.maximum,c.active,c.code).run();
        if (!updated.meta.changes) fail("Không tìm thấy mã ưu đãi cần chỉnh sửa.", 404);
        return json({ ok: true });
      }
    }
    return json({ error: "Không tìm thấy chức năng này." }, 404);
  } catch (e: any) {
    if (e instanceof z.ZodError)
      return json(
        { error: e.issues[0]?.message || "Dữ liệu không hợp lệ." },
        400,
      );
    const status = e.status || 500;
    if (status === 500) console.error("API error", e.message);
    return json(
      {
        error:
          status === 500
            ? "Dịch vụ đang tạm gián đoạn. Vui lòng thử lại sau."
            : e.message,
      },
      status,
    );
  }
}
export const GET = handle;
export const POST = handle;
export const PUT = handle;
export const PATCH = handle;
export const DELETE = handle;
