"use client";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import Link from "next/link";
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  Users,
  TicketPercent,
  Settings,
  ArrowUpRight,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Search,
  Plus,
  Pencil,
  EyeOff,
  Eye,
  LogOut,
  Menu,
  X,
  Bell,
  RefreshCw,
  Download,
  Clock3,
  Check,
  ShieldCheck,
  Zap,
  Banknote,
  Mail,
  Truck,
  CreditCard,
  LockKeyhole,
  ExternalLink,
  ArrowLeft,
  AlertCircle,
} from "lucide-react";
import { useShop, api } from "./context";
import {
  categories,
  money,
  normalize,
  seedProducts,
  type Product,
} from "../lib/catalog";
import { productImage } from "../lib/product-art";
import { Dialog, ErrorMessage, Loading } from "./ui";
import "./admin.css";

type Tab =
  | "overview"
  | "products"
  | "orders"
  | "customers"
  | "coupons"
  | "settings";
type Order = {
  id: string;
  name: string;
  phone: string;
  address: string;
  note: string;
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  shippingMethod: string;
  status: string;
  demo: number;
  createdAt: number;
};
type Coupon = {
  code: string;
  percent: number;
  maximum: number;
  active: number;
};
type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  orderCount: number;
  totalSpent: number;
  lastOrderAt: number | null;
};
type Dashboard = {
  products: Product[];
  orders: Order[];
  orderItems: {
    orderId: string;
    name: string;
    price: number;
    quantity: number;
  }[];
  coupons: Coupon[];
  customers: Customer[];
  summary: {
    totalOrders: number;
    pendingOrders: number;
    demoOrders: number;
    deliveredValue: number;
    activeProducts: number;
    lowStockProducts: number;
    customerCount: number;
  };
  dailyOrders: { day: string; liveOrders: number; demoOrders: number }[];
  settings: {
    demoMode: boolean;
    emailConnected: boolean;
    shippingConnected: boolean;
    paymentsConnected: boolean;
    adminSetupEnabled: boolean;
    adminSetupKeyConfigured: boolean;
  };
  scope: { ordersLimit: number; customersLimit: number; timezone: string };
};
const statusNames: Record<string, string> = {
  pending: "Chờ xác nhận",
  confirmed: "Đã xác nhận",
  shipping: "Đang giao",
  delivered: "Đã giao",
  cancelled: "Đã hủy",
};
const transitions: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["shipping", "cancelled"],
  shipping: ["delivered"],
  delivered: [],
  cancelled: [],
};
const navigation = [
  { id: "overview" as Tab, label: "Tổng quan", icon: LayoutDashboard },
  { id: "orders" as Tab, label: "Đơn hàng", icon: ShoppingBag },
  { id: "products" as Tab, label: "Sản phẩm", icon: Package },
  { id: "customers" as Tab, label: "Khách hàng", icon: Users },
  { id: "coupons" as Tab, label: "Mã ưu đãi", icon: TicketPercent },
  { id: "settings" as Tab, label: "Thiết lập", icon: Settings },
];
const blank: Product = {
  id: "",
  name: "",
  category: "Mystery Box",
  price: 299000,
  oldPrice: 0,
  stock: 0,
  description: "",
  image: "/products/box-yellow.svg",
  color: "yellow",
  badge: "",
  active: 1,
  createdAt: 0,
};
const blankCoupon: Coupon = {
  code: "",
  percent: 10,
  maximum: 50000,
  active: 1,
};
const date = (n: number) =>
  new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    timeZone: "Asia/Bangkok",
  }).format(n);
const time = (n: number) =>
  new Intl.DateTimeFormat("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Bangkok",
  }).format(n);
function Brand() {
  return (
    <Link href="/" className="adm-brand">
      <span>
        <Zap size={21} fill="currentColor" />
      </span>
      POKÉ<b>VAULT</b>
    </Link>
  );
}
function Status({ value }: { value: string }) {
  return (
    <span className={"adm-status adm-status-" + value}>
      <i />
      {statusNames[value] || value}
    </span>
  );
}
function exportCsv(
  filename: string,
  headers: string[],
  rows: (string | number)[][],
) {
  const cell = (value: string | number) => {
    let s = String(value ?? "");
    if (/^[\s]*[=+@-]/.test(s) || /^[\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  };
  const text =
    "\ufeff" +
    [headers, ...rows].map((row) => row.map(cell).join(",")).join("\r\n");
  const url = URL.createObjectURL(
    new Blob([text], { type: "text/csv;charset=utf-8;" }),
  );
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function Pager({
  page,
  total,
  onChange,
}: {
  page: number;
  total: number;
  onChange: (n: number) => void;
}) {
  const pages = Math.max(1, Math.ceil(total / 8));
  return (
    <div className="adm-pager">
      <span>
        {total
          ? `${(page - 1) * 8 + 1}–${Math.min(page * 8, total)} trong ${total}`
          : "Chưa có dữ liệu"}
      </span>
      <div>
        <button
          aria-label="Trang trước"
          disabled={page <= 1}
          onClick={() => onChange(page - 1)}
        >
          <ChevronLeft size={17} />
        </button>
        <span>
          Trang {page} / {pages}
        </span>
        <button
          aria-label="Trang sau"
          disabled={page >= pages}
          onClick={() => onChange(page + 1)}
        >
          <ChevronRight size={17} />
        </button>
      </div>
    </div>
  );
}
function EmptyAdmin({ title, text }: { title: string; text: string }) {
  return (
    <div className="adm-empty">
      <Package size={32} strokeWidth={1.4} />
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}

export function Admin() {
  const { user, authLoading, refresh, refreshUser, notify } = useShop();
  const [tab, setTab] = useState<Tab>("overview"),
    [data, setData] = useState<Dashboard | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [refreshing, setRefreshing] = useState(false),
    [mobile, setMobile] = useState(false),
    [alerts, setAlerts] = useState(false),
    [query, setQuery] = useState(""),
    [filter, setFilter] = useState("all"),
    [page, setPage] = useState(1),
    [editing, setEditing] = useState<Product | null>(null),
    [newProduct, setNewProduct] = useState(false),
    [formError, setFormError] = useState(""),
    [hideProduct, setHideProduct] = useState<Product | null>(null),
    [selectedOrder, setSelectedOrder] = useState<Order | null>(null),
    [orderChange, setOrderChange] = useState<{
      order: Order;
      status: string;
    } | null>(null),
    [newCoupon, setNewCoupon] = useState(false),
    [couponEdit, setCouponEdit] = useState<Coupon | null>(null),
    [customerView, setCustomerView] = useState<Customer | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const load = useCallback(async () => {
    setRefreshing(true);
    try {
      setData(await api("admin/overview"));
      setError("");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setRefreshing(false);
    }
  }, []);
  useEffect(() => {
    if (user?.role === "admin") load();
  }, [user?.id, user?.role, load]);
  useEffect(() => {
    setPage(1);
  }, [query, filter, tab]);
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.key === "Escape") {
        setMobile(false);
        setAlerts(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);
  function switchTab(next: Tab) {
    setTab(next);
    setQuery("");
    setFilter("all");
    setMobile(false);
    setAlerts(false);
  }
  async function mutate(path: string, method: string, body: unknown) {
    setBusy(true);
    setFormError("");
    try {
      await api(path, method, body);
      await load();
      await refresh();
      return true;
    } catch (e) {
      const message = (e as Error).message;
      setFormError(message);
      notify(message);
      return false;
    } finally {
      setBusy(false);
    }
  }
  const q = normalize(query.trim());
  const filteredProducts = (data?.products || []).filter(
    (p) =>
      (!q || normalize(p.name + " " + p.id + " " + p.category).includes(q)) &&
      (filter === "all" ||
        (filter === "active" && p.active === 1) ||
        (filter === "hidden" && !p.active) ||
        (filter === "low" && p.active === 1 && p.stock <= 5) ||
        (categories.includes(filter) && p.category === filter)),
  );
  const filteredOrders = (data?.orders || []).filter(
    (o) =>
      (!q || normalize(o.id + " " + o.name + " " + o.phone).includes(q)) &&
      (filter === "all" ||
        (filter === "demo" && !!o.demo) ||
        (filter === "live" && !o.demo) ||
        filter === o.status),
  );
  const filteredCustomers = (data?.customers || []).filter(
    (c) => !q || normalize(c.name + " " + c.email + " " + c.phone).includes(q),
  );
  const filteredCoupons = (data?.coupons || []).filter(
    (c) =>
      (!q || normalize(c.code).includes(q)) &&
      (filter === "all" ||
        (filter === "active" && !!c.active) ||
        (filter === "hidden" && !c.active)),
  );
  const filteredTotal =
    tab === "products"
      ? filteredProducts.length
      : tab === "orders"
        ? filteredOrders.length
        : tab === "customers"
          ? filteredCustomers.length
          : 0;
  useEffect(() => {
    setPage((current) =>
      Math.min(current, Math.max(1, Math.ceil(filteredTotal / 8))),
    );
  }, [filteredTotal]);
  if (authLoading)
    return (
      <div className="adm-root">
        <Loading />
      </div>
    );
  if (!user || user.role !== "admin") return <AdminAccess />;
  const summary = data?.summary,
    lowStock = (data?.products || []).filter((p) => p.active && p.stock <= 5),
    title = navigation.find((n) => n.id === tab)?.label || "Tổng quan";
  const recent = data?.orders.slice(0, 5) || [];
  const chartTotal =
    data?.dailyOrders.reduce((s, d) => s + d.liveOrders + d.demoOrders, 0) || 0;
  const chartMax = Math.max(
    1,
    ...(data?.dailyOrders || []).map((d) =>
      Math.max(d.liveOrders, d.demoOrders),
    ),
  );
  function orderTable(rows: Order[], compact = false) {
    return (
      <div className="adm-table-wrap">
        <table className="adm-table">
          <thead>
            <tr>
              <th>Đơn hàng</th>
              <th>Khách hàng</th>
              <th>Trạng thái</th>
              <th>Tổng tiền</th>
              {!compact && <th>Ngày đặt</th>}
              <th aria-label="Chi tiết" />
            </tr>
          </thead>
          <tbody>
            {rows.map((o) => (
              <tr key={o.id}>
                <td>
                  <button
                    className="adm-row-link"
                    onClick={() => setSelectedOrder(o)}
                  >
                    #{o.id.slice(0, 8).toUpperCase()}
                  </button>
                  {!!o.demo && <small className="adm-demo-tag">Đơn thử</small>}
                </td>
                <td>
                  <div className="adm-person-cell">
                    <span className="adm-avatar small">
                      {o.name
                        .split(" ")
                        .slice(-2)
                        .map((w) => w[0])
                        .join("")
                        .toUpperCase()}
                    </span>
                    <div>
                      <b>{o.name}</b>
                      <small>{o.phone}</small>
                    </div>
                  </div>
                </td>
                <td>
                  <Status value={o.status} />
                </td>
                <td>
                  <b>{money(o.total)}</b>
                </td>
                {!compact && (
                  <td>
                    {date(o.createdAt)}
                    <small className="adm-cell-sub">{time(o.createdAt)}</small>
                  </td>
                )}
                <td>
                  <button
                    className="adm-icon"
                    onClick={() => setSelectedOrder(o)}
                    aria-label={"Xem đơn " + o.id}
                  >
                    <ArrowUpRight size={17} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!rows.length && (
          <EmptyAdmin
            title="Chưa có đơn hàng phù hợp"
            text="Đơn đặt từ cửa hàng sẽ xuất hiện ở đây. Bạn có thể thử bỏ bộ lọc."
          />
        )}
      </div>
    );
  }
  return (
    <div className="adm-root">
      {mobile && (
        <button
          className="adm-mobile-overlay"
          onClick={() => setMobile(false)}
          aria-label="Đóng menu"
        />
      )}
      <aside className={"adm-sidebar " + (mobile ? "open" : "")}>
        <div className="adm-sidebar-brand">
          <Brand />
          <button
            className="adm-icon adm-mobile-close"
            onClick={() => setMobile(false)}
            aria-label="Đóng menu"
          >
            <X size={20} />
          </button>
        </div>
        <div className="adm-store-badge">
          <span className="adm-store-avatar">
            <ShoppingBag size={19} />
          </span>
          <div>
            <b>POKÉVAULT Store</b>
            <small>
              <i /> Cửa hàng của bạn
            </small>
          </div>
        </div>
        <p className="adm-nav-label">KHÔNG GIAN QUẢN LÝ</p>
        <nav aria-label="Quản trị cửa hàng">
          {navigation.map((n) => (
            <button
              key={n.id}
              className={tab === n.id ? "active" : ""}
              onClick={() => switchTab(n.id)}
              aria-current={tab === n.id ? "page" : undefined}
            >
              <n.icon size={19} strokeWidth={1.7} />
              <span>{n.label}</span>
              {n.id === "orders" && !!summary?.pendingOrders && (
                <b className="adm-nav-count">{summary.pendingOrders}</b>
              )}
            </button>
          ))}
        </nav>
        <div className="adm-sidebar-bottom">
          <div className="adm-sidebar-tip">
            <SparkleMark />
            <b>Cho niềm vui sưu tầm.</b>
            <p>Mỗi chiếc hộp đều bắt đầu từ sự chăm chút của bạn.</p>
            <Link href="/" target="_blank">
              Xem cửa hàng <ArrowUpRight size={15} />
            </Link>
          </div>
          <button
            className="adm-user"
            onClick={async () => {
              try {
                await api("auth/logout", "POST", {});
                await refreshUser();
              } catch (e) {
                notify((e as Error).message);
              }
            }}
            title="Đăng xuất"
          >
            <span className="adm-avatar">{user.name[0]?.toUpperCase()}</span>
            <span>
              <b>{user.name}</b>
              <small>Quản trị viên</small>
            </span>
            <LogOut size={17} />
          </button>
        </div>
      </aside>
      <div className="adm-workspace">
        <header className="adm-topbar">
          <div className="adm-topbar-location">
            <button
              className="adm-icon adm-mobile-toggle"
              onClick={() => setMobile(true)}
              aria-label="Mở menu quản trị"
            >
              <Menu size={21} />
            </button>
            <span>Cửa hàng</span>
            <ChevronRight size={14} />
            <b>{title}</b>
          </div>
          <form
            className="adm-global-search"
            onSubmit={(e) => {
              e.preventDefault();
              if (tab === "overview" || tab === "settings") {
                setTab("products");
                setFilter("all");
              }
            }}
          >
            <Search size={17} />
            <input
              ref={searchRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Tìm trong cửa hàng…"
              aria-label="Tìm kiếm trong quản trị"
            />
            <kbd>Ctrl K</kbd>
          </form>
          <div className="adm-topbar-actions">
            <Link href="/" className="adm-view-store" target="_blank">
              Xem cửa hàng <ExternalLink size={14} />
            </Link>
            <div className="adm-notifications">
              <button
                className="adm-icon"
                aria-label="Thông báo cần xử lý"
                aria-expanded={alerts}
                onClick={() => setAlerts(!alerts)}
              >
                <Bell size={19} />
                {!!(
                  (summary?.pendingOrders || 0) +
                  (summary?.lowStockProducts || 0)
                ) && <i />}
              </button>
              {alerts && (
                <div className="adm-alert-popover">
                  <b>Cần bạn chú ý</b>
                  <button
                    onClick={() => {
                      switchTab("orders");
                      setFilter("pending");
                    }}
                  >
                    <Clock3 size={17} />
                    {summary?.pendingOrders || 0} đơn chờ xác nhận{" "}
                    <ArrowRight size={15} />
                  </button>
                  <button
                    onClick={() => {
                      switchTab("products");
                      setFilter("low");
                    }}
                  >
                    <Package size={17} />
                    {summary?.lowStockProducts || 0} sản phẩm sắp hết{" "}
                    <ArrowRight size={15} />
                  </button>
                </div>
              )}
            </div>
            <span className="adm-avatar small">
              {user.name[0]?.toUpperCase()}
            </span>
          </div>
        </header>
        <div className="adm-content">
          <div className="adm-page-heading">
            <div>
              <p className="adm-overline">POKÉVAULT BUSINESS SPACE</p>
              <h1>
                {tab === "overview" ? "Chào bạn, một ngày tốt lành." : title}
              </h1>
              <p>
                {
                  {
                    overview:
                      "Mọi điều cần biết về cửa hàng của bạn, trong một góc nhìn.",
                    products:
                      "Chăm chút bộ sưu tập — từ hình ảnh đến từng mức tồn kho.",
                    orders:
                      "Theo dõi, xác nhận và quản lý hành trình của mỗi chiếc hộp.",
                    customers:
                      "Những người cùng bạn viết tiếp câu chuyện sưu tầm.",
                    coupons: "Một lý do nhỏ để niềm vui đến gần hơn.",
                    settings:
                      "Thông tin vận hành và trạng thái các dịch vụ kết nối.",
                  }[tab]
                }
              </p>
            </div>
            <div className="adm-heading-actions">
              <button
                className="adm-button"
                onClick={load}
                disabled={refreshing}
              >
                <RefreshCw size={15} className={refreshing ? "adm-spin" : ""} />{" "}
                Làm mới
              </button>
              {(tab === "overview" || tab === "products") && (
                <button
                  className="adm-button primary"
                  onClick={() => {
                    setNewProduct(true);
                    setEditing({ ...blank });
                    setFormError("");
                  }}
                >
                  <Plus size={16} /> Thêm sản phẩm
                </button>
              )}
              {tab === "coupons" && (
                <button
                  className="adm-button primary"
                  onClick={() => {
                    setNewCoupon(true);
                    setCouponEdit({ ...blankCoupon });
                    setFormError("");
                  }}
                >
                  <Plus size={16} /> Tạo mã ưu đãi
                </button>
              )}
              {tab === "orders" && (
                <button
                  className="adm-button"
                  onClick={() =>
                    exportCsv(
                      "pokevault-don-hang.csv",
                      [
                        "Mã đơn",
                        "Khách hàng",
                        "Điện thoại",
                        "Trạng thái",
                        "Tổng tiền",
                        "Loại đơn",
                        "Ngày đặt",
                      ],
                      filteredOrders.map((o) => [
                        o.id,
                        o.name,
                        o.phone,
                        statusNames[o.status],
                        o.total,
                        o.demo ? "Thử" : "Thật",
                        date(o.createdAt),
                      ]),
                    )
                  }
                >
                  <Download size={16} /> Xuất CSV
                </button>
              )}
            </div>
          </div>
          <ErrorMessage error={error} />
          {!data ? (
            <Loading />
          ) : (
            <>
              {data.settings.demoMode && (
                <div className="adm-demo-banner">
                  <span>
                    <ShieldCheck size={17} />
                    <b>Chế độ trải nghiệm</b>
                    <span>
                      Dữ liệu được lưu; đơn thử không thu tiền hoặc giao hàng
                      thật.
                    </span>
                  </span>
                  <button onClick={() => switchTab("settings")}>
                    Chi tiết <ArrowRight size={14} />
                  </button>
                </div>
              )}
              {tab === "overview" && (
                <>
                  <div className="adm-stats-grid">
                    {[
                      {
                        icon: ShoppingBag,
                        label: "Tổng đơn hàng",
                        value: String(summary?.totalOrders || 0),
                        hint: `${summary?.pendingOrders || 0} đơn đang chờ xác nhận`,
                        tone: "red",
                      },
                      {
                        icon: Banknote,
                        label: "Giá trị đơn thật đã giao",
                        value: money(summary?.deliveredValue || 0),
                        hint: "Không tính đơn thử · Chưa đối soát thu tiền",
                        tone: "green",
                      },
                      {
                        icon: Package,
                        label: "Sản phẩm đang hiển thị",
                        value: String(summary?.activeProducts || 0),
                        hint: `${summary?.lowStockProducts || 0} sản phẩm tồn kho ≤ 5`,
                        tone: "gold",
                      },
                      {
                        icon: Users,
                        label: "Khách hàng đăng ký",
                        value: String(summary?.customerCount || 0),
                        hint: "Tổng tài khoản khách trong hệ thống",
                        tone: "blue",
                      },
                    ].map((stat) => (
                      <article className="adm-stat" key={stat.label}>
                        <div>
                          <span>{stat.label}</span>
                          <span className={"adm-stat-icon " + stat.tone}>
                            <stat.icon size={19} />
                          </span>
                        </div>
                        <strong>{stat.value}</strong>
                        <p>{stat.hint}</p>
                      </article>
                    ))}
                  </div>
                  <div className="adm-overview-grid">
                    <section className="adm-panel adm-chart-panel">
                      <div className="adm-panel-head">
                        <div>
                          <h2>Hoạt động đặt hàng</h2>
                          <p>14 ngày gần nhất · Giờ Việt Nam (UTC+7)</p>
                        </div>
                        <span className="adm-period">
                          <Clock3 size={14} /> 14 ngày
                        </span>
                      </div>
                      <div className="adm-chart-value">
                        <strong>{chartTotal}</strong>
                        <span>đơn được tạo</span>
                        <div className="adm-chart-legend">
                          <span>
                            <i />
                            Đơn thật
                          </span>
                          <span>
                            <i />
                            Đơn thử
                          </span>
                        </div>
                      </div>
                      <div
                        className="adm-chart"
                        role="img"
                        aria-label={`Biểu đồ 14 ngày: tổng ${chartTotal} đơn. Đơn thử và đơn thật được thể hiện riêng.`}
                      >
                        <div className="adm-chart-grid">
                          <i />
                          <i />
                          <i />
                          <i />
                        </div>
                        {data.dailyOrders.map((d) => (
                          <div className="adm-chart-column" key={d.day}>
                            <div
                              className="adm-bar-pair"
                              title={`${d.day}: ${d.liveOrders} đơn thật, ${d.demoOrders} đơn thử`}
                            >
                              <i
                                style={{
                                  height: (d.liveOrders / chartMax) * 100 + "%",
                                }}
                              />
                              <i
                                style={{
                                  height: (d.demoOrders / chartMax) * 100 + "%",
                                }}
                              />
                            </div>
                            <small>
                              {d.day.slice(8)}/{d.day.slice(5, 7)}
                            </small>
                          </div>
                        ))}
                        {!chartTotal && (
                          <div className="adm-chart-empty">
                            <Package size={24} />
                            <b>Chưa có đơn trong 14 ngày qua</b>
                            <span>Biểu đồ sẽ cập nhật khi có đơn mới.</span>
                          </div>
                        )}
                      </div>
                    </section>
                    <section className="adm-panel adm-attention">
                      <div className="adm-panel-head">
                        <div>
                          <h2>Góc vận hành</h2>
                          <p>Những việc cần bạn chăm chút.</p>
                        </div>
                        <span className="adm-round-icon">
                          <Zap size={17} />
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          switchTab("orders");
                          setFilter("pending");
                        }}
                      >
                        <span className="adm-action-icon peach">
                          <Clock3 size={20} />
                        </span>
                        <span>
                          <b>Đơn chờ xác nhận</b>
                          <small>
                            {summary?.pendingOrders || 0} đơn cần xử lý
                          </small>
                        </span>
                        <ChevronRight size={18} />
                      </button>
                      <button
                        onClick={() => {
                          switchTab("products");
                          setFilter("low");
                        }}
                      >
                        <span className="adm-action-icon sand">
                          <Package size={20} />
                        </span>
                        <span>
                          <b>Kiểm tra tồn kho</b>
                          <small>{lowStock.length} sản phẩm sắp hết</small>
                        </span>
                        <ChevronRight size={18} />
                      </button>
                      <button onClick={() => switchTab("settings")}>
                        <span className="adm-action-icon mint">
                          <ShieldCheck size={20} />
                        </span>
                        <span>
                          <b>Sẵn sàng mở cửa</b>
                          <small>Kiểm tra dịch vụ & thông tin</small>
                        </span>
                        <ChevronRight size={18} />
                      </button>
                      <div className="adm-attention-footer">
                        <span /> Dữ liệu từ cửa hàng của bạn
                      </div>
                    </section>
                  </div>
                  <section className="adm-panel">
                    <div className="adm-panel-head">
                      <div>
                        <h2>Đơn hàng gần đây</h2>
                        <p>Mỗi đơn là một niềm vui sắp được gửi đi.</p>
                      </div>
                      <button
                        className="adm-link"
                        onClick={() => switchTab("orders")}
                      >
                        Xem tất cả <ArrowUpRight size={16} />
                      </button>
                    </div>
                    {orderTable(recent, true)}
                  </section>
                  <div className="adm-overview-bottom">
                    <section className="adm-panel">
                      <div className="adm-panel-head">
                        <h2>Sản phẩm cần bổ sung</h2>
                        <button
                          className="adm-link"
                          onClick={() => {
                            switchTab("products");
                            setFilter("low");
                          }}
                        >
                          Quản lý kho <ArrowUpRight size={15} />
                        </button>
                      </div>
                      {lowStock.length ? (
                        lowStock.slice(0, 4).map((p) => (
                          <div className="adm-stock-item" key={p.id}>
                            <img
                              src={productImage(p.image)}
                              alt=""
                              width="48"
                              height="48"
                            />
                            <span>
                              <b>{p.name}</b>
                              <small>{p.category}</small>
                            </span>
                            <span
                              className={
                                "adm-stock-pill " + (!p.stock ? "empty" : "")
                              }
                            >
                              {p.stock ? "Còn " + p.stock : "Hết hàng"}
                            </span>
                            <button
                              className="adm-icon"
                              aria-label={"Sửa " + p.name}
                              onClick={() => {
                                setEditing({ ...p });
                                setNewProduct(false);
                                setFormError("");
                              }}
                            >
                              <Pencil size={15} />
                            </button>
                          </div>
                        ))
                      ) : (
                        <EmptyAdmin
                          title="Tồn kho đang ổn"
                          text="Không có sản phẩm đang bán nào dưới ngưỡng 6 sản phẩm."
                        />
                      )}
                    </section>
                    <section className="adm-brand-panel">
                      <span>THE JOY IS IN THE DETAILS.</span>
                      <h2>
                        Chăm chút hôm nay.
                        <br />
                        Bất ngờ ngày mai.
                      </h2>
                      <p>
                        Điều chỉnh bộ sưu tập, kiểm tra thông tin và tạo một
                        trải nghiệm thật đáng nhớ.
                      </p>
                      <button
                        className="adm-button"
                        onClick={() => switchTab("products")}
                      >
                        Khám phá bộ sưu tập <ArrowUpRight size={17} />
                      </button>
                      <Zap className="adm-brand-watermark" />
                    </section>
                  </div>
                </>
              )}
              {tab === "products" && (
                <section className="adm-panel">
                  <div className="adm-list-tabs">
                    {[
                      ["all", "Tất cả"],
                      ["active", "Đang hiển thị"],
                      ["hidden", "Đã ẩn"],
                      ["low", "Sắp hết hàng"],
                    ].map(([key, label]) => (
                      <button
                        key={key}
                        className={filter === key ? "active" : ""}
                        onClick={() => setFilter(key)}
                      >
                        {label}
                        <span>
                          {key === "all"
                            ? data.products.length
                            : key === "active"
                              ? data.products.filter((p) => p.active).length
                              : key === "hidden"
                                ? data.products.filter((p) => !p.active).length
                                : lowStock.length}
                        </span>
                      </button>
                    ))}
                  </div>
                  <div className="adm-table-toolbar">
                    <label className="adm-search">
                      <Search size={17} />
                      <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="Tìm tên hoặc mã sản phẩm…"
                        aria-label="Tìm sản phẩm"
                      />
                    </label>
                    <select
                      aria-label="Lọc danh mục"
                      value={categories.includes(filter) ? filter : "all"}
                      onChange={(e) => setFilter(e.target.value)}
                    >
                      <option value="all">Tất cả danh mục</option>
                      {categories.map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                    <button
                      className="adm-button"
                      onClick={() =>
                        exportCsv(
                          "pokevault-san-pham.csv",
                          [
                            "Mã",
                            "Tên",
                            "Danh mục",
                            "Giá",
                            "Tồn kho",
                            "Hiển thị",
                          ],
                          filteredProducts.map((p) => [
                            p.id,
                            p.name,
                            p.category,
                            p.price,
                            p.stock,
                            p.active ? "Có" : "Không",
                          ]),
                        )
                      }
                    >
                      <Download size={15} /> Xuất
                    </button>
                  </div>
                  <div className="adm-table-wrap">
                    <table className="adm-table">
                      <thead>
                        <tr>
                          <th>Sản phẩm</th>
                          <th>Danh mục</th>
                          <th>Giá bán</th>
                          <th>Tồn kho</th>
                          <th>Trạng thái</th>
                          <th>Thao tác</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredProducts
                          .slice((page - 1) * 8, page * 8)
                          .map((p) => (
                            <tr key={p.id}>
                              <td>
                                <div className="adm-product-cell">
                                  <img
                                    src={productImage(p.image)}
                                    width="54"
                                    height="54"
                                    alt=""
                                  />
                                  <span>
                                    <button
                                      className="adm-row-link"
                                      onClick={() => {
                                        setEditing({ ...p });
                                        setNewProduct(false);
                                        setFormError("");
                                      }}
                                    >
                                      {p.name}
                                    </button>
                                    <small>{p.id}</small>
                                  </span>
                                </div>
                              </td>
                              <td>{p.category}</td>
                              <td>
                                <b>{money(p.price)}</b>
                                {p.oldPrice > p.price && (
                                  <del className="adm-cell-sub">
                                    {money(p.oldPrice)}
                                  </del>
                                )}
                              </td>
                              <td>
                                <span
                                  className={
                                    "adm-stock-pill " +
                                    (!p.stock
                                      ? "empty"
                                      : p.stock <= 5
                                        ? "low"
                                        : "")
                                  }
                                >
                                  {p.stock} sản phẩm
                                </span>
                              </td>
                              <td>
                                <span
                                  className={
                                    "adm-status " +
                                    (p.active
                                      ? "adm-status-delivered"
                                      : "adm-status-cancelled")
                                  }
                                >
                                  <i />
                                  {p.active ? "Hiển thị" : "Đã ẩn"}
                                </span>
                              </td>
                              <td>
                                <div className="adm-row-actions">
                                  <button
                                    className="adm-icon"
                                    aria-label={"Sửa " + p.name}
                                    onClick={() => {
                                      setEditing({ ...p });
                                      setNewProduct(false);
                                      setFormError("");
                                    }}
                                  >
                                    <Pencil size={16} />
                                  </button>
                                  <button
                                    className="adm-icon"
                                    disabled={busy}
                                    aria-label={
                                      (p.active ? "Ẩn " : "Hiện ") + p.name
                                    }
                                    onClick={async () => {
                                      if (p.active) setHideProduct(p);
                                      else if (
                                        await mutate(
                                          "admin/products",
                                          "PATCH",
                                          { id: p.id, active: 1 },
                                        )
                                      )
                                        notify("Đã hiển thị sản phẩm.");
                                    }}
                                  >
                                    {p.active ? (
                                      <EyeOff size={16} />
                                    ) : (
                                      <Eye size={16} />
                                    )}
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                    {!filteredProducts.length && (
                      <EmptyAdmin
                        title="Chưa tìm thấy sản phẩm"
                        text="Thử từ khóa khác hoặc thay đổi bộ lọc."
                      />
                    )}
                  </div>
                  <Pager
                    page={page}
                    total={filteredProducts.length}
                    onChange={setPage}
                  />
                </section>
              )}
              {tab === "orders" && (
                <section className="adm-panel">
                  <div className="adm-list-tabs">
                    {[
                      ["all", "Tất cả"],
                      ["pending", "Chờ xác nhận"],
                      ["shipping", "Đang giao"],
                      ["delivered", "Đã giao"],
                      ["cancelled", "Đã hủy"],
                    ].map(([key, label]) => (
                      <button
                        key={key}
                        className={filter === key ? "active" : ""}
                        onClick={() => setFilter(key)}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                  <div className="adm-table-toolbar">
                    <label className="adm-search">
                      <Search size={17} />
                      <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        aria-label="Tìm đơn hàng"
                        placeholder="Mã đơn, khách hàng, số điện thoại…"
                      />
                    </label>
                    <select
                      aria-label="Lọc loại đơn"
                      value={
                        filter === "demo" || filter === "live" ? filter : "all"
                      }
                      onChange={(e) => setFilter(e.target.value)}
                    >
                      <option value="all">Tất cả loại đơn</option>
                      <option value="demo">Đơn thử</option>
                      <option value="live">Đơn thật</option>
                    </select>
                    <span className="adm-table-limit">
                      Trong {data.scope.ordersLimit} đơn gần nhất
                    </span>
                  </div>
                  {orderTable(filteredOrders.slice((page - 1) * 8, page * 8))}
                  <Pager
                    page={page}
                    total={filteredOrders.length}
                    onChange={setPage}
                  />
                </section>
              )}
              {tab === "customers" && (
                <section className="adm-panel">
                  <div className="adm-panel-head">
                    <div>
                      <h2>Những người bạn của POKÉVAULT</h2>
                      <p>
                        Tối đa {data.scope.customersLimit} tài khoản khách hàng.
                      </p>
                    </div>
                    <span className="adm-period">
                      {data.summary.customerCount} khách hàng
                    </span>
                  </div>
                  <div className="adm-table-toolbar">
                    <label className="adm-search">
                      <Search size={17} />
                      <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        aria-label="Tìm khách hàng"
                        placeholder="Tìm tên, email, số điện thoại…"
                      />
                    </label>
                  </div>
                  <div className="adm-table-wrap">
                    <table className="adm-table">
                      <thead>
                        <tr>
                          <th>Khách hàng</th>
                          <th>Điện thoại</th>
                          <th>Đơn hàng</th>
                          <th>Giá trị đơn thật đã giao</th>
                          <th>Lần đặt gần nhất</th>
                          <th />
                        </tr>
                      </thead>
                      <tbody>
                        {filteredCustomers
                          .slice((page - 1) * 8, page * 8)
                          .map((c) => (
                            <tr key={c.id}>
                              <td>
                                <div className="adm-person-cell">
                                  <span className="adm-avatar">
                                    {c.name[0]?.toUpperCase()}
                                  </span>
                                  <span>
                                    <b>{c.name}</b>
                                    <small>{c.email}</small>
                                  </span>
                                </div>
                              </td>
                              <td>{c.phone || "Chưa cung cấp"}</td>
                              <td>{c.orderCount}</td>
                              <td>
                                <b>{money(c.totalSpent)}</b>
                              </td>
                              <td>
                                {c.lastOrderAt
                                  ? date(c.lastOrderAt)
                                  : "Chưa đặt hàng"}
                              </td>
                              <td>
                                <button
                                  className="adm-icon"
                                  onClick={() => setCustomerView(c)}
                                  aria-label={"Xem thông tin " + c.name}
                                >
                                  <ArrowUpRight size={16} />
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                    {!filteredCustomers.length && (
                      <EmptyAdmin
                        title="Chưa có khách hàng phù hợp"
                        text="Tài khoản đăng ký mới sẽ xuất hiện tại đây."
                      />
                    )}
                  </div>
                  <Pager
                    page={page}
                    total={filteredCustomers.length}
                    onChange={setPage}
                  />
                </section>
              )}
              {tab === "coupons" && (
                <section className="adm-panel">
                  <div className="adm-table-toolbar">
                    <label className="adm-search">
                      <Search size={17} />
                      <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        aria-label="Tìm mã ưu đãi"
                        placeholder="Tìm mã ưu đãi…"
                      />
                    </label>
                    <select
                      value={filter}
                      onChange={(e) => setFilter(e.target.value)}
                      aria-label="Trạng thái mã"
                    >
                      <option value="all">Tất cả trạng thái</option>
                      <option value="active">Đang áp dụng</option>
                      <option value="hidden">Đã tắt</option>
                    </select>
                  </div>
                  <div className="adm-coupon-grid">
                    {filteredCoupons.map((c) => (
                      <article className="adm-coupon" key={c.code}>
                        <div>
                          <span className="adm-coupon-icon">
                            <TicketPercent size={24} />
                          </span>
                          <span
                            className={
                              "adm-status " +
                              (c.active
                                ? "adm-status-delivered"
                                : "adm-status-cancelled")
                            }
                          >
                            <i />
                            {c.active ? "Đang áp dụng" : "Đã tắt"}
                          </span>
                        </div>
                        <h3>{c.code}</h3>
                        <p>
                          Giảm <strong>{c.percent}%</strong> · Tối đa{" "}
                          {money(c.maximum)}
                        </p>
                        <div>
                          <span>Áp dụng cho giá trị sản phẩm</span>
                          <button
                            className="adm-icon"
                            aria-label={"Sửa mã " + c.code}
                            onClick={() => {
                              setNewCoupon(false);
                              setCouponEdit({ ...c });
                              setFormError("");
                            }}
                          >
                            <Pencil size={16} />
                          </button>
                        </div>
                      </article>
                    ))}
                  </div>
                  {!filteredCoupons.length && (
                    <EmptyAdmin
                      title="Chưa có mã ưu đãi phù hợp"
                      text="Tạo một mã mới hoặc thay đổi từ khóa tìm kiếm."
                    />
                  )}
                </section>
              )}
              {tab === "settings" && (
                <div className="adm-settings-grid">
                  <section className="adm-panel">
                    <div className="adm-panel-head">
                      <div>
                        <h2>Trạng thái vận hành</h2>
                        <p>Những kết nối đã có và cần hoàn thiện.</p>
                      </div>
                      <ShieldCheck size={22} />
                    </div>
                    {[
                      [
                        ShieldCheck,
                        "Chế độ cửa hàng",
                        data.settings.demoMode
                          ? "Đang trải nghiệm · không giao hàng thật"
                          : "Đang nhận đơn COD",
                        !data.settings.demoMode,
                      ],
                      [
                        Mail,
                        "Email",
                        "Chưa kết nối gửi email hoặc đặt lại mật khẩu",
                        false,
                      ],
                      [
                        Truck,
                        "Vận chuyển",
                        "Phí mẫu · chưa đồng bộ đơn vị giao hàng",
                        false,
                      ],
                      [
                        CreditCard,
                        "Thanh toán",
                        "Chưa kết nối cổng thanh toán trực tuyến",
                        false,
                      ],
                    ].map(([Icon, label, desc, ready]) => {
                      const SettingIcon = Icon as typeof Mail;
                      return (
                        <div className="adm-setting-row" key={label as string}>
                          <SettingIcon size={22} />
                          <span>
                            <b>{label as string}</b>
                            <small>{desc as string}</small>
                          </span>
                          <span
                            className={
                              "adm-status " +
                              (ready
                                ? "adm-status-delivered"
                                : "adm-status-pending")
                            }
                          >
                            {ready ? "Đang hoạt động" : "Cần cấu hình"}
                          </span>
                        </div>
                      );
                    })}
                    <div className="adm-settings-note">
                      Các trạng thái này phản ánh cấu hình máy chủ. Việc bật chế
                      độ bán hàng không tự kết nối email, giao hàng hoặc thanh
                      toán.
                    </div>
                  </section>
                  <section className="adm-panel">
                    <div className="adm-panel-head">
                      <h2>Thông tin & bảo mật</h2>
                    </div>
                    <dl className="adm-definition">
                      <div>
                        <dt>Tài khoản quản trị</dt>
                        <dd>{user.email}</dd>
                      </div>
                      <div>
                        <dt>Múi giờ dữ liệu</dt>
                        <dd>Việt Nam · UTC+7</dd>
                      </div>
                      <div>
                        <dt>Đơn vị tiền tệ</dt>
                        <dd>VNĐ</dd>
                      </div>
                      <div>
                        <dt>Quyền truy cập</dt>
                        <dd>Kiểm tra ở máy chủ</dd>
                      </div>
                      <div>
                        <dt>Thiết lập admin lần đầu</dt>
                        <dd>Đã khóa</dd>
                      </div>
                    </dl>
                    {data.settings.adminSetupKeyConfigured && (
                      <p className="adm-settings-note warning">
                        Bạn nên xóa ADMIN_SETUP_KEY khỏi môi trường sau khi tạo
                        tài khoản quản trị.
                      </p>
                    )}
                    <Link className="adm-button" href="/tai-khoan">
                      Cập nhật hồ sơ tài khoản <ArrowUpRight size={15} />
                    </Link>
                  </section>
                  <section className="adm-panel adm-settings-checklist">
                    <div className="adm-panel-head">
                      <h2>Trước khi mở bán thật</h2>
                      <span className="adm-period">Nhắc việc</span>
                    </div>
                    {[
                      "Thay thông tin thương hiệu, email, điện thoại và địa chỉ cửa hàng.",
                      "Xác nhận nguồn gốc sản phẩm, quyền hình ảnh và thông tin trong từng Mystery Box.",
                      "Phê duyệt chính sách vận chuyển, đổi trả, bảo mật và điều khoản.",
                      "Kết nối dịch vụ cần thiết, kiểm tra thanh toán/giao hàng và sao lưu dữ liệu.",
                    ].map((text, i) => (
                      <p key={text}>
                        <span>0{i + 1}</span>
                        {text}
                      </p>
                    ))}
                    <Link
                      className="adm-link"
                      href="/thong-tin/lien-he"
                      target="_blank"
                    >
                      Kiểm tra thông tin liên hệ <ArrowUpRight size={15} />
                    </Link>
                  </section>
                </div>
              )}
            </>
          )}
          <footer className="adm-footer">
            <span>POKÉVAULT · Made for the joy of collecting.</span>
            <span>
              <LockKeyhole size={12} /> Khu vực quản trị được bảo vệ
            </span>
          </footer>
        </div>
      </div>
      <Dialog
        open={!!editing}
        onClose={() => {
          if (!busy) setEditing(null);
        }}
        title={newProduct ? "Thêm vào bộ sưu tập" : "Chỉnh sửa sản phẩm"}
      >
        {editing && (
          <form
            className="adm-edit-form"
            onSubmit={async (e) => {
              e.preventDefault();
              if (
                await mutate(
                  "admin/product",
                  newProduct ? "POST" : "PUT",
                  editing,
                )
              ) {
                setEditing(null);
                notify("Đã lưu sản phẩm.");
              }
            }}
          >
            <div className="adm-edit-image">
              <img
                src={productImage(editing.image)}
                alt="Ảnh minh họa sản phẩm"
                width="180"
                height="180"
              />
              <div>
                <b>Hình ảnh sản phẩm</b>
                <p>
                  Chọn một ảnh trong thư viện minh họa. Nội dung ảnh không thay
                  thế mô tả sản phẩm.
                </p>
                <select
                  aria-label="Chọn ảnh sản phẩm"
                  value={editing.image}
                  onChange={(e) => {
                    const selected = seedProducts.find(
                      (p) => p.image === e.target.value,
                    );
                    setEditing({
                      ...editing,
                      image: e.target.value,
                      color: selected?.color || "yellow",
                    });
                  }}
                >
                  {seedProducts.map((p) => (
                    <option key={p.id} value={p.image}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <label>
              Tên sản phẩm
              <input
                required
                minLength={2}
                maxLength={150}
                value={editing.name}
                onChange={(e) =>
                  setEditing({ ...editing, name: e.target.value })
                }
                placeholder="Tên chiếc hộp mới…"
              />
            </label>
            <div className="form-row">
              <label>
                Mã sản phẩm
                <input
                  required
                  disabled={!newProduct}
                  pattern="[a-z0-9-]{1,80}"
                  value={editing.id}
                  onChange={(e) =>
                    setEditing({ ...editing, id: e.target.value })
                  }
                  placeholder="mystery-box-new"
                />
              </label>
              <label>
                Danh mục
                <select
                  value={editing.category}
                  onChange={(e) =>
                    setEditing({ ...editing, category: e.target.value })
                  }
                >
                  {categories.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </label>
            </div>
            <div className="form-row">
              <label>
                Giá bán (VNĐ)
                <input
                  required
                  type="number"
                  min={1000}
                  max={100000000}
                  value={editing.price}
                  onChange={(e) =>
                    setEditing({ ...editing, price: Number(e.target.value) })
                  }
                />
              </label>
              <label>
                Giá cũ (0 = không có)
                <input
                  required
                  type="number"
                  min={0}
                  max={100000000}
                  value={editing.oldPrice}
                  onChange={(e) =>
                    setEditing({ ...editing, oldPrice: Number(e.target.value) })
                  }
                />
              </label>
            </div>
            <div className="form-row">
              <label>
                Tồn kho
                <input
                  required
                  type="number"
                  min={0}
                  max={100000}
                  value={editing.stock}
                  onChange={(e) =>
                    setEditing({ ...editing, stock: Number(e.target.value) })
                  }
                />
              </label>
              <label>
                Nhãn nổi bật
                <input
                  maxLength={30}
                  value={editing.badge}
                  onChange={(e) =>
                    setEditing({ ...editing, badge: e.target.value })
                  }
                  placeholder="MỚI / ĐƯỢC YÊU THÍCH"
                />
              </label>
            </div>
            <label>
              Mô tả sản phẩm
              <textarea
                rows={4}
                required
                minLength={5}
                maxLength={5000}
                value={editing.description}
                onChange={(e) =>
                  setEditing({ ...editing, description: e.target.value })
                }
              />
            </label>
            <label className="check-label">
              <input
                type="checkbox"
                checked={!!editing.active}
                onChange={(e) =>
                  setEditing({ ...editing, active: e.target.checked ? 1 : 0 })
                }
              />{" "}
              Hiển thị sản phẩm trong cửa hàng
            </label>
            <ErrorMessage error={formError} />
            <div className="adm-dialog-actions">
              <button
                type="button"
                disabled={busy}
                className="adm-button"
                onClick={() => setEditing(null)}
              >
                Hủy
              </button>
              <button disabled={busy} className="adm-button primary">
                {busy ? "Đang lưu…" : "Lưu sản phẩm"} <Check size={16} />
              </button>
            </div>
          </form>
        )}
      </Dialog>
      <Dialog
        open={!!hideProduct}
        onClose={() => setHideProduct(null)}
        title="Ẩn sản phẩm khỏi cửa hàng?"
      >
        <p className="adm-dialog-copy">
          <b>{hideProduct?.name}</b> sẽ tạm ngừng hiển thị. Dữ liệu và lịch sử
          đơn vẫn được giữ; bạn có thể hiển thị lại bất cứ lúc nào.
        </p>
        <div className="adm-dialog-actions">
          <button className="adm-button" onClick={() => setHideProduct(null)}>
            Giữ lại
          </button>
          <button
            disabled={busy}
            className="adm-button primary"
            onClick={async () => {
              if (
                await mutate("admin/product", "DELETE", { id: hideProduct?.id })
              ) {
                setHideProduct(null);
                notify("Đã ẩn sản phẩm.");
              }
            }}
          >
            Xác nhận ẩn
          </button>
        </div>
      </Dialog>
      <Dialog
        open={!!selectedOrder}
        onClose={() => setSelectedOrder(null)}
        title={
          "Đơn hàng #" + (selectedOrder?.id.slice(0, 8).toUpperCase() || "")
        }
      >
        {selectedOrder && (
          <div className="adm-order-detail">
            <div className="adm-order-meta">
              <Status value={selectedOrder.status} />
              {!!selectedOrder.demo && (
                <span className="adm-demo-tag">Đơn thử</span>
              )}
              <small>
                {date(selectedOrder.createdAt)} ·{" "}
                {time(selectedOrder.createdAt)}
              </small>
            </div>
            <section>
              <h3>Thông tin người nhận</h3>
              <p>
                <b>{selectedOrder.name}</b> · {selectedOrder.phone}
              </p>
              <p>{selectedOrder.address}</p>
              {selectedOrder.note && (
                <p className="adm-order-note">Ghi chú: {selectedOrder.note}</p>
              )}
            </section>
            <section>
              <h3>Sản phẩm trong đơn</h3>
              {data?.orderItems
                .filter((i) => i.orderId === selectedOrder.id)
                .map((i, index) => (
                  <div className="adm-order-item" key={index}>
                    <span>
                      {i.name}
                      <small>
                        Số lượng {i.quantity} × {money(i.price)}
                      </small>
                    </span>
                    <b>{money(i.price * i.quantity)}</b>
                  </div>
                ))}
            </section>
            <dl className="adm-definition">
              <div>
                <dt>Tạm tính</dt>
                <dd>{money(selectedOrder.subtotal)}</dd>
              </div>
              <div>
                <dt>
                  Giao{" "}
                  {selectedOrder.shippingMethod === "express"
                    ? "nhanh"
                    : "tiêu chuẩn"}
                </dt>
                <dd>{money(selectedOrder.shipping)}</dd>
              </div>
              <div>
                <dt>Giảm giá</dt>
                <dd>−{money(selectedOrder.discount)}</dd>
              </div>
              <div className="adm-total">
                <dt>Tổng cộng</dt>
                <dd>{money(selectedOrder.total)}</dd>
              </div>
            </dl>
            <p className="adm-settings-note">
              COD · Chưa xác nhận thanh toán trực tuyến.{" "}
              {selectedOrder.demo ? "Đơn thử không được giao hàng thật." : ""}
            </p>
            <div className="adm-dialog-actions">
              {transitions[selectedOrder.status]?.map((s) => (
                <button
                  className={
                    "adm-button " + (s === "cancelled" ? "danger" : "primary")
                  }
                  key={s}
                  onClick={() =>
                    setOrderChange({ order: selectedOrder, status: s })
                  }
                >
                  {s === "cancelled" ? "Hủy đơn" : statusNames[s]}{" "}
                  <ArrowRight size={15} />
                </button>
              ))}
            </div>
          </div>
        )}
      </Dialog>
      <Dialog
        open={!!orderChange}
        onClose={() => setOrderChange(null)}
        title="Xác nhận cập nhật đơn hàng"
      >
        <p className="adm-dialog-copy">
          Chuyển đơn <b>#{orderChange?.order.id.slice(0, 8).toUpperCase()}</b>{" "}
          sang <b>{statusNames[orderChange?.status || ""]}</b>?{" "}
          {orderChange?.status === "cancelled"
            ? "Hệ thống sẽ hoàn lại tồn kho. Đơn đã hủy không thể mở lại."
            : ""}
        </p>
        <ErrorMessage error={formError} />
        <div className="adm-dialog-actions">
          <button className="adm-button" onClick={() => setOrderChange(null)}>
            Quay lại
          </button>
          <button
            disabled={busy}
            className="adm-button primary"
            onClick={async () => {
              if (!orderChange) return;
              if (
                await mutate("admin/order", "PUT", {
                  id: orderChange.order.id,
                  status: orderChange.status,
                })
              ) {
                setSelectedOrder({
                  ...orderChange.order,
                  status: orderChange.status,
                });
                setOrderChange(null);
                notify("Đã cập nhật trạng thái đơn hàng.");
              }
            }}
          >
            {busy ? "Đang cập nhật…" : "Xác nhận"}
          </button>
        </div>
      </Dialog>
      <Dialog
        open={!!couponEdit}
        onClose={() => setCouponEdit(null)}
        title="Thiết lập mã ưu đãi"
      >
        {couponEdit && (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (
                await mutate(
                  "admin/coupon",
                  newCoupon ? "POST" : "PUT",
                  couponEdit,
                )
              ) {
                setCouponEdit(null);
                notify("Đã lưu mã ưu đãi.");
              }
            }}
          >
            <label>
              Mã ưu đãi
              <input
                required
                pattern="[A-Z0-9]{3,20}"
                disabled={!newCoupon}
                value={couponEdit.code}
                onChange={(e) =>
                  setCouponEdit({
                    ...couponEdit,
                    code: e.target.value.toUpperCase(),
                  })
                }
                placeholder="HELLOVAULT"
              />
            </label>
            <div className="form-row">
              <label>
                Giảm giá (%)
                <input
                  required
                  type="number"
                  min={1}
                  max={50}
                  value={couponEdit.percent}
                  onChange={(e) =>
                    setCouponEdit({
                      ...couponEdit,
                      percent: Number(e.target.value),
                    })
                  }
                />
              </label>
              <label>
                Giảm tối đa (VNĐ)
                <input
                  required
                  type="number"
                  min={1000}
                  max={1000000}
                  value={couponEdit.maximum}
                  onChange={(e) =>
                    setCouponEdit({
                      ...couponEdit,
                      maximum: Number(e.target.value),
                    })
                  }
                />
              </label>
            </div>
            <label className="check-label">
              <input
                type="checkbox"
                checked={!!couponEdit.active}
                onChange={(e) =>
                  setCouponEdit({
                    ...couponEdit,
                    active: e.target.checked ? 1 : 0,
                  })
                }
              />{" "}
              Đang áp dụng
            </label>
            <p className="adm-settings-note">
              Mã giảm trên giá trị sản phẩm trước phí giao hàng. Chưa giới hạn
              số lượt dùng hoặc ngày hết hạn.
            </p>
            <ErrorMessage error={formError} />
            <div className="adm-dialog-actions">
              <button
                type="button"
                className="adm-button"
                onClick={() => setCouponEdit(null)}
              >
                Hủy
              </button>
              <button className="adm-button primary" disabled={busy}>
                {busy ? "Đang lưu…" : "Lưu mã ưu đãi"}
              </button>
            </div>
          </form>
        )}
      </Dialog>
      <Dialog
        open={!!customerView}
        onClose={() => setCustomerView(null)}
        title="Thông tin khách hàng"
      >
        {customerView && (
          <>
            <div className="adm-customer-profile">
              <span className="adm-avatar">
                {customerView.name[0]?.toUpperCase()}
              </span>
              <h3>{customerView.name}</h3>
              <p>{customerView.email}</p>
            </div>
            <dl className="adm-definition">
              <div>
                <dt>Điện thoại</dt>
                <dd>{customerView.phone || "Chưa cung cấp"}</dd>
              </div>
              <div>
                <dt>Địa chỉ mặc định</dt>
                <dd>{customerView.address || "Chưa cung cấp"}</dd>
              </div>
              <div>
                <dt>Số đơn hàng</dt>
                <dd>{customerView.orderCount}</dd>
              </div>
              <div>
                <dt>Giá trị đơn thật đã giao</dt>
                <dd>{money(customerView.totalSpent)}</dd>
              </div>
            </dl>
            <p className="adm-settings-note">
              Chỉ sử dụng thông tin khách hàng để xử lý đơn và hỗ trợ theo chính
              sách đã công bố.
            </p>
          </>
        )}
      </Dialog>
    </div>
  );
}

function SparkleMark() {
  return <Zap size={19} strokeWidth={1.6} />;
}
function AdminAccess() {
  const { user, refreshUser, notify } = useShop();
  const [setup, setSetup] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [showPassword, setShowPassword] = useState(false),
    [done, setDone] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const form = e.currentTarget;
    try {
      await api(
        setup ? "setup" : "auth/login",
        "POST",
        Object.fromEntries(new FormData(form)),
      );
      if (setup) {
        form.reset();
        setDone(true);
        setSetup(false);
        notify("Đã tạo quản trị viên. Hãy đăng nhập tài khoản vừa tạo.");
      } else await refreshUser();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="adm-access">
      <section className="adm-access-story">
        <Brand />
        <div>
          <p className="adm-overline">THE OTHER SIDE OF THE MAGIC</p>
          <h1>
            Phía sau mỗi bất ngờ,
            <br />
            là một người
            <br />
            <span>thật tận tâm.</span>
          </h1>
          <p>
            Chào mừng bạn đến không gian quản lý POKÉVAULT.
            <br />
            Mọi chiếc hộp, mọi đơn hàng, mọi niềm vui — ở đây.
          </p>
          <img
            src="/studio/hero-v2.png"
            width="700"
            height="467"
            alt="Hộp POKÉVAULT và thẻ sưu tầm minh họa"
          />
        </div>
        <small>POKÉVAULT BUSINESS SPACE · VIETNAM</small>
      </section>
      <section className="adm-access-form">
        <Link className="adm-back" href="/">
          <ArrowLeft size={16} /> Trở lại cửa hàng
        </Link>
        <div className="adm-access-card">
          <span className="adm-access-lock">
            <ShieldCheck size={27} />
          </span>
          <p className="adm-overline">WELCOME TO YOUR VAULT</p>
          <h2>{setup ? "Thiết lập cửa hàng." : "Chào mừng trở lại."}</h2>
          <p>
            {setup
              ? "Tạo tài khoản quản trị đầu tiên bằng khóa thiết lập của chủ cửa hàng."
              : "Đăng nhập để chăm chút cửa hàng của bạn."}
          </p>
          {user && user.role !== "admin" ? (
            <>
              <div className="adm-access-warning">
                <AlertCircle size={20} />
                <p>
                  Tài khoản <b>{user.email}</b> chưa có quyền quản trị.
                </p>
              </div>
              <button
                className="adm-button primary full"
                onClick={async () => {
                  try {
                    await api("auth/logout", "POST", {});
                    await refreshUser();
                  } catch (e) {
                    setError((e as Error).message);
                  }
                }}
              >
                Đăng xuất để dùng tài khoản quản trị <LogOut size={16} />
              </button>
              <ErrorMessage error={error} />
            </>
          ) : (
            <>
              <form onSubmit={submit} key={setup ? "setup" : "login"}>
                {setup && (
                  <>
                    <label>
                      Khóa thiết lập
                      <input
                        type="password"
                        name="key"
                        required
                        minLength={32}
                        autoComplete="off"
                        placeholder="ADMIN_SETUP_KEY"
                      />
                    </label>
                    <label>
                      Tên quản trị viên
                      <input
                        name="name"
                        required
                        minLength={2}
                        maxLength={100}
                        autoComplete="name"
                        placeholder="Tên của bạn"
                      />
                    </label>
                  </>
                )}
                <label>
                  {setup ? "Email quản trị" : "Email hoặc tên đăng nhập"}
                  <input
                    type={setup ? "email" : "text"}
                    name="email"
                    required
                    maxLength={200}
                    autoComplete={setup ? "email" : "username"}
                    placeholder={
                      setup ? "admin@cuahang.vn" : "Email hoặc tên đăng nhập"
                    }
                  />
                </label>
                <label>
                  Mật khẩu
                  <div className="adm-password">
                    <input
                      type={showPassword ? "text" : "password"}
                      name="password"
                      required
                      minLength={setup ? 10 : 1}
                      maxLength={128}
                      autoComplete={setup ? "new-password" : "current-password"}
                      placeholder={setup ? "Ít nhất 10 ký tự" : "Nhập mật khẩu"}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      aria-label={
                        showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"
                      }
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </label>
                {done && !setup && (
                  <p className="adm-success">
                    Đã tạo tài khoản. Bạn có thể đăng nhập ngay.
                  </p>
                )}
                <ErrorMessage error={error} />
                <button className="adm-button primary full" disabled={busy}>
                  {busy
                    ? "Đang xử lý…"
                    : setup
                      ? "Tạo tài khoản quản trị"
                      : "Đăng nhập quản trị"}
                  <ArrowRight size={17} />
                </button>
              </form>
              <div className="adm-access-switch">
                <span>
                  {setup
                    ? "Bạn đã có tài khoản?"
                    : "Lần đầu thiết lập cửa hàng?"}
                </span>
                <button
                  onClick={() => {
                    setSetup(!setup);
                    setError("");
                  }}
                >
                  {setup ? "Đăng nhập" : "Thiết lập quản trị"}{" "}
                  <ArrowUpRight size={14} />
                </button>
              </div>
              {setup && (
                <details className="adm-setup-help">
                  <summary>Lấy khóa thiết lập ở đâu?</summary>
                  <p>
                    Chủ cửa hàng tạo khóa ngẫu nhiên ít nhất 32 ký tự trong biến
                    ADMIN_SETUP_KEY của máy chủ. Trên máy local, sao chép
                    .env.example thành .env.local, thay khóa rồi khởi động
                    lại server. Xem README để cấu hình. Không có mật khẩu mặc
                    định.
                  </p>
                </details>
              )}
            </>
          )}
          <div className="adm-access-security">
            <LockKeyhole size={14} />
            <span>
              Phiên đăng nhập được bảo vệ.
              <br />
              Quyền quản trị được kiểm tra trên máy chủ.
            </span>
          </div>
        </div>
        <small className="adm-access-copyright">
          © {new Date().getFullYear()} POKÉVAULT. Made with a little magic.
        </small>
      </section>
    </div>
  );
}
