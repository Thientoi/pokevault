"use client";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef,
  type ReactNode,
} from "react";
import { Product } from "../lib/catalog";
import {
  addToCart,
  restoreCart,
  CART_QUANTITY_LIMIT,
  type CartItem,
} from "../lib/cart";
export type { CartItem } from "../lib/cart";
export type User = {
  id: string;
  name: string;
  email: string;
  role: string;
  phone: string;
  address: string;
};
export async function api(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<any> {
  const r = await fetch("/api/" + path, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let d: any;
  try {
    d = await r.json();
  } catch {
    throw new Error("Không thể kết nối máy chủ. Vui lòng thử lại.");
  }
  if (!r.ok) throw new Error(d.error || "Có lỗi xảy ra.");
  return d;
}
type Context = {
  products: Product[];
  loading: boolean;
  error: string;
  demo: boolean;
  cart: CartItem[];
  favorites: string[];
  user: User | null;
  authLoading: boolean;
  drawer: boolean;
  setDrawer: (v: boolean) => void;
  refresh: () => Promise<void>;
  refreshUser: () => Promise<void>;
  add: (id: string, q?: number) => boolean;
  quantity: (id: string, q: number) => void;
  clear: () => void;
  favorite: (id: string) => void;
  notify: (s: string) => void;
};
const C = createContext<Context>(null!);
export const useShop = () => useContext(C);
export function ShopProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [demo, setDemo] = useState(true),
    [cart, setCart] = useState<CartItem[]>([]),
    [favorites, setFavorites] = useState<string[]>([]),
    [user, setUser] = useState<User | null>(null),
    [authLoading, setAuthLoading] = useState(true),
    [ready, setReady] = useState(false),
    [drawer, setDrawer] = useState(false),
    [toast, setToast] = useState("");
  // Keep synchronous actions on one current cart even before React re-renders.
  const cartRef = useRef<CartItem[]>([]);
  const commitCart = useCallback((next: CartItem[]) => {
    cartRef.current = next;
    setCart(next);
  }, []);
  const refresh = useCallback(async () => {
    try {
      const d = await api("products");
      setProducts(d.products);
      setDemo(d.demo);
      setError("");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);
  const refreshUser = useCallback(async () => {
    try {
      setUser((await api("me")).user);
    } catch {
      setUser(null);
    } finally {
      setAuthLoading(false);
    }
  }, []);
  useEffect(() => {
    refresh();
    refreshUser();
    try {
      const c = JSON.parse(localStorage.getItem("pv-cart") || "[]");
      commitCart(restoreCart(c));
      const f = JSON.parse(localStorage.getItem("pv-favorites") || "[]");
      if (Array.isArray(f))
        setFavorites(f.filter((i: any) => typeof i === "string"));
    } catch {}
    setReady(true);
  }, [refresh, refreshUser, commitCart]);
  useEffect(() => {
    if (ready)
      try {
        localStorage.setItem("pv-cart", JSON.stringify(cart));
        localStorage.setItem("pv-favorites", JSON.stringify(favorites));
      } catch {
        setToast(
          "Trình duyệt không cho lưu giỏ hàng. Giỏ vẫn dùng được trong phiên này.",
        );
      }
  }, [cart, favorites, ready]);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(""), 4500);
    return () => clearTimeout(id);
  }, [toast]);
  function add(id: string, q = 1) {
    const p = products.find((p) => p.id === id);
    const result = addToCart(cartRef.current, p, q);
    if (!result.ok) {
      const messages = {
        quantity: "Vui lòng chọn số lượng nguyên từ 1 trở lên.",
        unavailable: "Sản phẩm đã hết hàng hoặc không còn được bán.",
        capacity: "Đã đạt số lượng tối đa hoặc giới hạn tồn kho.",
        lines: "Giỏ hàng chỉ chứa tối đa 20 sản phẩm khác nhau.",
      };
      setToast(messages[result.reason]);
      return false;
    }
    commitCart(result.cart);
    setToast("Đã thêm vào giỏ hàng. Niềm vui đang chờ bạn!");
    return true;
  }
  function quantity(id: string, q: number) {
    if (!Number.isInteger(q) || q < 0) {
      setToast("Số lượng sản phẩm không hợp lệ.");
      return;
    }
    const current = cartRef.current;
    const p = products.find((p) => p.id === id);
    if (q === 0) {
      commitCart(current.filter((i) => i.id !== id));
      return;
    }
    if (!p || p.active !== 1 || q > Math.min(p.stock, CART_QUANTITY_LIMIT)) {
      setToast("Số lượng vượt quá tồn kho hiện tại.");
      return;
    }
    commitCart(current.map((i) => (i.id === id ? { ...i, quantity: q } : i)));
  }
  return (
    <C.Provider
      value={{
        products,
        loading,
        error,
        demo,
        cart,
        favorites,
        user,
        authLoading,
        drawer,
        setDrawer,
        refresh,
        refreshUser,
        add,
        quantity,
        clear: () => commitCart([]),
        favorite: (id) =>
          setFavorites((f) =>
            f.includes(id) ? f.filter((v) => v !== id) : [...f, id],
          ),
        notify: setToast,
      }}
    >
      {children}
      {toast && (
        <div className="toast" role="status">
          ✓ {toast}
          <button aria-label="Đóng thông báo" onClick={() => setToast("")}>
            ×
          </button>
        </div>
      )}
    </C.Provider>
  );
}
