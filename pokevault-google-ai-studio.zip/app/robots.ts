export default function robots() {
  return {
    rules: { userAgent: "*", disallow: "/" },
    sitemap: (process.env.APP_URL || "http://localhost:3000") + "/sitemap.xml",
  };
}
