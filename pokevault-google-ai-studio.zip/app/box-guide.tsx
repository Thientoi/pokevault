"use client";
import Link from "next/link";
import { ArrowUpRight, ArrowRight, Package } from "lucide-react";
import { useShop } from "./context";
import { Loading, ErrorMessage } from "./ui";
import { boxBudgets, findBudgetBox } from "../lib/discovery";
import { productImage } from "../lib/product-art";
import { money } from "../lib/catalog";

export function BoxGuide() {
  const { products, loading, error, refresh } = useShop();
  return (
    <section className="collector-guide" aria-labelledby="box-guide-title">
      <div className="container">
        <div className="studio-section-heading">
          <div>
            <p className="studio-eyebrow">CHỌN THEO NGÂN SÁCH</p>
            <h2 id="box-guide-title">Một chiếc hộp, vừa ý bạn.</h2>
          </div>
          <p className="collector-heading-copy">
            Bắt đầu từ điều bạn thấy thoải mái.
            <br />
            Giá hiện tại, lựa chọn rõ ràng.
          </p>
        </div>
        {loading ? (
          <Loading />
        ) : error ? (
          <>
            <ErrorMessage error={error} />
            <button className="button secondary" onClick={refresh}>
              Thử tải lại
            </button>
          </>
        ) : (
          <div className="collector-budget-grid">
            {boxBudgets.map((budget, index) => {
              const product = findBudgetBox(products, budget);
              return (
                <article
                  className={"collector-budget-card budget-" + index}
                  key={budget.id}
                >
                  <div className="collector-budget-heading">
                    <span>
                      0{index + 1} / {budget.label}
                    </span>
                    <span>{budget.budget}</span>
                  </div>
                  <div className="collector-budget-art">
                    <img
                      src={product ? productImage(product.image) : budget.image}
                      width={320}
                      height={320}
                      loading="lazy"
                      alt={
                        product
                          ? "Hình minh họa " + product.name
                          : "Hộp minh họa cho khoảng ngân sách"
                      }
                    />
                  </div>
                  <div className="collector-budget-copy">
                    <p>{budget.description}</p>
                    <h3>{product ? product.name : "Chưa có hộp phù hợp"}</h3>
                    {product ? (
                      <>
                        <div className="collector-budget-price">
                          <strong>{money(product.price)}</strong>
                          <span>
                            <i /> Còn hàng
                          </span>
                        </div>
                        <Link
                          href={"/san-pham/" + product.id}
                          className="collector-budget-link"
                        >
                          Xem chiếc hộp này <ArrowUpRight size={20} />
                        </Link>
                      </>
                    ) : (
                      <>
                        <p className="collector-budget-empty">
                          <Package size={15} /> Chưa có sản phẩm còn hàng trong
                          mức giá này.
                        </p>
                        <Link
                          href="/san-pham?category=Mystery%20Box"
                          className="collector-budget-link"
                        >
                          Xem các lựa chọn khác <ArrowRight size={20} />
                        </Link>
                      </>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
        <p className="collector-budget-note">
          Bộ sưu tập minh họa · Giá được cập nhật từ cửa hàng · Nội dung hộp
          ngẫu nhiên, không cam kết thẻ hiếm.
        </p>
      </div>
    </section>
  );
}
