"use client";
import { useEffect, useState, useRef, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  ArrowLeft,
  Trash2,
  ShieldCheck,
  Truck,
  Check,
  Package,
  LogOut,
  Heart,
  UserRound,
  LockKeyhole,
} from "lucide-react";
import { money } from "../lib/catalog";
import { productImage } from "../lib/product-art";
import { totals, checkoutSchema } from "../lib/validation";
import { useShop, api } from "./context";
import { Quantity, Empty, Dialog, ErrorMessage, Loading } from "./ui";
export const statuses: Record<string, string> = {
  pending: "Chờ xác nhận",
  confirmed: "Đã xác nhận",
  shipping: "Đang giao",
  delivered: "Đã giao",
  cancelled: "Đã hủy",
};
function CartLines({ compact = false }: { compact?: boolean }) {
  const { cart, products, quantity } = useShop();
  return (
    <div className={"cart-lines " + (compact ? "compact" : "")}>
      {cart.map((c) => {
        const p = products.find((p) => p.id === c.id);
        return (
          <article className="cart-line" key={c.id}>
            {p ? (
              <>
                <Link href={"/san-pham/" + p.id}>
                  <img
                    className={p.color}
                    src={productImage(p.image)}
                    alt={p.name}
                    width="100"
                    height="100"
                  />
                </Link>
                <div className="cart-line-info">
                  <span className="eyebrow muted">{p.category}</span>
                  <Link href={"/san-pham/" + p.id}>
                    <h3>{p.name}</h3>
                  </Link>
                  <b>{money(p.price)}</b>
                  {c.quantity > p.stock && (
                    <p className="red-text">Chỉ còn {p.stock} sản phẩm.</p>
                  )}
                  <Quantity
                    value={c.quantity}
                    max={Math.min(p.stock, 20)}
                    onChange={(q) => quantity(c.id, q)}
                  />
                </div>
                <div className="cart-line-end">
                  <button
                    className="icon-button"
                    aria-label={"Xóa " + p.name}
                    onClick={() => quantity(c.id, 0)}
                  >
                    <Trash2 size={17} />
                  </button>
                  {!compact && <strong>{money(p.price * c.quantity)}</strong>}
                </div>
              </>
            ) : (
              <>
                <p>Sản phẩm không còn được bán.</p>
                <button
                  className="button secondary"
                  onClick={() => quantity(c.id, 0)}
                >
                  Xóa khỏi giỏ
                </button>
              </>
            )}
          </article>
        );
      })}
    </div>
  );
}
export function CartDrawer() {
  const { cart, products, drawer, setDrawer } = useShop();
  const subtotal = cart.reduce(
    (s, c) =>
      s + (products.find((p) => p.id === c.id)?.price || 0) * c.quantity,
    0,
  );
  return (
    <Dialog
      open={drawer}
      onClose={() => setDrawer(false)}
      title={
        "Giỏ hàng của bạn (" + cart.reduce((s, c) => s + c.quantity, 0) + ")"
      }
      drawer
    >
      {cart.length ? (
        <>
          <p className="muted">Một chút niềm vui đang chờ được mở.</p>
          <CartLines compact />
          <div className="drawer-summary">
            <div>
              <span>Tạm tính</span>
              <strong>{money(subtotal)}</strong>
            </div>
            <small>Phí vận chuyển và ưu đãi được tính ở bước tiếp theo.</small>
            <Link
              className="button primary full"
              onClick={() => setDrawer(false)}
              href="/gio-hang"
            >
              Xem giỏ hàng <ArrowRight size={18} />
            </Link>
          </div>
        </>
      ) : (
        <div onClick={() => setDrawer(false)}>
          <Empty
            title="Giỏ hàng còn trống."
            text="Chọn một chiếc hộp để bắt đầu câu chuyện của bạn."
          />
        </div>
      )}
    </Dialog>
  );
}
export function Cart() {
  const { cart, products, loading } = useShop();
  const router = useRouter();
  const [code, setCode] = useState(""),
    [coupon, setCoupon] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const subtotal = cart.reduce(
      (s, c) =>
        s + (products.find((p) => p.id === c.id)?.price || 0) * c.quantity,
      0,
    ),
    t = totals(subtotal, "standard", coupon?.percent, coupon?.maximum);
  if (loading) return <Loading />;
  if (!cart.length)
    return (
      <Empty
        title="Chiếc giỏ đang chờ điều bất ngờ."
        text="Bạn chưa thêm sản phẩm nào. Cùng tìm chiếc hộp dành cho bạn nhé!"
      />
    );
  const invalid = cart.some((c) => {
    const p = products.find((p) => p.id === c.id);
    return !p || p.stock < c.quantity;
  });
  return (
    <div className="container page-space">
      <p className="eyebrow red-text">SẮP ĐẾN LÚC MỞ NIỀM VUI</p>
      <h1>Giỏ hàng của bạn</h1>
      <div className="checkout-grid">
        <div>
          <CartLines />
          <Link className="text-link" href="/san-pham">
            <ArrowLeft size={17} /> Tiếp tục khám phá
          </Link>
          <div className="notice">
            <ShieldCheck size={20} />
            <p>
              Bản mẫu có lưu đơn thử. Không thanh toán, không gửi hàng thật. Vui
              lòng dùng thông tin thử khi trải nghiệm.
            </p>
          </div>
        </div>
        <aside className="order-summary">
          <h2>Tóm tắt đơn hàng</h2>
          <div className="free-shipping">
            <Truck size={20} />
            <p>
              {subtotal >= 699000
                ? "Bạn đã đạt mức miễn phí giao tiêu chuẩn."
                : `Thêm ${money(699000 - subtotal)} để miễn phí giao tiêu chuẩn.`}
            </p>
          </div>
          <form
            className="coupon-form"
            onSubmit={async (e) => {
              e.preventDefault();
              setBusy(true);
              setError("");
              try {
                setCoupon(await api("coupon", "POST", { code }));
              } catch (e) {
                setCoupon(null);
                setError((e as Error).message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <label htmlFor="coupon">Mã ưu đãi</label>
            <div>
              <input
                id="coupon"
                value={code}
                onChange={(e) => {
                  setCode(e.target.value);
                  setCoupon(null);
                }}
                placeholder="Thử mã HELLOVAULT"
              />
              <button disabled={busy} className="button secondary">
                {busy ? "…" : "Áp dụng"}
              </button>
            </div>
          </form>
          {coupon && <p className="success-text">✓ Đã áp dụng {coupon.code}</p>}
          <ErrorMessage error={error} />
          <Totals value={t} />
          <button
            className="button primary full"
            disabled={invalid}
            onClick={() =>
              router.push(
                "/thanh-toan" +
                  (coupon ? "?coupon=" + encodeURIComponent(coupon.code) : ""),
              )
            }
          >
            Tiến hành thanh toán <ArrowRight size={18} />
          </button>
          {invalid && (
            <ErrorMessage error="Vui lòng cập nhật số lượng hoặc xóa sản phẩm không còn hàng." />
          )}
          <p className="secure-note">
            <LockKeyhole size={13} /> Giá và tồn kho được kiểm tra lại trên máy
            chủ.
          </p>
        </aside>
      </div>
    </div>
  );
}
function Totals({
  value,
}: {
  value: {
    subtotal: number;
    shipping: number;
    discount: number;
    total: number;
  };
}) {
  return (
    <div className="totals">
      <div>
        <span>Tạm tính</span>
        <b>{money(value.subtotal)}</b>
      </div>
      <div>
        <span>Phí vận chuyển</span>
        <b>{value.shipping ? money(value.shipping) : "Miễn phí"}</b>
      </div>
      <div>
        <span>Giảm giá</span>
        <b className="success-text">−{money(value.discount)}</b>
      </div>
      <div className="total">
        <b>Tổng cộng</b>
        <strong>{money(value.total)}</strong>
      </div>
    </div>
  );
}
export function Checkout() {
  const { cart, products, user, loading, clear, refresh, demo } = useShop();
  const [method, setMethod] = useState("standard"),
    [coupon, setCoupon] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [receipt, setReceipt] = useState<any>(null),
    [couponLoading, setCouponLoading] = useState(true);
  const requestId = useRef("");
  useEffect(() => {
    requestId.current = crypto.randomUUID();
    const code = new URLSearchParams(window.location.search).get("coupon");
    if (code)
      api("coupon", "POST", { code })
        .then(setCoupon)
        .catch((e) => setError(e.message))
        .finally(() => setCouponLoading(false));
    else setCouponLoading(false);
  }, []);
  const subtotal = cart.reduce(
      (s, c) =>
        s + (products.find((p) => p.id === c.id)?.price || 0) * c.quantity,
      0,
    ),
    t = totals(subtotal, method, coupon?.percent, coupon?.maximum);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    setError("");
    const f = new FormData(e.currentTarget);
    const body = {
      id: requestId.current,
      name: f.get("name"),
      phone: f.get("phone"),
      address: f.get("address"),
      note: f.get("note") || "",
      shippingMethod: method,
      payment: "cod",
      coupon: coupon?.code || "",
      items: cart,
    };
    const parsed = checkoutSchema.safeParse(body);
    if (!parsed.success) {
      setError(parsed.error.issues[0].message);
      return;
    }
    setBusy(true);
    try {
      const r = await api("orders", "POST", parsed.data);
      setReceipt({
        ...r,
        name: body.name,
        address: body.address,
        lines: cart.map((c) => ({
          ...c,
          p: products.find((p) => p.id === c.id),
        })),
      });
      clear();
      await refresh();
    } catch (e) {
      setError((e as Error).message);
      await refresh();
    } finally {
      setBusy(false);
    }
  }
  if (receipt)
    return (
      <div className="container receipt page-space">
        <div className="receipt-check">
          <Check size={34} />
        </div>
        <p className="eyebrow red-text">CẢM ƠN BẠN ĐÃ GHÉ POKÉVAULT</p>
        <h1>
          {receipt.demo ? "Đã lưu đơn thử của bạn." : "Đã tiếp nhận đơn hàng."}
        </h1>
        <p>
          {receipt.demo
            ? "Đây là đơn thử được lưu trong hệ thống. Không phát sinh thanh toán hoặc giao hàng."
            : "Đơn hàng đang chờ cửa hàng xác nhận. Bạn chưa thanh toán; thanh toán khi nhận hàng."}
        </p>
        <div className="receipt-card">
          <b>Mã đơn: {receipt.id}</b>
          <span>
            Trạng thái: Chờ xác nhận ·{" "}
            {receipt.demo ? "Đơn thử" : "Chưa thanh toán"}
          </span>
          {receipt.lines.map((l: any) => (
            <div className="receipt-line" key={l.id}>
              <span>
                {l.p?.name} × {l.quantity}
              </span>
              <b>{money((l.p?.price || 0) * l.quantity)}</b>
            </div>
          ))}
          <p>
            Người nhận: {receipt.name}
            <br />
            Địa chỉ: {receipt.address}
          </p>
          <strong>Tổng cộng: {money(receipt.total)}</strong>
        </div>
        <p className="muted">
          {user
            ? "Bạn có thể xem lại đơn tại trang tài khoản."
            : "Hãy lưu mã đơn này. Đơn khách không có trang tra cứu công khai để bảo vệ thông tin người nhận."}
        </p>
        <Link
          className="button primary"
          href={user ? "/tai-khoan" : "/san-pham"}
        >
          {user ? "Xem lịch sử đơn" : "Tiếp tục khám phá"}{" "}
          <ArrowRight size={18} />
        </Link>
      </div>
    );
  if (loading || couponLoading) return <Loading />;
  if (!cart.length)
    return (
      <Empty
        title="Chưa có sản phẩm để thanh toán."
        text="Thêm sản phẩm yêu thích vào giỏ để tiếp tục."
      />
    );
  return (
    <div className="container page-space">
      <Link className="text-link" href="/gio-hang">
        <ArrowLeft size={16} /> Quay lại giỏ hàng
      </Link>
      <h1>Hoàn tất {demo ? "đơn thử" : "đơn hàng"}</h1>
      <div className="notice">
        <ShieldCheck size={22} />
        <p>
          {demo
            ? "Chế độ trải nghiệm: đơn được lưu thật trong cơ sở dữ liệu, nhưng không thu tiền hay gửi hàng. Hãy sử dụng dữ liệu thử."
            : "Đặt hàng thanh toán khi nhận hàng. Đơn sẽ được cửa hàng xác nhận trước khi giao."}
        </p>
      </div>
      <form onSubmit={submit} className="checkout-grid">
        <div className="checkout-fields">
          <h2>Thông tin nhận hàng</h2>
          <p className="muted">Bạn có thể đặt hàng mà không cần tài khoản.</p>
          <div className="form-row">
            <label>
              Họ và tên
              <input
                required
                name="name"
                minLength={2}
                maxLength={100}
                autoComplete="name"
                defaultValue={user?.name}
                placeholder="Nguyễn Minh Anh"
              />
            </label>
            <label>
              Số điện thoại
              <input
                required
                name="phone"
                type="tel"
                pattern="(0|\+84)[0-9]{9}"
                autoComplete="tel"
                defaultValue={user?.phone}
                placeholder="0901234567"
              />
            </label>
          </div>
          <label>
            Địa chỉ giao hàng
            <textarea
              required
              name="address"
              minLength={10}
              maxLength={500}
              autoComplete="street-address"
              defaultValue={user?.address}
              placeholder="Số nhà, đường, phường/xã, tỉnh/thành phố"
              rows={3}
            />
          </label>
          <label>
            Ghi chú <small>(không bắt buộc)</small>
            <textarea
              name="note"
              maxLength={1000}
              placeholder="Có điều gì bạn muốn nhắn với chúng mình?"
              rows={2}
            />
          </label>
          <h2>Phương thức giao hàng</h2>
          {[
            [
              "standard",
              "Giao tiêu chuẩn",
              "Dự kiến 3–5 ngày",
              subtotal >= 699000 ? 0 : 30000,
            ],
            ["express", "Giao nhanh", "Dự kiến 1–2 ngày", 50000],
          ].map(([id, title, desc, fee]) => (
            <label
              className={"choice " + (method === id ? "selected" : "")}
              key={id}
            >
              <input
                type="radio"
                name="shipping"
                value={id}
                checked={method === id}
                onChange={() => setMethod(id as string)}
              />
              <span>
                <b>{title}</b>
                <small>{desc} · Chính sách mẫu</small>
              </span>
              <strong>{fee ? money(fee as number) : "Miễn phí"}</strong>
            </label>
          ))}
          <h2>Phương thức thanh toán</h2>
          <label className="choice selected">
            <input type="radio" checked readOnly name="payment" value="cod" />
            <span>
              <b>Thanh toán khi nhận hàng (COD)</b>
              <small>
                {demo
                  ? "Mô phỏng đặt đơn COD, không thu tiền."
                  : "Thanh toán cho đơn vị giao hàng khi nhận."}
              </small>
            </span>
          </label>
          <p className="muted small">
            Chuyển khoản, ví điện tử và cổng thanh toán chưa được kết nối.
          </p>
        </div>
        <aside className="order-summary">
          <h2>Đơn hàng của bạn</h2>
          {cart.map((c) => {
            const p = products.find((p) => p.id === c.id);
            return (
              <div className="checkout-product" key={c.id}>
                {p ? (
                  <>
                    <img src={productImage(p.image)} alt="" width="64" height="64" />
                    <span>
                      <b>{p.name}</b>
                      <small>Số lượng: {c.quantity}</small>
                    </span>
                    <strong>{money(p.price * c.quantity)}</strong>
                  </>
                ) : (
                  <p>Sản phẩm không còn bán. Vui lòng quay lại giỏ hàng.</p>
                )}
              </div>
            );
          })}
          {coupon && <p className="success-text">Mã ưu đãi: {coupon.code}</p>}
          <Totals value={t} />
          <label className="consent checkout-consent">
            <input type="checkbox" required />{" "}
            <span>
              Tôi đã đọc{" "}
              <Link href="/thong-tin/dieu-khoan" target="_blank">
                điều khoản
              </Link>
              ,{" "}
              <Link href="/thong-tin/bao-mat" target="_blank">
                chính sách bảo mật
              </Link>{" "}
              và hiểu {demo ? "đây là đơn thử." : "điều kiện đặt hàng."}
            </span>
          </label>
          <ErrorMessage error={error} />
          <button
            className="button primary full"
            disabled={
              busy ||
              cart.some(
                (c) =>
                  !products.find((p) => p.id === c.id && p.stock >= c.quantity),
              )
            }
          >
            {busy
              ? "Đang kiểm tra & lưu đơn…"
              : demo
                ? "Xác nhận đặt đơn thử"
                : "Xác nhận đặt hàng"}{" "}
            <ArrowRight size={18} />
          </button>
          <p className="secure-note">
            Chưa có khoản thanh toán nào được xử lý.
          </p>
        </aside>
      </form>
    </div>
  );
}
export function Account() {
  const { user, authLoading, refreshUser, notify } = useShop();
  const [mode, setMode] = useState("login"),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [orders, setOrders] = useState<any[]>([]),
    [ordersError, setOrdersError] = useState(""),
    [ordersLoading, setOrdersLoading] = useState(false);
  useEffect(() => {
    if (user) {
      setOrdersLoading(true);
      api("orders")
        .then((d) => {
          setOrders(d.orders);
          setOrdersError("");
        })
        .catch((e) => setOrdersError(e.message))
        .finally(() => setOrdersLoading(false));
    }
  }, [user]);
  async function auth(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const f = new FormData(e.currentTarget);
    try {
      await api("auth/" + mode, "POST", Object.fromEntries(f));
      await refreshUser();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (authLoading) return <Loading />;
  if (!user)
    return (
      <div className="auth-page container page-space">
        <div className="auth-story">
          <span className="eyebrow">YOUR COLLECTION STARTS HERE</span>
          <h1>
            Một góc nhỏ.
            <br />
            Của riêng bạn.
          </h1>
          <p>Lưu đơn hàng, quản lý thông tin và tiếp tục hành trình sưu tầm.</p>
          <img
            src={productImage("/products/cards.svg")}
            alt="Những thẻ sưu tầm minh họa"
            width="380"
            height="380"
          />
        </div>
        <div className="auth-form">
          <UserRound size={30} />
          <h2>
            {mode === "register"
              ? "Bắt đầu câu chuyện của bạn"
              : "Chào mừng bạn trở lại"}
          </h2>
          <p className="muted">
            {mode === "register"
              ? "Tạo tài khoản để theo dõi những niềm vui."
              : "Đăng nhập vào tài khoản POKÉVAULT."}
          </p>
          <div className="tabs">
            <button
              className={mode === "login" ? "selected" : ""}
              onClick={() => {
                setMode("login");
                setError("");
              }}
            >
              Đăng nhập
            </button>
            <button
              className={mode === "register" ? "selected" : ""}
              onClick={() => {
                setMode("register");
                setError("");
              }}
            >
              Đăng ký
            </button>
          </div>
          <form onSubmit={auth}>
            {mode === "register" && (
              <label>
                Họ và tên
                <input
                  name="name"
                  required
                  minLength={2}
                  maxLength={100}
                  autoComplete="name"
                />
              </label>
            )}
            <label>
              Email
              <input
                name="email"
                type="email"
                required
                autoComplete="email"
                maxLength={200}
              />
            </label>
            <label>
              Mật khẩu
              <input
                name="password"
                type="password"
                required
                minLength={10}
                maxLength={128}
                autoComplete={
                  mode === "register" ? "new-password" : "current-password"
                }
              />
              <small>Ít nhất 10 ký tự.</small>
            </label>
            {mode === "register" && (
              <label className="consent">
                <input type="checkbox" required />
                <span>
                  Tôi đồng ý với{" "}
                  <Link href="/thong-tin/dieu-khoan">điều khoản</Link> và{" "}
                  <Link href="/thong-tin/bao-mat">chính sách bảo mật</Link>.
                </span>
              </label>
            )}
            <ErrorMessage error={error} />
            <button className="button primary full" disabled={busy}>
              {busy
                ? "Đang xử lý…"
                : mode === "login"
                  ? "Đăng nhập"
                  : "Tạo tài khoản"}{" "}
              <ArrowRight size={18} />
            </button>
          </form>
          <details className="forgot">
            <summary>Quên mật khẩu?</summary>
            <p>
              Dịch vụ email chưa được kết nối nên chưa hỗ trợ đặt lại mật khẩu.
              Chủ cửa hàng cần cấu hình email và luồng khôi phục trước khi vận
              hành thật.
            </p>
          </details>
          <p className="small muted">
            Tài khoản hiện dùng để thử nghiệm. Không dùng lại mật khẩu từ tài
            khoản khác.
          </p>
        </div>
      </div>
    );
  return (
    <div className="container page-space">
      <div className="section-head">
        <div>
          <span className="eyebrow red-text">GÓC NHỎ CỦA BẠN</span>
          <h1>Xin chào, {user.name}.</h1>
        </div>
        <button
          className="button secondary"
          onClick={async () => {
            try {
              await api("auth/logout", "POST", {});
              await refreshUser();
            } catch (e) {
              notify((e as Error).message);
            }
          }}
        >
          <LogOut size={17} /> Đăng xuất
        </button>
      </div>
      <div className="account-grid">
        <section className="panel">
          <h2>Thông tin & địa chỉ nhận hàng</h2>
          <p className="muted">{user.email}</p>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setBusy(true);
              setError("");
              try {
                await api(
                  "profile",
                  "PUT",
                  Object.fromEntries(new FormData(e.currentTarget)),
                );
                await refreshUser();
                notify("Đã cập nhật thông tin.");
              } catch (e) {
                setError((e as Error).message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <label>
              Họ và tên
              <input
                name="name"
                defaultValue={user.name}
                required
                minLength={2}
              />
            </label>
            <label>
              Số điện thoại
              <input
                type="tel"
                name="phone"
                defaultValue={user.phone}
                pattern="(0|\+84)[0-9]{9}"
              />
            </label>
            <label>
              Địa chỉ mặc định
              <textarea
                name="address"
                defaultValue={user.address}
                maxLength={500}
                rows={3}
              />
            </label>
            <ErrorMessage error={error} />
            <button className="button primary" disabled={busy}>
              {busy ? "Đang lưu…" : "Lưu thông tin"}
            </button>
          </form>
          <Link className="text-link account-link" href="/yeu-thich">
            <Heart size={17} /> Sản phẩm yêu thích
          </Link>
          {user.role === "admin" && (
            <Link className="text-link account-link" href="/quan-tri">
              Đi tới quản trị <ArrowRight size={17} />
            </Link>
          )}
        </section>
        <section className="panel">
          <h2>Lịch sử đơn hàng</h2>
          <ErrorMessage error={ordersError} />
          {ordersLoading ? (
            <Loading />
          ) : orders.length ? (
            orders.map((o) => (
              <article className="order-history" key={o.id}>
                <div>
                  <b>#{o.id.slice(0, 8).toUpperCase()}</b>
                  <span className="status-pill">{statuses[o.status]}</span>
                </div>
                <p>
                  {new Date(o.createdAt).toLocaleString("vi-VN", {
                    timeZone: "Asia/Bangkok",
                  })}{" "}
                  {o.demo ? "· Đơn thử" : ""}
                </p>
                <strong>{money(o.total)}</strong>
                <small>
                  Chưa thanh toán trực tuyến ·{" "}
                  {o.demo ? "Không giao hàng" : "COD"}
                </small>
              </article>
            ))
          ) : (
            <div className="empty small-empty">
              <Package size={40} />
              <h3>Chưa có đơn hàng nào.</h3>
              <p>Đơn đặt khi đăng nhập sẽ xuất hiện ở đây.</p>
              <Link className="text-link" href="/san-pham">
                Khám phá cửa hàng <ArrowRight size={16} />
              </Link>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
