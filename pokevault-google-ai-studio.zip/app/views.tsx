"use client";
import { useEffect, useState, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  ArrowRight,
  ArrowUpRight,
  Sparkles,
  ShieldCheck,
  Truck,
  Gift,
  Package,
  Heart,
  SlidersHorizontal,
  Search,
  Check,
  Star,
  ZoomIn,
  ChevronRight,
  RotateCcw,
  X,
} from "lucide-react";
import { categories, money, normalize } from "../lib/catalog";
import { productImage } from "../lib/product-art";
import { useShop } from "./context";
import {
  ProductCard,
  SectionHead,
  Empty,
  Loading,
  FAQ,
  ErrorMessage,
  Quantity,
  Dialog,
} from "./ui";
const categoryArt = ["box-yellow", "pack", "cards", "album", "gift"];
export function Home() {
  const { products, loading, error, refresh } = useShop();
  const [tab, setTab] = useState("Nổi bật");
  const displayed =
    tab === "Bán chạy"
      ? [...products]
          .filter((p) => (p.soldCount || 0) > 0)
          .sort((a, b) => (b.soldCount || 0) - (a.soldCount || 0))
          .slice(0, 4)
      : tab === "Mới nhất"
        ? [...products].sort((a, b) => b.createdAt - a.createdAt).slice(0, 4)
        : tab === "Gợi ý sưu tầm"
          ? products
              .filter((p) =>
                ["Phụ kiện", "Thẻ bài", "Quà tặng"].includes(p.category),
              )
              .slice(0, 4)
          : products.slice(0, 4);
  return (
    <>
      <section className="hero">
        <div className="container hero-inner">
          <div className="hero-copy">
            <div className="hero-eyebrow">
              <span /> DÀNH CHO TÂM HỒN SƯU TẦM
            </div>
            <h1>
              Mở một chiếc hộp.
              <br />
              Chạm ngàn
              <br />
              <span>điều bất ngờ.</span>
              <Sparkles className="headline-spark" size={39} />
            </h1>
            <p>
              Một chút tò mò. Một chút háo hức.
              <br />
              Và cả thế giới sưu tầm đang chờ bạn khám phá.
            </p>
            <div className="hero-buttons">
              <Link
                href="/san-pham?category=Mystery%20Box"
                className="button yellow-button"
              >
                Khám phá Mystery Box <ArrowUpRight size={20} />
              </Link>
              <Link href="/san-pham" className="hero-secondary">
                Xem bộ sưu tập <ArrowRight size={17} />
              </Link>
            </div>
            <div className="hero-note">
              <span className="mini-cards">
                <i>✦</i>
                <i>ϟ</i>
                <i>?</i>
              </span>
              <span>
                Niềm vui bắt đầu từ sự tò mò.
                <br />
                <b>Bạn sẽ mở ra điều gì hôm nay?</b>
              </span>
            </div>
          </div>
          <div className="hero-visual">
            <span className="hero-sticker">
              100%<small>NIỀM VUI KHÁM PHÁ</small>
            </span>
            <img
              src="/hero.svg"
              alt="Minh họa hộp Mystery Box vàng cùng những thẻ sưu tầm lấp lánh"
              width="740"
              height="580"
              fetchPriority="high"
            />
            <span className="hero-caption">
              HÌNH MINH HỌA · NỘI DUNG HỘP CÓ THỂ KHÁC
            </span>
          </div>
        </div>
        <div className="hero-bottom">
          <span>COLLECT MOMENTS. COLLECT JOY.</span>
          <span>
            EST. 2026 <span className="tiny-star">✦</span> VIETNAM
          </span>
        </div>
      </section>
      <div className="benefits container">
        <div>
          <ShieldCheck />
          <span>
            <b>Thông tin minh bạch</b>
            <small>Biết rõ trước khi mở hộp</small>
          </span>
        </div>
        <div>
          <Package />
          <span>
            <b>Đóng gói cẩn thận</b>
            <small>Trân trọng từng bộ sưu tập</small>
          </span>
        </div>
        <div>
          <Truck />
          <span>
            <b>Giao hàng toàn quốc</b>
            <small>Chính sách mẫu từ 30.000đ</small>
          </span>
        </div>
        <div>
          <Gift />
          <span>
            <b>Món quà đầy bất ngờ</b>
            <small>Gửi niềm vui đến người thương</small>
          </span>
        </div>
      </div>
      <section className="section container">
        <SectionHead
          eyebrow="TÌM NIỀM VUI CỦA BẠN"
          title="Một thế giới để khám phá"
        >
          <Link className="text-link" href="/san-pham">
            Tất cả danh mục <ArrowUpRight size={18} />
          </Link>
        </SectionHead>
        <div className="categories">
          {categories.map((c, i) => (
            <Link
              className={"category category-" + i}
              key={c}
              href={"/san-pham?category=" + encodeURIComponent(c)}
            >
              <div>
                <img
                  src={productImage("/products/" + categoryArt[i] + ".svg")}
                  alt=""
                  width="120"
                  height="120"
                />
              </div>
              <span>
                {c}
                <ArrowUpRight size={16} />
              </span>
            </Link>
          ))}
        </div>
      </section>
      <section className="section products-section container">
        <SectionHead
          eyebrow="ĐƯỢC CHỌN VÌ NIỀM VUI"
          title="Chiếc hộp dành cho bạn"
        >
          <Link className="text-link" href="/san-pham">
            Xem tất cả sản phẩm <ArrowUpRight size={18} />
          </Link>
        </SectionHead>
        <div className="collection-toolbar">
          <div className="tabs" role="tablist" aria-label="Bộ sưu tập">
            {["Nổi bật", "Mới nhất", "Bán chạy", "Gợi ý sưu tầm"].map((t) => (
              <button
                role="tab"
                aria-selected={tab === t}
                onClick={() => setTab(t)}
                className={tab === t ? "selected" : ""}
                key={t}
              >
                {t}
              </button>
            ))}
          </div>
          <span className="sample-note">Sản phẩm & giá minh họa</span>
        </div>
        {loading ? (
          <Loading />
        ) : error ? (
          <div>
            <ErrorMessage error={error} />
            <button className="button secondary" onClick={refresh}>
              Thử tải lại
            </button>
          </div>
        ) : (
          <div className="product-grid">
            {displayed.map((p) => (
              <ProductCard key={p.id} p={p} />
            ))}
            {!displayed.length && (
              <p className="bestseller-empty">
                Chưa có dữ liệu bán chạy. Danh sách này sẽ dựa trên số lượng sản
                phẩm trong đơn thật đã giao, không tính đơn thử.
              </p>
            )}
          </div>
        )}
      </section>
      <section className="discovery-banner container">
        <div className="discovery-copy">
          <span className="eyebrow">MỘT MÓN QUÀ, NHIỀU CẢM XÚC</span>
          <h2>
            Không cần dịp đặc biệt.
            <br />
            Chỉ cần một người đặc biệt.
          </h2>
          <p>
            Gửi một chiếc hộp. Trao một nụ cười.
            <br />
            Khám phá những combo dành riêng cho người bạn thương.
          </p>
          <Link
            className="button dark-button"
            href="/san-pham?category=Qu%C3%A0%20t%E1%BA%B7ng"
          >
            Chọn quà ngay <ArrowUpRight size={18} />
          </Link>
        </div>
        <div className="gift-art">
          <span className="handwritten">
            a little surprise
            <br />
            just for you ♡
          </span>
          <img
            src={productImage("/products/gift.svg")}
            alt="Hộp quà minh họa màu hồng"
            loading="lazy"
            width="420"
            height="420"
          />
        </div>
      </section>
      <section className="section container how">
        <SectionHead
          eyebrow="THẬT ĐƠN GIẢN, THẬT HÁO HỨC"
          title="Niềm vui chỉ cách bạn 3 bước"
        />
        <div className="steps">
          {[
            [
              "01",
              "Chọn chiếc hộp của bạn",
              "Tìm sản phẩm phù hợp với sở thích và ngân sách.",
              "✦",
            ],
            [
              "02",
              "Chờ một chút, vui một chút",
              "Kiểm tra thông tin, đặt hàng và theo dõi đơn của bạn.",
              "↗",
            ],
            [
              "03",
              "Mở hộp. Bắt đầu câu chuyện.",
              "Khám phá, sưu tầm và chia sẻ niềm vui theo cách riêng.",
              "♡",
            ],
          ].map(([n, t, d, icon]) => (
            <div className="step" key={n}>
              <div className="step-top">
                <span>{n}</span>
                <i>{icon}</i>
              </div>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="about-strip">
        <div className="container about-inner">
          <div>
            <span className="eyebrow">TỪ NHỮNG NGƯỜI YÊU SƯU TẦM</span>
            <h2>
              Không chỉ là những tấm thẻ.
              <br />
              Đó là câu chuyện của bạn.
            </h2>
          </div>
          <div>
            <p>
              POKÉVAULT là ý tưởng về một góc nhỏ dành cho người yêu thẻ bài.
              Chúng mình tin niềm vui nằm ở hành trình khám phá, ở chiếc album
              đầy dần và những khoảnh khắc chia sẻ cùng nhau.
            </p>
            <Link className="text-link" href="/thong-tin/gioi-thieu">
              Gặp gỡ POKÉVAULT <ArrowUpRight size={18} />
            </Link>
          </div>
        </div>
      </section>
      <section className="section container">
        <SectionHead eyebrow="GÓC CHIA SẺ" title="Những niềm vui nho nhỏ">
          <span className="sample-note">
            Đánh giá mẫu để minh họa giao diện
          </span>
        </SectionHead>
        <div className="reviews">
          {[
            [
              "Minh Anh",
              "Người mới sưu tầm",
              "Mình thích cảm giác chờ mở chiếc hộp đầu tiên. Giao diện dễ xem và phần mô tả giúp mình hiểu rõ sản phẩm.",
              "MA",
            ],
            [
              "Hoàng Nam",
              "Yêu những tấm thẻ",
              "Một góc nhỏ rất hợp với người thích sưu tầm. Mình đặc biệt thích những chiếc hộp màu vàng!",
              "HN",
            ],
            [
              "Thu Hà",
              "Tìm một món quà",
              "Có cả combo quà tặng nên mình dễ chọn hơn. Một ý tưởng nhỏ nhưng tạo được nhiều niềm vui.",
              "TH",
            ],
          ].map(([name, role, review, initial]) => (
            <article className="review" key={name}>
              <span className="review-stars" aria-label="5 sao mẫu">
                ★★★★★
              </span>
              <p>“{review}”</p>
              <div className="review-person">
                <span>{initial}</span>
                <div>
                  <b>{name}</b>
                  <small>{role} · Mẫu</small>
                </div>
                <span className="review-mark">”</span>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="section container faq-section">
        <div>
          <p className="eyebrow red-text">BẠN CÒN TÒ MÒ?</p>
          <h2>
            Hỏi một chút.
            <br />
            Hiểu nhiều hơn.
          </h2>
          <p>
            Những điều bạn có thể muốn biết
            <br />
            trước khi bắt đầu hành trình.
          </p>
          <Link className="text-link" href="/thong-tin/faq">
            Tất cả câu hỏi <ArrowUpRight size={17} />
          </Link>
        </div>
        <FAQ />
      </section>
    </>
  );
}
export function Catalog({
  favoritesOnly = false,
}: {
  favoritesOnly?: boolean;
}) {
  return (
    <Suspense fallback={<Loading />}>
      <CatalogContent favoritesOnly={favoritesOnly} />
    </Suspense>
  );
}
function CatalogContent({ favoritesOnly }: { favoritesOnly: boolean }) {
  const params = useSearchParams(),
    { products, loading, error, favorites } = useShop();
  const [query, setQuery] = useState(params.get("q") || ""),
    [category, setCategory] = useState(params.get("category") || ""),
    [price, setPrice] = useState("all"),
    [stock, setStock] = useState(false),
    [filtersOpen, setFiltersOpen] = useState(false),
    [sort, setSort] = useState("featured"),
    [visible, setVisible] = useState(8);
  useEffect(() => {
    setQuery(params.get("q") || "");
    setCategory(params.get("category") || "");
  }, [params]);
  useEffect(() => setVisible(8), [query, category, price, stock, sort]);
  let filtered = products.filter(
    (p) =>
      (!favoritesOnly || favorites.includes(p.id)) &&
      (!category || p.category === category) &&
      (!stock || p.stock > 0) &&
      normalize(p.name + " " + p.description + " " + p.category).includes(
        normalize(query),
      ) &&
      (price === "all" ||
        (price === "low"
          ? p.price < 300000
          : price === "mid"
            ? p.price >= 300000 && p.price <= 1000000
            : p.price > 1000000)),
  );
  if (sort === "best")
    filtered.sort((a, b) => (b.soldCount || 0) - (a.soldCount || 0));
  if (sort === "asc") filtered.sort((a, b) => a.price - b.price);
  if (sort === "desc") filtered.sort((a, b) => b.price - a.price);
  if (sort === "new") filtered.sort((a, b) => b.createdAt - a.createdAt);
  const activeFilters = [
    ...(query
      ? [{ key: "query", label: "Tìm: " + query, clear: () => setQuery("") }]
      : []),
    ...(category
      ? [{ key: "category", label: category, clear: () => setCategory("") }]
      : []),
    ...(price !== "all"
      ? [
          {
            key: "price",
            label:
              price === "low"
                ? "Dưới 300.000đ"
                : price === "mid"
                  ? "300.000đ – 1.000.000đ"
                  : "Trên 1.000.000đ",
            clear: () => setPrice("all"),
          },
        ]
      : []),
    ...(stock
      ? [{ key: "stock", label: "Còn hàng", clear: () => setStock(false) }]
      : []),
  ];
  return (
    <div className="container page-space">
      <p className="breadcrumb">
        <Link href="/">Trang chủ</Link>
        <ChevronRight size={13} />
        {favoritesOnly ? "Yêu thích" : "Cửa hàng"}
      </p>
      <div className="catalog-intro">
        <span className="eyebrow red-text">
          MỖI BỘ SƯU TẬP BẮT ĐẦU TỪ MỘT ĐIỀU NHỎ
        </span>
        <h1>
          {favoritesOnly
            ? "Những món bạn thương."
            : "Tìm điều bất ngờ của bạn."}
        </h1>
        <p>
          Mystery Box, thẻ bài và những món phụ kiện cho hành trình sưu tầm.
        </p>
      </div>
      <div className="catalog-layout">
        <aside className="filters">
          <button
            type="button"
            className="catalog-filter-toggle"
            aria-expanded={filtersOpen}
            aria-controls="catalog-filter-fields"
            onClick={() => setFiltersOpen(!filtersOpen)}
          >
            <SlidersHorizontal size={18} />
            <span>
              Bộ lọc{activeFilters.length ? ` (${activeFilters.length})` : ""}
            </span>
            {filtersOpen ? <X size={17} /> : <ChevronRight size={17} />}
          </button>
          <div
            id="catalog-filter-fields"
            className={"catalog-filter-body " + (filtersOpen ? "is-open" : "")}
          >
            <h3>
              <SlidersHorizontal size={18} /> Bộ lọc
            </h3>
            <label>
              Tìm kiếm
              <div className="input-icon">
                <Search size={17} />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Tên sản phẩm…"
                />
              </div>
            </label>
            <fieldset>
              <legend>Danh mục</legend>
              {["", ...categories].map((c) => (
                <label className="radio-label" key={c}>
                  <input
                    type="radio"
                    checked={category === c}
                    onChange={() => setCategory(c)}
                    name="category"
                  />
                  {c || "Tất cả sản phẩm"}
                </label>
              ))}
            </fieldset>
            <label>
              Khoảng giá
              <select value={price} onChange={(e) => setPrice(e.target.value)}>
                <option value="all">Tất cả mức giá</option>
                <option value="low">Dưới 300.000đ</option>
                <option value="mid">300.000đ – 1.000.000đ</option>
                <option value="high">Trên 1.000.000đ</option>
              </select>
            </label>
            <label className="check-label">
              <input
                type="checkbox"
                checked={stock}
                onChange={(e) => setStock(e.target.checked)}
              />{" "}
              Chỉ sản phẩm còn hàng
            </label>
            <button
              className="text-link"
              onClick={() => {
                setCategory("");
                setPrice("all");
                setStock(false);
                setQuery("");
              }}
            >
              Xóa bộ lọc <RotateCcw size={14} />
            </button>
            <div className="filter-note">
              <Sparkles size={20} />
              <b>Một chút bất ngờ mỗi ngày.</b>
              <p>
                Danh mục hiện dùng dữ liệu mẫu. Hãy đọc mô tả trước khi đặt thử.
              </p>
            </div>
          </div>
        </aside>
        <div>
          <div className="catalog-toolbar">
            <span>
              {filtered.length} sản phẩm <small>· Dữ liệu mẫu</small>
            </span>
            <label>
              Sắp xếp{" "}
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="featured">Nổi bật</option>
                <option value="new">Mới nhất</option>
                <option value="best">Bán chạy</option>
                <option value="asc">Giá tăng dần</option>
                <option value="desc">Giá giảm dần</option>
              </select>
            </label>
          </div>
          {!!activeFilters.length && (
            <div
              className="catalog-active-filters"
              aria-label="Bộ lọc đang áp dụng"
            >
              <span>Đang chọn:</span>
              {activeFilters.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  onClick={item.clear}
                  aria-label={"Bỏ bộ lọc " + item.label}
                >
                  {item.label}
                  <X size={13} />
                </button>
              ))}
            </div>
          )}
          {loading ? (
            <Loading />
          ) : error ? (
            <ErrorMessage error={error} />
          ) : filtered.length ? (
            <>
              <div className="product-grid catalog-grid">
                {filtered.slice(0, visible).map((p) => (
                  <ProductCard p={p} key={p.id} />
                ))}
              </div>
              {visible < filtered.length && (
                <button
                  className="button secondary load-more"
                  onClick={() => setVisible((v) => v + 8)}
                >
                  Xem thêm sản phẩm <ArrowRight size={17} />
                </button>
              )}
            </>
          ) : (
            <Empty
              title="Chưa tìm thấy điều bạn muốn."
              text="Thử từ khóa khác hoặc xóa bớt bộ lọc để khám phá thêm."
            />
          )}
        </div>
      </div>
    </div>
  );
}
export function ProductDetail({ id }: { id: string }) {
  const { products, loading, error, refresh, cart, add, favorite, favorites } =
      useShop(),
    router = useRouter();
  const [quantity, setQuantity] = useState(1),
    [imageIndex, setImageIndex] = useState(0),
    [zoom, setZoom] = useState(false);
  const p = products.find((p) => p.id === id);
  const inCart = cart.find((item) => item.id === id)?.quantity || 0;
  const available = Math.max(0, Math.min(p?.stock || 0, 20) - inCart);
  const selectedQuantity = Math.max(1, Math.min(quantity, available));
  useEffect(() => {
    setQuantity(1);
    setImageIndex(0);
  }, [id]);
  useEffect(() => {
    setQuantity((value) => Math.max(1, Math.min(value, available)));
  }, [available]);
  useEffect(() => {
    if (p) document.title = p.name + " | POKÉVAULT";
  }, [p]);
  if (loading) return <Loading />;
  if (error)
    return (
      <div className="container page-space">
        <ErrorMessage error={error} />
        <button className="button secondary" onClick={refresh}>
          Thử tải lại
        </button>
      </div>
    );
  if (!p)
    return (
      <Empty
        title="Sản phẩm chưa có ở đây."
        text="Sản phẩm có thể đã được ẩn hoặc thay đổi."
      />
    );
  const images = [
    productImage(p.image),
    productImage(
      p.category === "Mystery Box" ? "/products/cards.svg" : p.image,
    ),
  ];
  return (
    <div className="container page-space">
      <p className="breadcrumb">
        <Link href="/">Trang chủ</Link>
        <ChevronRight size={13} />
        <Link href="/san-pham">Cửa hàng</Link>
        <ChevronRight size={13} />
        {p.name}
      </p>
      <div className="detail-grid">
        <div>
          <button
            className={"detail-image " + p.color}
            onClick={() => setZoom(true)}
            aria-label="Phóng to ảnh sản phẩm"
          >
            <img
              src={images[imageIndex]}
              alt={"Hình minh họa " + p.name}
              width="520"
              height="520"
            />
            <ZoomIn size={22} />
            <span>Ảnh minh họa · Có thể khác sản phẩm thực tế</span>
          </button>
          <div className="thumbnails">
            {images.map((src, i) => (
              <button
                key={i}
                className={i === imageIndex ? "active" : ""}
                onClick={() => setImageIndex(i)}
                aria-label={"Xem ảnh " + (i + 1)}
              >
                <img
                  src={src}
                  alt={"Góc minh họa " + (i + 1)}
                  width="72"
                  height="72"
                />
              </button>
            ))}
            <small>
              {imageIndex === 1 && p.category === "Mystery Box"
                ? "Minh họa nhóm thẻ có thể xuất hiện; không bảo đảm nội dung này."
                : "Hình tự thiết kế, không phải ảnh sản phẩm chính thức."}
            </small>
          </div>
        </div>
        <div className="detail-copy">
          <p className="eyebrow red-text">
            {p.category} / POKÉVAULT COLLECTION
          </p>
          <h1>{p.name}</h1>
          <span className={"stock " + (!p.stock ? "out" : "")}>
            {p.stock ? `● Còn ${p.stock} sản phẩm mẫu` : "○ Tạm hết hàng"}
          </span>
          <div className="detail-price">
            <strong>{money(p.price)}</strong>
            {p.oldPrice > p.price && <del>{money(p.oldPrice)}</del>}
            <span>Giá minh họa</span>
          </div>
          <p>{p.description}</p>
          <div className="product-disclosure">
            <ShieldCheck size={21} />
            <div>
              <b>Niềm vui bất ngờ, thông tin rõ ràng.</b>
              <p>
                {p.category === "Mystery Box"
                  ? "Có thể gồm thẻ bài, booster và phụ kiện. Số lượng, nội dung bảo đảm chưa được công bố. Không cam kết thẻ hiếm, tỷ lệ xuất hiện hay giá trị bán lại."
                  : "Đây là sản phẩm mẫu để trải nghiệm website. Thông số và xuất xứ phải được xác nhận trước khi mở bán."}
              </p>
            </div>
          </div>
          <label className="field-label">Phiên bản</label>
          <span className="variant selected">
            {(p.category === "Mystery Box" && p.name.split("·")[1]?.trim()) ||
              "Tiêu chuẩn"}{" "}
            <Check size={14} />
          </span>
          <div className="detail-buy">
            <Quantity
              value={selectedQuantity}
              max={Math.max(1, available)}
              onChange={setQuantity}
            />
            <button
              className="button primary"
              disabled={!available}
              onClick={() => add(p.id, selectedQuantity)}
            >
              <PlusIcon />{" "}
              {available
                ? "Thêm vào giỏ hàng"
                : p.stock
                  ? "Đã đạt giới hạn"
                  : "Tạm hết hàng"}
            </button>
            <button
              className={
                "icon-button favorite-detail " +
                (favorites.includes(p.id) ? "selected" : "")
              }
              aria-label="Yêu thích sản phẩm"
              onClick={() => favorite(p.id)}
            >
              <Heart
                fill={favorites.includes(p.id) ? "currentColor" : "none"}
              />
            </button>
          </div>
          <button
            disabled={!available}
            className="button dark-button full"
            onClick={() => {
              if (add(p.id, selectedQuantity)) router.push("/gio-hang");
            }}
          >
            Mua ngay <ArrowRight size={18} />
          </button>
          {inCart > 0 && (
            <p className="small muted" aria-live="polite">
              Bạn đã có {inCart} sản phẩm này trong giỏ.{" "}
              <Link href="/gio-hang">Xem giỏ hàng ↗</Link>
            </p>
          )}
          <div className="detail-perks">
            <span>
              <Truck size={17} /> Freeship mẫu từ 699.000đ
            </span>
            <span>
              <ShieldCheck size={17} /> Kiểm tra thông tin trước khi đặt
            </span>
          </div>
        </div>
      </div>
      <div className="detail-info">
        <details open>
          <summary>Mô tả & thông tin cần biết</summary>
          <p>
            {p.description} Tất cả hình ảnh, giá và tồn kho ở bản này là dữ liệu
            minh họa. Sản phẩm cần được xác minh về thương hiệu, nguồn gốc, kích
            thước và nội dung trước khi bán.
          </p>
          {p.category === "Mystery Box" && (
            <p>
              Nội dung hộp ngẫu nhiên. Chưa công bố số lượng vật phẩm, tỷ lệ
              xuất hiện hoặc vật phẩm bảo đảm. Ảnh thẻ chỉ minh họa nhóm sản
              phẩm, không phải cam kết bạn sẽ nhận thẻ đó.
            </p>
          )}
        </details>
        <details>
          <summary>Giao hàng & đổi trả</summary>
          <p>
            Chính sách mẫu: giao tiêu chuẩn 3–5 ngày với phí 30.000đ, miễn phí
            từ 699.000đ; giao nhanh 1–2 ngày với phí 50.000đ. Liên hệ trong 7
            ngày nếu nhận sai hàng hoặc hàng có lỗi.
          </p>
          <Link className="text-link" href="/thong-tin/doi-tra">
            Xem điều kiện đổi trả <ArrowUpRight size={15} />
          </Link>
        </details>
        <details>
          <summary>Đánh giá sản phẩm</summary>
          <p>Chưa có đánh giá đã xác minh cho sản phẩm này.</p>
        </details>
      </div>
      <section className="section">
        <SectionHead title="Có thể bạn cũng thích" />
        <div className="product-grid">
          {products
            .filter((v) => v.id !== id)
            .slice(0, 4)
            .map((v) => (
              <ProductCard key={v.id} p={v} />
            ))}
        </div>
      </section>
      <section className="section">
        <SectionHead title="Trước khi mở hộp" />
        <FAQ />
      </section>
      <Dialog open={zoom} onClose={() => setZoom(false)} title={p.name}>
        <img className="zoom-image" src={images[imageIndex]} alt={p.name} />
      </Dialog>
    </div>
  );
}
function PlusIcon() {
  return <span aria-hidden="true">＋</span>;
}
const info: Record<
  string,
  { title: string; intro: string; sections: [string, string][] }
> = {
  "gioi-thieu": {
    title: "Cho niềm vui sưu tầm.",
    intro:
      "POKÉVAULT là thương hiệu mẫu cho cửa hàng Mystery Box và thẻ bài tại Việt Nam.",
    sections: [
      [
        "Câu chuyện bắt đầu từ sự tò mò",
        "Một chiếc hộp mới, một trang album mới và một câu chuyện để kể. Chúng mình xây dựng một trải nghiệm sưu tầm thân thiện, dễ khám phá và minh bạch về thông tin.",
      ],
      [
        "Những điều chúng mình hướng đến",
        "Mô tả rõ ràng, đóng gói cẩn thận và hỗ trợ người sưu tầm. Đây là định hướng của cửa hàng; quy trình thực tế cần được thiết lập trước khi mở bán.",
      ],
      [
        "Hình ảnh & thương hiệu",
        "Hình minh họa hộp và thẻ được tự thiết kế cho bản mẫu. POKÉVAULT không đại diện hoặc được chứng nhận bởi Pokémon. Chủ cửa hàng cần xác nhận quyền sử dụng các tên, ảnh và nội dung liên quan trước khi vận hành.",
      ],
    ],
  },
  "lien-he": {
    title: "Chúng mình ở đây.",
    intro:
      "Thông tin liên hệ đang chờ chủ cửa hàng bổ sung. Chưa có kênh hỗ trợ hoạt động trong bản mẫu.",
    sections: [
      [
        "Email & điện thoại",
        "[CẦN CẬP NHẬT] Email hỗ trợ và số điện thoại của cửa hàng.",
      ],
      [
        "Địa chỉ & giờ làm việc",
        "[CẦN CẬP NHẬT] Địa chỉ kinh doanh, địa chỉ nhận hàng đổi trả và giờ hỗ trợ.",
      ],
      [
        "Cộng đồng sưu tầm",
        "[CẦN CẬP NHẬT] Đường dẫn Facebook, TikTok và Instagram chính thức. Không sử dụng các tài khoản trùng tên chưa được xác minh.",
      ],
    ],
  },
  "giao-hang": {
    title: "Chính sách giao hàng",
    intro:
      "NỘI DUNG MẪU — cần chủ cửa hàng kiểm tra và phê duyệt trước khi sử dụng.",
    sections: [
      [
        "Phí vận chuyển mẫu",
        "Tiêu chuẩn: 30.000đ, miễn phí cho giá trị hàng từ 699.000đ trước giảm giá. Nhanh: 50.000đ. Phí này được tính ở cả giao diện và máy chủ.",
      ],
      [
        "Thời gian dự kiến",
        "Tiêu chuẩn 3–5 ngày và nhanh 1–2 ngày là thông tin mẫu; chưa có đối tác vận chuyển kết nối. Thời gian thật tùy địa chỉ và xác nhận của cửa hàng.",
      ],
      [
        "Nhận hàng",
        "Kiểm tra tình trạng bao bì. Nếu có dấu hiệu hư hại, chụp ảnh hoặc lưu bằng chứng để cửa hàng hỗ trợ. Bản mẫu không gửi hàng thật.",
      ],
    ],
  },
  "doi-tra": {
    title: "Đổi trả & hoàn tiền",
    intro:
      "NỘI DUNG MẪU — cần được rà soát và bổ sung theo quy trình thực tế trước khi áp dụng.",
    sections: [
      [
        "Trường hợp được hỗ trợ",
        "Dự kiến hỗ trợ trong 7 ngày với hàng giao sai hoặc lỗi do sản phẩm. Cần cung cấp mã đơn, mô tả vấn đề và bằng chứng nhận hàng.",
      ],
      [
        "Điều kiện đối với Mystery Box",
        "Nội dung ngẫu nhiên không phù hợp sở thích không mặc nhiên là lỗi. Cửa hàng cần công bố đầy đủ điều kiện về niêm phong, hàng đã mở, hàng lỗi và các quyền áp dụng trước khi bán.",
      ],
      [
        "Hoàn tiền",
        "Phương thức, thời gian, phí vận chuyển hoàn trả và địa chỉ tiếp nhận đang chờ xác nhận. Bản mẫu không xử lý thanh toán hay hoàn tiền thật.",
      ],
    ],
  },
  "bao-mat": {
    title: "Chính sách bảo mật",
    intro:
      "NỘI DUNG MẪU — cần bổ sung thông tin đơn vị kiểm soát dữ liệu và rà soát trước khi vận hành.",
    sections: [
      [
        "Dữ liệu được lưu",
        "Tài khoản lưu email, tên, mật khẩu đã băm, số điện thoại và địa chỉ khi bạn cung cấp. Đơn hàng lưu sản phẩm, giá, thông tin người nhận và trạng thái. Email bản tin chỉ được lưu khi bạn đồng ý.",
      ],
      [
        "Mục đích sử dụng",
        "Xử lý tài khoản, đơn hàng và đăng ký bản tin. Bản mẫu chưa gửi email hoặc chuyển thông tin cho đơn vị vận chuyển. Giỏ hàng và sản phẩm yêu thích lưu trên trình duyệt; phiên đăng nhập sử dụng cookie HttpOnly.",
      ],
      [
        "Lưu trữ & quyền của bạn",
        "Chủ cửa hàng cần quy định thời hạn lưu dữ liệu, quy trình truy cập/chỉnh sửa/xóa và đầu mối tiếp nhận yêu cầu trước khi mở bán. Trong thời gian thử nghiệm, chỉ nên sử dụng dữ liệu thử.",
      ],
    ],
  },
  "dieu-khoan": {
    title: "Điều khoản sử dụng",
    intro: "NỘI DUNG MẪU — chưa phải điều khoản thương mại hoàn chỉnh.",
    sections: [
      [
        "Phạm vi bản mẫu",
        "Đây là website trình diễn có lưu tài khoản và đơn thử trong cơ sở dữ liệu. Giá, tồn kho, đánh giá và chính sách là dữ liệu mẫu. Đơn thử không tạo giao dịch thanh toán hoặc giao hàng.",
      ],
      [
        "Thông tin sản phẩm",
        "Nội dung Mystery Box có thể khác hình minh họa. Không có cam kết độ hiếm, tỷ lệ trúng hay lợi nhuận từ sưu tầm. Hãy đọc nội dung sản phẩm trước khi đặt.",
      ],
      [
        "Trước khi vận hành thật",
        "Chủ cửa hàng cần bổ sung pháp nhân, liên hệ, điều kiện mua bán, quy trình khiếu nại và xác nhận quyền sử dụng tài sản thương hiệu.",
      ],
    ],
  },
};
export function Information({ slug }: { slug: string }) {
  if (slug === "faq")
    return (
      <div className="container information page-space">
        <p className="eyebrow red-text">MỘT CHÚT GIẢI ĐÁP</p>
        <h1>Câu hỏi thường gặp</h1>
        <p className="lead">Hiểu rõ hơn để trải nghiệm mở hộp vui hơn.</p>
        <FAQ />
      </div>
    );
  const p = info[slug];
  if (!p)
    return (
      <Empty
        title="Trang này chưa có trong bộ sưu tập."
        text="Quay về cửa hàng và tiếp tục khám phá nhé."
      />
    );
  return (
    <div className="container information page-space">
      <p className="breadcrumb">
        <Link href="/">Trang chủ</Link>
        <ChevronRight size={13} />
        {p.title}
      </p>
      <h1>{p.title}</h1>
      <p className="lead">{p.intro}</p>
      {p.sections.map(([t, c]) => (
        <section key={t}>
          <h2>{t}</h2>
          <p>{c}</p>
        </section>
      ))}
      <Link className="button secondary" href="/san-pham">
        Trở lại khám phá <ArrowRight size={18} />
      </Link>
    </div>
  );
}
