"use client";
import Link from "next/link";
import { useRef, useEffect, useState, type ReactNode } from "react";
import {
  ArrowUpRight,
  Heart,
  Plus,
  Minus,
  X,
  PackageOpen,
  Eye,
  ShoppingBag,
} from "lucide-react";
import { Product, money } from "../lib/catalog";
import { productImage } from "../lib/product-art";
import { useShop } from "./context";
export function ProductCard({ p }: { p: Product }) {
  const { add, favorite, favorites, cart, setDrawer } = useShop();
  const [quickOpen, setQuickOpen] = useState(false);
  const [quickQuantity, setQuickQuantity] = useState(1);
  const inCart = cart.find((item) => item.id === p.id)?.quantity || 0;
  const available = Math.max(0, Math.min(p.stock, 20) - inCart);
  useEffect(() => {
    setQuickQuantity((quantity) => Math.max(1, Math.min(quantity, available)));
  }, [available]);
  return (
    <article className="product-card">
      <div className={`product-art ${p.color}`}>
        <Link href={"/san-pham/" + p.id} aria-label={"Xem " + p.name}>
          <img
            src={productImage(p.image)}
            alt={"Hình minh họa " + p.name}
            loading="lazy"
            width="420"
            height="420"
          />
        </Link>
        {p.badge && (
          <span
            className={"product-badge " + (p.color === "dark" ? "gold" : "")}
          >
            {p.badge}
          </span>
        )}
        <button
          className={"favorite " + (favorites.includes(p.id) ? "selected" : "")}
          aria-label={
            (favorites.includes(p.id) ? "Bỏ yêu thích " : "Yêu thích ") + p.name
          }
          onClick={() => favorite(p.id)}
        >
          <Heart
            size={18}
            fill={favorites.includes(p.id) ? "currentColor" : "none"}
          />
        </button>
        <button
          type="button"
          className="studio-quick-view"
          aria-label={"Xem nhanh " + p.name}
          onClick={() => {
            setQuickQuantity(1);
            setQuickOpen(true);
          }}
        >
          <Eye size={16} /> Xem nhanh
        </button>
      </div>
      <div className="product-info">
        <span className="eyebrow muted">{p.category}</span>
        <Link href={"/san-pham/" + p.id}>
          <h3>{p.name}</h3>
        </Link>
        <p className="product-desc">{p.description}</p>
        <div className="product-bottom">
          <div>
            <strong>{money(p.price)}</strong>
            {p.oldPrice > p.price && <del>{money(p.oldPrice)}</del>}
          </div>
          <button
            className="add-button"
            disabled={!available}
            onClick={() => add(p.id)}
            aria-label={
              available
                ? "Thêm " + p.name + " vào giỏ"
                : p.stock
                  ? p.name + " đã đạt giới hạn trong giỏ"
                  : p.name + " tạm hết hàng"
            }
          >
            <Plus size={20} />
          </button>
        </div>
        <span className={"stock " + (!p.stock ? "out" : "")}>
          {p.stock ? "● Còn hàng" : "○ Tạm hết hàng"}
        </span>
      </div>
      <Dialog
        open={quickOpen}
        onClose={() => setQuickOpen(false)}
        title="Khám phá nhanh"
        className="studio-quick-modal"
      >
        <div className="studio-quick-dialog">
          <div className={"studio-quick-art " + p.color}>
            <img
              src={productImage(p.image)}
              alt={"Hình minh họa " + p.name}
              width={420}
              height={420}
            />
          </div>
          <div className="studio-quick-copy">
            <p className="eyebrow red-text">{p.category} / POKÉVAULT</p>
            <h3>{p.name}</h3>
            <p>{p.description}</p>
            <span className={"stock " + (!p.stock ? "out" : "")}>
              {p.stock ? `● Còn ${p.stock} sản phẩm mẫu` : "○ Tạm hết hàng"}
            </span>
            <div className="studio-quick-price">
              <strong>{money(p.price)}</strong>
              {p.oldPrice > p.price && <del>{money(p.oldPrice)}</del>}
            </div>
            <div className="studio-quick-actions">
              <Quantity
                value={quickQuantity}
                max={Math.max(1, available)}
                onChange={setQuickQuantity}
              />
              <button
                type="button"
                className="button primary"
                disabled={!available}
                onClick={() => {
                  if (quickQuantity > available) return;
                  if (add(p.id, quickQuantity)) {
                    setQuickOpen(false);
                    setDrawer(true);
                  }
                }}
              >
                <ShoppingBag size={17} />{" "}
                {p.stock
                  ? available
                    ? "Thêm vào giỏ"
                    : "Đã đạt giới hạn"
                  : "Tạm hết hàng"}
              </button>
            </div>
            {inCart > 0 && (
              <p className="small muted">
                Bạn đã có {inCart} sản phẩm này trong giỏ.{" "}
                <Link href="/gio-hang" onClick={() => setQuickOpen(false)}>
                  Xem giỏ hàng ↗
                </Link>
              </p>
            )}
            <Link
              className="text-link"
              href={"/san-pham/" + p.id}
              onClick={() => setQuickOpen(false)}
            >
              Xem đầy đủ chi tiết <ArrowUpRight size={17} />
            </Link>
            <p className="studio-quick-note">
              Ảnh và giá minh họa.{" "}
              {p.category === "Mystery Box"
                ? "Nội dung hộp ngẫu nhiên; không cam kết thẻ hiếm hoặc giá trị vật phẩm."
                : "Thông số sản phẩm cần được cửa hàng xác nhận trước khi mở bán."}
            </p>
          </div>
        </div>
      </Dialog>
    </article>
  );
}
export function Quantity({
  value,
  max = 20,
  onChange,
}: {
  value: number;
  max?: number;
  onChange: (q: number) => void;
}) {
  return (
    <div className="quantity">
      <button
        aria-label="Giảm số lượng"
        disabled={value <= 1}
        onClick={() => onChange(value - 1)}
        type="button"
      >
        <Minus size={14} />
      </button>
      <span aria-live="polite">{value}</span>
      <button
        type="button"
        aria-label="Tăng số lượng"
        disabled={value >= max}
        onClick={() => onChange(value + 1)}
      >
        <Plus size={14} />
      </button>
    </div>
  );
}
export function SectionHead({
  eyebrow,
  title,
  children,
}: {
  eyebrow?: string;
  title: string;
  children?: ReactNode;
}) {
  return (
    <div className="section-head">
      <div>
        {eyebrow && <p className="eyebrow red-text">{eyebrow}</p>}
        <h2>{title}</h2>
      </div>
      {children}
    </div>
  );
}
export function Empty({ title, text }: { title: string; text: string }) {
  return (
    <div className="empty">
      <PackageOpen size={54} strokeWidth={1.2} />
      <h2>{title}</h2>
      <p>{text}</p>
      <Link className="button primary" href="/san-pham">
        Khám phá cửa hàng <ArrowUpRight size={18} />
      </Link>
    </div>
  );
}
export function Dialog({
  open,
  onClose,
  children,
  title,
  drawer = false,
  className = "",
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  title: string;
  drawer?: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!open) {
      if (d?.open) d.close();
      return;
    }
    if (!d?.open) d?.showModal();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);
  return (
    <dialog
      ref={ref}
      className={`${drawer ? "dialog drawer" : "dialog"} ${className}`.trim()}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === ref.current) onClose();
      }}
      aria-label={title}
    >
      <div className="dialog-content">
        <div className="dialog-head">
          <h2>{title}</h2>
          <button className="icon-button" onClick={onClose} aria-label="Đóng">
            <X />
          </button>
        </div>
        {children}
      </div>
    </dialog>
  );
}
export function ErrorMessage({ error }: { error: string }) {
  return error ? (
    <p className="form-error" role="alert">
      {error}
    </p>
  ) : null;
}
export function Loading() {
  return (
    <div className="loading" role="status">
      <span className="spinner" /> Đang mở cánh cửa khám phá…
    </div>
  );
}
export const faqs = [
  [
    "Mystery Box có những gì bên trong?",
    "Hộp có thể gồm thẻ bài, gói booster hoặc phụ kiện. Hiện đây là danh mục minh họa; số lượng, nội dung bảo đảm và phiên bản cần được cửa hàng xác nhận trước khi mở bán. Không có cam kết về độ hiếm hay giá trị bán lại.",
  ],
  [
    "Mình có được chọn thẻ trong hộp không?",
    "Nội dung của Mystery Box là ngẫu nhiên, bạn không chọn từng thẻ. Nếu muốn một sản phẩm cụ thể, hãy xem danh mục Thẻ bài hoặc Phụ kiện.",
  ],
  [
    "Bao lâu thì mình nhận được hàng?",
    "Chính sách mẫu: giao tiêu chuẩn dự kiến 3–5 ngày, giao nhanh 1–2 ngày. Thời gian thực tế cần được xác nhận theo địa chỉ và đơn vị vận chuyển.",
  ],
  [
    "Mình có thể đổi trả sản phẩm không?",
    "Chính sách mẫu: liên hệ trong 7 ngày nếu nhận sai hàng hoặc hàng có lỗi. Giữ nguyên bao bì và bằng chứng nhận hàng. Nội dung ngẫu nhiên không đúng sở thích không được xem là lỗi. Điều kiện cuối cùng cần chủ cửa hàng phê duyệt.",
  ],
];
export function FAQ() {
  return (
    <div className="faq-list">
      {faqs.map(([q, a]) => (
        <details key={q}>
          <summary>
            {q}
            <Plus size={18} />
          </summary>
          <p>{a}</p>
        </details>
      ))}
    </div>
  );
}
