import { seedProducts } from "../lib/catalog";
export default function sitemap() {
  const base = process.env.APP_URL || "http://localhost:3000";
  return [
    "",
    "/san-pham",
    "/thong-tin/gioi-thieu",
    "/thong-tin/faq",
    ...seedProducts.map((p) => "/san-pham/" + p.id),
  ].map((p) => ({ url: base + p }));
}
