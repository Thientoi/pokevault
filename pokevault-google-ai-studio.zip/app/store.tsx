"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Search,
  UserRound,
  ShoppingBag,
  Heart,
  ArrowRight,
  Zap,
  Menu,
  Truck,
  X,
  ArrowUpRight,
} from "lucide-react";
import { ShopProvider, useShop, api } from "./context";
import { Catalog, ProductDetail, Information } from "./views";
import { HomeStudio } from "./home-studio";
import { Cart, Checkout, Account, CartDrawer } from "./commerce";
import { Admin } from "./admin";
const nav = [
  ["Trang chủ", "/"],
  ["Mystery Box", "/san-pham?category=Mystery%20Box"],
  ["Booster", "/san-pham?category=Booster"],
  ["Thẻ bài", "/san-pham?category=Th%E1%BA%BB%20b%C3%A0i"],
  ["Phụ kiện", "/san-pham?category=Ph%E1%BB%A5%20ki%E1%BB%87n"],
  ["Quà tặng", "/san-pham?category=Qu%C3%A0%20t%E1%BA%B7ng"],
  ["Về POKÉVAULT", "/thong-tin/gioi-thieu"],
];
function Header() {
  const { cart, setDrawer, favorites, user } = useShop();
  const [query, setQuery] = useState(""),
    [menu, setMenu] = useState(false);
  const router = useRouter(),
    path = usePathname();
  useEffect(() => {
    setMenu(false);
  }, [path]);
  return (
    <>
      <div className="announcement">
        <span>
          <Truck size={14} /> Freeship mẫu cho đơn từ <b>699.000đ</b>
        </span>
        <span>
          COLLECT SOMETHING THAT MAKES YOU HAPPY <Zap size={13} />
        </span>
        <Link href="/quan-tri">
          Quản trị cửa hàng <ArrowUpRight size={13} />
        </Link>
      </div>
      <header className="header">
        <div className="header-main container">
          <Link className="brand" href="/" aria-label="POKÉVAULT Trang chủ">
            <span className="brand-icon">
              <Zap size={26} fill="currentColor" />
            </span>
            POKÉ<span>VAULT</span>
          </Link>
          <form
            className="search"
            role="search"
            onSubmit={(e) => {
              e.preventDefault();
              router.push("/san-pham?q=" + encodeURIComponent(query));
              setMenu(false);
            }}
          >
            <Search size={19} />
            <input
              aria-label="Tìm kiếm sản phẩm"
              placeholder="Tìm chiếc hộp bất ngờ của bạn…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <kbd>↵</kbd>
          </form>
          <div className="header-actions">
            <Link
              href="/yeu-thich"
              className="icon-button desktop-icon"
              aria-label={"Sản phẩm yêu thích: " + favorites.length}
            >
              <Heart size={21} />
            </Link>
            <Link
              href="/tai-khoan"
              className="icon-button"
              aria-label={
                user ? "Tài khoản của " + user.name : "Đăng nhập tài khoản"
              }
            >
              <UserRound size={21} />
            </Link>
            <span className="header-divider" />
            <button className="cart-button" onClick={() => setDrawer(true)}>
              <ShoppingBag size={21} />
              <span className="cart-label">Giỏ hàng</span>
              <b>{cart.reduce((s, c) => s + c.quantity, 0)}</b>
            </button>
            <button
              className="icon-button mobile-menu"
              aria-label="Mở menu"
              aria-expanded={menu}
              onClick={() => setMenu(!menu)}
            >
              {menu ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        <div className={"nav-wrap " + (menu ? "is-open" : "")}>
          <nav className="container nav" aria-label="Điều hướng chính">
            <div>
              {nav.map(([label, href], i) => (
                <Link
                  key={href}
                  href={href}
                  className={path === href ? "active" : ""}
                  onClick={() => setMenu(false)}
                >
                  {label}
                  {i === 1 && <span className="hot-dot" />}
                </Link>
              ))}
            </div>
            <Link
              className="nav-gift"
              href="/san-pham?category=Qu%C3%A0%20t%E1%BA%B7ng"
            >
              Một chút bất ngờ, gửi người thương <ArrowUpRight size={15} />
            </Link>
          </nav>
        </div>
      </header>
    </>
  );
}
function Footer() {
  const { notify, demo } = useShop();
  const [busy, setBusy] = useState(false);
  return (
    <>
      <section className="newsletter">
        <div className="container newsletter-inner">
          <div>
            <p className="eyebrow">ĐỪNG BỎ LỠ ĐIỀU BẤT NGỜ</p>
            <h2>Hộp thư cũng cần một chút niềm vui.</h2>
            <p>Nhận tin về bộ sưu tập mới và ưu đãi của POKÉVAULT.</p>
          </div>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              const form = e.currentTarget;
              const data = new FormData(form);
              setBusy(true);
              try {
                const d = await api("newsletter", "POST", {
                  email: data.get("email"),
                  consent: data.get("consent") === "on",
                });
                notify(d.message);
                form.reset();
              } catch (e) {
                notify((e as Error).message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <div className="newsletter-input">
              <input
                name="email"
                type="email"
                required
                aria-label="Email nhận bản tin"
                placeholder="Email của bạn"
              />
              <button disabled={busy} aria-label="Đăng ký bản tin">
                {busy ? "…" : <ArrowRight size={22} />}
              </button>
            </div>
            <label className="consent">
              <input type="checkbox" name="consent" required /> Tôi đồng ý nhận
              tin về sản phẩm và ưu đãi qua email. Có thể hủy bất cứ lúc nào.
            </label>
          </form>
        </div>
      </section>
      <footer className="footer container">
        <div className="footer-grid">
          <div className="footer-about">
            <Link className="brand" href="/">
              <span className="brand-icon">
                <Zap size={24} fill="currentColor" />
              </span>
              POKÉ<span>VAULT</span>
            </Link>
            <p>
              Cho niềm vui sưu tầm.
              <br />
              Cho những bất ngờ bé nhỏ mỗi ngày.
            </p>
            <span className="demo-label">
              {demo ? "CỬA HÀNG MẪU · CHƯA MỞ BÁN" : "CỬA HÀNG TRỰC TUYẾN"}
            </span>
          </div>
          <div>
            <h4>Cùng khám phá</h4>
            <Link href="/san-pham">Tất cả sản phẩm</Link>
            <Link href="/san-pham?category=Mystery%20Box">Mystery Box</Link>
            <Link href="/san-pham?category=Qu%C3%A0%20t%E1%BA%B7ng">
              Quà tặng & combo
            </Link>
            <Link href="/thong-tin/gioi-thieu">Câu chuyện của chúng mình</Link>
          </div>
          <div>
            <h4>Luôn ở đây hỗ trợ</h4>
            <Link href="/thong-tin/faq">Câu hỏi thường gặp</Link>
            <Link href="/thong-tin/giao-hang">Chính sách giao hàng</Link>
            <Link href="/thong-tin/doi-tra">Đổi trả & hoàn tiền</Link>
            <Link href="/thong-tin/bao-mat">Chính sách bảo mật</Link>
            <Link href="/thong-tin/dieu-khoan">Điều khoản sử dụng</Link>
          </div>
          <div>
            <h4>Kết nối với POKÉVAULT</h4>
            <p>
              Email, số điện thoại, địa chỉ và mạng xã hội đang chờ chủ cửa hàng
              cập nhật.
            </p>
            <Link className="text-link" href="/thong-tin/lien-he">
              Thông tin liên hệ <ArrowUpRight size={15} />
            </Link>
            <Link href="/quan-tri">Dành cho quản trị viên</Link>
          </div>
        </div>
        <div className="footer-bottom">
          <p>
            © {new Date().getFullYear()} POKÉVAULT. Thương hiệu mẫu độc lập.
          </p>
          <p>
            Ảnh minh họa tự thiết kế · Không đại diện cho thương hiệu Pokémon.
          </p>
        </div>
      </footer>
    </>
  );
}
function Shell() {
  const path = usePathname();
  useEffect(() => {
    window.scrollTo(0, 0);
    const titles: Record<string, string> = {
      "/": "Mở hộp, mở niềm vui",
      "/san-pham": "Khám phá cửa hàng",
      "/gio-hang": "Giỏ hàng",
      "/thanh-toan": "Thanh toán",
      "/tai-khoan": "Tài khoản",
      "/quan-tri": "Quản trị",
      "/admin": "Quản trị",
    };
    document.title = (titles[path] || "Bộ sưu tập của bạn") + " | POKÉVAULT";
  }, [path]);
  let view;
  if (path === "/") view = <HomeStudio />;
  else if (path === "/san-pham" || path === "/yeu-thich")
    view = <Catalog favoritesOnly={path === "/yeu-thich"} />;
  else if (path.startsWith("/san-pham/"))
    view = <ProductDetail id={decodeURIComponent(path.split("/")[2])} />;
  else if (path === "/gio-hang") view = <Cart />;
  else if (path === "/thanh-toan") view = <Checkout />;
  else if (path === "/tai-khoan") view = <Account />;
  else if (path === "/quan-tri" || path === "/admin")
    return (
      <>
        <a className="skip-link" href="#main">
          Bỏ qua đến nội dung
        </a>
        <main id="main">
          <Admin />
        </main>
      </>
    );
  else view = <Information slug={path.split("/")[2] || "not-found"} />;
  return (
    <div className="storefront">
      <a className="skip-link" href="#main">
        Bỏ qua đến nội dung
      </a>
      <Header />
      <main id="main">{view}</main>
      <Footer />
      <CartDrawer />
    </div>
  );
}
export default function Store() {
  return (
    <ShopProvider>
      <Shell />
    </ShopProvider>
  );
}
