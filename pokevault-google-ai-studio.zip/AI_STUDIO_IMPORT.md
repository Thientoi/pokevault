# Hướng dẫn nhập POKÉVAULT

Sau khi chọn **Build → + → Import from GitHub** và nhập repository chứa mã nguồn này, gửi nội dung sau cho Google AI Studio:

```text
Đây là dự án POKÉVAULT đã có giao diện cửa hàng và trang quản trị hoàn chỉnh. Hãy đọc README.md và chạy đúng dự án hiện có.

- Dùng Next.js 16, React 19 và Node.js >=22.13. Cài bằng npm ci, chạy npm run dev. Máy chủ cần lắng nghe 0.0.0.0, cổng 3000 hoặc giá trị PORT của môi trường preview.
- Giữ giao diện tiếng Việt, ảnh và font trong public, 9 sản phẩm mẫu, tìm kiếm/bộ lọc, xem nhanh, giỏ hàng, đặt đơn thử và toàn bộ trang quản trị /quan-tri.
- Backend đã dùng node:sqlite; migration trong drizzle được áp dụng tự động. Không thêm Cloudflare, Wrangler hay Sites. Không cần gọi Gemini API cho chức năng cửa hàng.
- Giữ COMMERCE_LIVE=false. Không tạo thanh toán, gửi email hay giao hàng giả thành công. Không tự tạo tài khoản hoặc mật khẩu mặc định. Thiết lập admin bằng ADMIN_SETUP_KEY ở server Secrets và form thiết lập tại /quan-tri theo README.
- Không đưa Secrets vào mã nguồn hoặc frontend. SQLite trong .data chỉ dùng cho bản xem trước; trước khi xuất bản vận hành lâu dài phải kết nối cơ sở dữ liệu bền vững.
- Nếu preview dùng proxy HTTPS, cấu hình APP_URL ở máy chủ bằng đúng origin của preview để các yêu cầu đăng nhập cùng nguồn được xác thực đúng.
- Chạy npm run check, npm test và npm run build; kiểm tra cửa hàng và trang admin trong preview. Chỉ sửa lỗi tương thích thực tế, không dựng lại một giao diện thay thế.
```

Sau khi tạo thành công, sao chép URL dự án từ thanh địa chỉ Google AI Studio. URL này phải do Google tạo; không thể suy ra chỉ từ tên repository.
