export const LOCAL_ADMIN_EMAIL = "admin@pokevault.local";

export function localAdminEnabled(
  url: URL,
  config: { LOCAL_ADMIN_LOGIN?: string; COMMERCE_LIVE?: string },
) {
  return (
    config.LOCAL_ADMIN_LOGIN === "true" &&
    config.COMMERCE_LIVE === "false" &&
    ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)
  );
}
