import { z } from "zod";
export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email("Email chưa đúng định dạng.")
  .max(200);
export const passwordSchema = z
  .string()
  .min(10, "Mật khẩu cần ít nhất 10 ký tự.")
  .max(128);
const accountLoginSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
});
const localAdminLoginSchema = z.object({
  email: z.string().trim().toLowerCase().pipe(z.literal("admin")),
  password: z.string().min(1, "Vui lòng nhập mật khẩu.").max(128),
});
export function loginSchema(allowLocalAdmin = false) {
  return allowLocalAdmin
    ? z.union([localAdminLoginSchema, accountLoginSchema])
    : accountLoginSchema;
}
export const phoneSchema = z
  .string()
  .trim()
  .regex(/^(\+84|0)[0-9]{9}$/, "Nhập số điện thoại Việt Nam hợp lệ.");
export const profileSchema = z.object({
  name: z.string().trim().min(2).max(100),
  phone: z.union([phoneSchema, z.literal("")]),
  address: z.string().trim().max(500),
});
export const checkoutSchema = z.object({
  id: z.string().uuid(),
  name: z.string().trim().min(2, "Vui lòng nhập họ tên.").max(100),
  phone: phoneSchema,
  address: z
    .string()
    .trim()
    .min(10, "Vui lòng nhập địa chỉ đầy đủ (ít nhất 10 ký tự).")
    .max(500),
  note: z.string().max(1000).default(""),
  shippingMethod: z.enum(["standard", "express"]),
  payment: z.literal("cod"),
  coupon: z.string().trim().max(30).default(""),
  items: z
    .array(
      z.object({
        id: z.string().min(1).max(100),
        quantity: z.number().int().min(1).max(20),
      }),
    )
    .min(1)
    .max(20),
});
export const productSchema = z.object({
  id: z.string().regex(/^[a-z0-9-]{1,80}$/),
  name: z.string().trim().min(2).max(150),
  category: z.enum([
    "Mystery Box",
    "Booster",
    "Thẻ bài",
    "Phụ kiện",
    "Quà tặng",
  ]),
  price: z.number().int().min(1000).max(100000000),
  oldPrice: z.number().int().min(0).max(100000000),
  stock: z.number().int().min(0).max(100000),
  description: z.string().trim().min(5).max(5000),
  image: z
    .string()
    .regex(/^\/products\/[a-z0-9-]+\.svg$/, "Chọn ảnh minh họa có sẵn."),
  color: z.enum(["yellow", "red", "dark", "blue", "purple", "mint", "pink"]),
  badge: z.string().max(30),
  active: z.number().int().min(0).max(1),
});
export function totals(
  subtotal: number,
  method: string,
  percent = 0,
  maximum = 0,
) {
  const discount = Math.min(Math.floor((subtotal * percent) / 100), maximum);
  const shipping =
    method === "express" ? 50000 : subtotal >= 699000 ? 0 : 30000;
  return {
    subtotal,
    discount,
    shipping,
    total: subtotal - discount + shipping,
  };
}
