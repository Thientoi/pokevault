import { getDatabase } from "./database";
import { seedProducts } from "./catalog";
import { LOCAL_ADMIN_EMAIL, localAdminEnabled } from "./local-admin";
export const config = () => ({
  ADMIN_SETUP_KEY: process.env.ADMIN_SETUP_KEY,
  COMMERCE_LIVE: process.env.COMMERCE_LIVE || "false",
  LOCAL_ADMIN_LOGIN: process.env.LOCAL_ADMIN_LOGIN,
});
export function db() {
  return getDatabase();
}
export async function seed() {
  const database = db();
  const found = await database
    .prepare("SELECT value FROM meta WHERE key='seed-v1'")
    .first();
  if (found) return;
  await database.batch([
    ...seedProducts.map((p) =>
      database
        .prepare(
          "INSERT OR IGNORE INTO products (id,name,category,price,old_price,stock,description,image,color,badge,active,created_at) SELECT ?,?,?,?,?,?,?,?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM meta WHERE key='seed-v1')",
        )
        .bind(
          p.id,
          p.name,
          p.category,
          p.price,
          p.oldPrice,
          p.stock,
          p.description,
          p.image,
          p.color,
          p.badge,
          p.active,
          p.createdAt,
        ),
    ),
    database.prepare(
      "INSERT OR IGNORE INTO coupons (code,percent,maximum,active) SELECT 'HELLOVAULT',10,50000,1 WHERE NOT EXISTS (SELECT 1 FROM meta WHERE key='seed-v1')",
    ),
    database.prepare(
      "INSERT OR IGNORE INTO meta (key,value) VALUES ('seed-v1','1')",
    ),
  ]);
}
const hex = (buf: ArrayBuffer) =>
  Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join(
    "",
  );
export async function digest(s: string) {
  return hex(
    await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)),
  );
}
export async function passwordHash(
  password: string,
  salt = hex(crypto.getRandomValues(new Uint8Array(16)).buffer),
) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  return (
    salt +
    ":" +
    hex(
      await crypto.subtle.deriveBits(
        {
          name: "PBKDF2",
          hash: "SHA-256",
          salt: new TextEncoder().encode(salt),
          iterations: 100000,
        },
        key,
        256,
      ),
    )
  );
}
export async function verifyPassword(password: string, stored: string) {
  const hash = await passwordHash(password, stored.split(":")[0]);
  let diff = hash.length ^ stored.length;
  for (let i = 0; i < hash.length; i++)
    diff |= hash.charCodeAt(i) ^ (stored.charCodeAt(i) || 0);
  return diff === 0;
}
export type User = {
  id: string;
  email: string;
  name: string;
  role: string;
  address: string;
  phone: string;
};
export async function currentUser(req: Request): Promise<User | null> {
  const cookie = req.headers
    .get("cookie")
    ?.match(/(?:^|;\s*)pv_session=([^;]+)/)?.[1];
  if (!cookie) return null;
  const user = await db()
    .prepare(
      "SELECT u.id,u.email,u.name,u.role,u.address,u.phone FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token=? AND s.expires>?",
    )
    .bind(await digest(cookie), Date.now())
    .first<User>();
  if (
    user?.email === LOCAL_ADMIN_EMAIL &&
    !localAdminEnabled(new URL(req.url), config())
  )
    return null;
  return user;
}
export async function session(userId: string, req: Request) {
  const token = crypto.randomUUID() + crypto.randomUUID();
  await db()
    .prepare("INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)")
    .bind(await digest(token), userId, Date.now() + 7 * 86400000)
    .run();
  return `pv_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${new URL(req.url).protocol === "https:" ? "; Secure" : ""}`;
}
export async function limit(req: Request, scope: string, max = 12) {
  const key = `${scope}:${req.headers.get("cf-connecting-ip") || "local"}:${Math.floor(Date.now() / 60000)}`;
  const row = await db()
    .prepare(
      "INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count",
    )
    .bind(key, Date.now() + 120000)
    .first<{ count: number }>();
  await db()
    .prepare("DELETE FROM rate_limits WHERE expires<?")
    .bind(Date.now())
    .run();
  if (row && row.count > max)
    throw Object.assign(
      new Error("Bạn thao tác quá nhanh. Vui lòng thử lại sau một phút."),
      { status: 429 },
    );
}
export function fail(message: string, status = 400): never {
  throw Object.assign(new Error(message), { status });
}
export function json(
  data: unknown,
  status = 200,
  headers: Record<string, string> = {},
) {
  return Response.json(data, {
    status,
    headers: {
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      ...headers,
    },
  });
}
