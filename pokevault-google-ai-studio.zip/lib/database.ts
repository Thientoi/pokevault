import { DatabaseSync, type SQLInputValue } from "node:sqlite";
import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, readdirSync } from "node:fs";
import { dirname, resolve } from "node:path";

export type QueryResult<T = Record<string, any>> = {
  results: T[];
  success: true;
  meta: { changes: number; last_row_id: number };
};

type Migration = { name: string; checksum: string; sql: string };

function migrationsIn(directory: string): Migration[] {
  return readdirSync(directory)
    .filter((name) => name.endsWith(".sql"))
    .sort()
    .map((name) => {
      // Git may normalize line endings between Windows and Linux.
      const sql = readFileSync(resolve(directory, name), "utf8").replace(
        /\r\n/g,
        "\n",
      );
      return {
        name,
        sql,
        checksum: createHash("sha256").update(sql).digest("hex"),
      };
    });
}

export class PreparedQuery {
  readonly owner: NodeDatabase;
  readonly sql: string;
  readonly values: SQLInputValue[];

  constructor(owner: NodeDatabase, sql: string, values: SQLInputValue[] = []) {
    this.owner = owner;
    this.sql = sql;
    this.values = values;
  }

  bind(...values: SQLInputValue[]) {
    return new PreparedQuery(this.owner, this.sql, values);
  }

  async first<T = Record<string, any>>(column?: string): Promise<T | null> {
    const row = this.owner.execute<Record<string, any>>(this).results[0];
    if (!row) return null;
    if (column !== undefined) {
      if (!(column in row)) throw new Error(`Unknown result column: ${column}`);
      return row[column] as T;
    }
    return row as T;
  }

  async all<T = Record<string, any>>(): Promise<QueryResult<T>> {
    return this.owner.execute<T>(this);
  }

  async run<T = Record<string, any>>(): Promise<QueryResult<T>> {
    return this.owner.execute<T>(this);
  }
}

export class NodeDatabase {
  private readonly connection: DatabaseSync;

  constructor(filename: string, migrationsDirectory: string) {
    if (filename !== ":memory:")
      mkdirSync(dirname(filename), { recursive: true });
    this.connection = new DatabaseSync(filename);
    try {
      this.connection.exec(
        "PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL;",
      );
      this.migrate(migrationsIn(migrationsDirectory));
    } catch (error) {
      this.connection.close();
      throw error;
    }
  }

  private migrate(migrations: Migration[]) {
    this.connection.exec(
      "CREATE TABLE IF NOT EXISTS __pokevault_migrations (name TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at INTEGER NOT NULL)",
    );
    this.connection.exec("BEGIN IMMEDIATE");
    try {
      const applied = this.connection
        .prepare("SELECT name, checksum FROM __pokevault_migrations")
        .all() as { name: string; checksum: string }[];
      for (const previous of applied) {
        const source = migrations.find((item) => item.name === previous.name);
        if (!source || source.checksum !== previous.checksum)
          throw new Error(
            `Applied migration has changed or is missing: ${previous.name}`,
          );
      }
      for (const migration of migrations) {
        if (applied.some((item) => item.name === migration.name)) continue;
        this.connection.exec(migration.sql);
        this.connection
          .prepare(
            "INSERT INTO __pokevault_migrations(name,checksum,applied_at) VALUES(?,?,?)",
          )
          .run(migration.name, migration.checksum, Date.now());
      }
      this.connection.exec("COMMIT");
    } catch (error) {
      this.connection.exec("ROLLBACK");
      throw error;
    }
  }

  prepare(sql: string) {
    return new PreparedQuery(this, sql);
  }

  /** Synchronous internals keep every batch in one uninterrupted transaction. */
  execute<T = Record<string, any>>(query: PreparedQuery): QueryResult<T> {
    if (query.owner !== this)
      throw new Error("Query belongs to another database.");
    const before = Number(
      this.connection.prepare("SELECT total_changes() AS n").get()?.n,
    );
    const rows = this.connection.prepare(query.sql).all(...query.values) as T[];
    const state = this.connection
      .prepare(
        "SELECT changes() AS changes, total_changes() AS total, last_insert_rowid() AS id",
      )
      .get()!;
    return {
      results: rows,
      success: true,
      meta: {
        changes: Number(state.total) === before ? 0 : Number(state.changes),
        last_row_id: Number(state.id),
      },
    };
  }

  async batch<T = Record<string, any>>(
    queries: PreparedQuery[],
  ): Promise<QueryResult<T>[]> {
    if (queries.some((query) => query.owner !== this))
      throw new Error("Batch queries must belong to the same database.");
    this.connection.exec("BEGIN IMMEDIATE");
    try {
      const results = queries.map((query) => this.execute<T>(query));
      this.connection.exec("COMMIT");
      return results;
    } catch (error) {
      this.connection.exec("ROLLBACK");
      throw error;
    }
  }

  /** Operator-only SQL scripts; never expose this method through an HTTP route. */
  exec(sql: string) {
    this.connection.exec("BEGIN IMMEDIATE");
    try {
      this.connection.exec(sql);
      this.connection.exec("COMMIT");
    } catch (error) {
      this.connection.exec("ROLLBACK");
      throw error;
    }
  }

  close() {
    this.connection.close();
  }
}

export function createDatabase(
  filename = process.env.DATABASE_PATH || ".data/pokevault.sqlite",
  options: { migrationsDirectory?: string } = {},
) {
  return new NodeDatabase(
    filename === ":memory:" ? filename : resolve(filename),
    resolve(options.migrationsDirectory || "drizzle"),
  );
}

// Next hot reload must reuse the same connection rather than open one per module.
const globals = globalThis as typeof globalThis & {
  __pokevaultDatabases?: Map<string, NodeDatabase>;
};
export function getDatabase(): NodeDatabase {
  const filename = resolve(
    process.env.DATABASE_PATH || ".data/pokevault.sqlite",
  );
  const connections = (globals.__pokevaultDatabases ??= new Map<string, NodeDatabase>());
  let database = connections.get(filename);
  if (!database) {
    database = createDatabase(filename);
    connections.set(filename, database);
  }
  return database;
}
