import type { Product } from "./catalog";

export const boxBudgets = [
  {
    id: "starter",
    label: "Bắt đầu nhỏ",
    budget: "Dưới 350.000đ",
    min: 0,
    max: 350000,
    description: "Một chút tò mò cho lần mở hộp đầu tiên.",
    image: "/studio/starter.png",
  },
  {
    id: "explorer",
    label: "Thêm khám phá",
    budget: "350.000đ – dưới 1 triệu",
    min: 350000,
    max: 1000000,
    description: "Dành một khoảng riêng cho niềm vui sưu tầm.",
    image: "/studio/adventure.png",
  },
  {
    id: "collector",
    label: "Dịp đặc biệt",
    budget: "Từ 1.000.000đ",
    min: 1000000,
    max: Infinity,
    description: "Một lựa chọn cho khoảnh khắc bạn muốn ghi nhớ.",
    image: "/studio/legend.png",
  },
] as const;

export function findBudgetBox(
  products: Product[],
  budget: (typeof boxBudgets)[number],
) {
  return products
    .filter(
      (p) =>
        p.active === 1 &&
        p.category === "Mystery Box" &&
        p.stock > 0 &&
        p.price >= budget.min &&
        p.price < budget.max,
    )
    .sort((a, b) => a.price - b.price)[0];
}
