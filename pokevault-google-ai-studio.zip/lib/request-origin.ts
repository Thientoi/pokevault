/** Match the browser's origin to this request host or an operator-set public URL. */
export function sameOriginRequest(request: Request, publicUrl?: string) {
  const origin = request.headers.get("origin");
  if (!origin) return false;
  try {
    if (new URL(origin).origin !== origin) return false;
    const internal = new URL(request.url);
    const allowed = new Set([internal.origin]);
    // Next may construct Request.url with the listener hostname (0.0.0.0).
    // Host remains the host that the browser addressed; browsers cannot set it.
    const host = request.headers.get("host");
    if (host && !/[\s/\\#?@]/.test(host))
      allowed.add(new URL(`${internal.protocol}//${host}`).origin);
    // For a TLS-terminating preview proxy, set APP_URL to the actual HTTPS URL.
    if (publicUrl) allowed.add(new URL(publicUrl).origin);
    return allowed.has(origin);
  } catch {
    return false;
  }
}
