// Preserve the stored image key and admin choices while serving the new studio artwork.
const studioImages: Record<string, string> = {
  "/products/box-yellow.svg": "/studio/starter.png",
  "/products/box-red.svg": "/studio/adventure.png",
  "/products/box-black.svg": "/studio/legend.png",
  "/products/pack.svg": "/studio/booster.png",
};
export function productImage(src: string): string {
  return studioImages[src] || src;
}
