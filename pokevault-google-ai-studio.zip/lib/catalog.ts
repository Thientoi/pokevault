export type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  oldPrice: number;
  stock: number;
  description: string;
  image: string;
  color: string;
  badge: string;
  active: number;
  createdAt: number;
  soldCount?: number;
};
export const categories = [
  "Mystery Box",
  "Booster",
  "Thẻ bài",
  "Phụ kiện",
  "Quà tặng",
];
const rows = [
  [
    "mystery-starter",
    "Mystery Box · Starter",
    "Mystery Box",
    299000,
    349000,
    24,
    "Bắt đầu hành trình sưu tầm với một hộp bất ngờ nhỏ xinh.",
    "box-yellow",
    "yellow",
    "DỄ BẮT ĐẦU",
  ],
  [
    "mystery-adventure",
    "Mystery Box · Adventure",
    "Mystery Box",
    599000,
    699000,
    18,
    "Thêm một chút tò mò, thêm nhiều điều để khám phá.",
    "box-red",
    "red",
    "YÊU THÍCH",
  ],
  [
    "mystery-legend",
    "Mystery Box · Legend",
    "Mystery Box",
    1299000,
    0,
    8,
    "Một trải nghiệm mở hộp dành cho người yêu sưu tầm.",
    "box-black",
    "dark",
    "PREMIUM",
  ],
  [
    "booster-pack",
    "Booster Pack · Random",
    "Booster",
    129000,
    149000,
    40,
    "Một gói thẻ ngẫu nhiên để làm mới bộ sưu tập của bạn.",
    "pack",
    "blue",
    "MỚI",
  ],
  [
    "booster-box",
    "Booster Box · Discovery",
    "Booster",
    2199000,
    0,
    6,
    "Hộp booster minh họa dành cho những buổi mở thẻ cùng bạn bè.",
    "box-blue",
    "blue",
    "",
  ],
  [
    "collection-cards",
    "Bộ thẻ · First Collection",
    "Thẻ bài",
    249000,
    0,
    15,
    "Bộ thẻ minh họa để bắt đầu sắp xếp bộ sưu tập.",
    "cards",
    "purple",
    "MỚI",
  ],
  [
    "card-sleeves",
    "Túi bảo vệ thẻ · Clear",
    "Phụ kiện",
    59000,
    79000,
    60,
    "Bộ 100 túi trong suốt, kích thước mẫu 66 × 91 mm.",
    "sleeves",
    "mint",
    "",
  ],
  [
    "collector-album",
    "Album · Collector Edition",
    "Phụ kiện",
    349000,
    0,
    0,
    "Album 9 ngăn mỗi trang, thiết kế gọn gàng cho bộ sưu tập.",
    "album",
    "yellow",
    "TẠM HẾT",
  ],
  [
    "gift-combo",
    "Combo · A Little Surprise",
    "Quà tặng",
    449000,
    499000,
    12,
    "Một món quà gồm hộp Starter, túi bảo vệ và thiệp viết tay.",
    "gift",
    "pink",
    "QUÀ TẶNG",
  ],
] as const;
export const seedProducts: Product[] = rows.map((r, i) => ({
  id: r[0],
  name: r[1],
  category: r[2],
  price: r[3],
  oldPrice: r[4],
  stock: r[5],
  description: r[6],
  image: `/products/${r[7]}.svg`,
  color: r[8],
  badge: r[9],
  active: 1,
  createdAt: 1793836800000 + i * 1000,
}));
export const money = (n: number) =>
  new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
    n,
  );
export const normalize = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/gi, "d")
    .toLowerCase();
