import type { Product } from "./catalog";

export type CartItem = { id: string; quantity: number };
export const CART_LINE_LIMIT = 20;
export const CART_QUANTITY_LIMIT = 20;

type AddResult =
  | { ok: true; cart: CartItem[] }
  | { ok: false; reason: "quantity" | "unavailable" | "capacity" | "lines" };

/** Apply an addition to the latest cart without changing it when rejected. */
export function addToCart(
  cart: CartItem[],
  product: Pick<Product, "id" | "active" | "stock"> | undefined,
  quantity: number,
): AddResult {
  if (!Number.isInteger(quantity) || quantity < 1)
    return { ok: false, reason: "quantity" };
  if (
    !product ||
    product.active !== 1 ||
    !Number.isInteger(product.stock) ||
    product.stock < 1
  )
    return { ok: false, reason: "unavailable" };
  const existing = cart.find((item) => item.id === product.id);
  const nextQuantity = (existing?.quantity || 0) + quantity;
  if (nextQuantity > Math.min(product.stock, CART_QUANTITY_LIMIT))
    return { ok: false, reason: "capacity" };
  if (!existing && cart.length >= CART_LINE_LIMIT)
    return { ok: false, reason: "lines" };
  return {
    ok: true,
    cart: existing
      ? cart.map((item) =>
          item.id === product.id ? { ...item, quantity: nextQuantity } : item,
        )
      : [...cart, { id: product.id, quantity: nextQuantity }],
  };
}

/** Local storage is untrusted; preserve one valid entry per product. */
export function restoreCart(value: unknown): CartItem[] {
  if (!Array.isArray(value)) return [];
  const result: CartItem[] = [];
  const seen = new Set<string>();
  for (const item of value) {
    if (
      !item ||
      typeof item !== "object" ||
      typeof item.id !== "string" ||
      !item.id ||
      item.id.length > 100 ||
      !Number.isInteger(item.quantity) ||
      item.quantity < 1 ||
      item.quantity > CART_QUANTITY_LIMIT ||
      seen.has(item.id)
    )
      continue;
    result.push({ id: item.id, quantity: item.quantity });
    seen.add(item.id);
    if (result.length === CART_LINE_LIMIT) break;
  }
  return result;
}
